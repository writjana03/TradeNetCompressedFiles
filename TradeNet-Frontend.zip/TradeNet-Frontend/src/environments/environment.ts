export const environment = {
  production: false,
  apis: {
    admin:          'https://localhost:7001/api',
    businessTrader: 'https://localhost:7002/api',
    tradeOfficer:   'https://localhost:7003/api',
    programManager: 'https://localhost:7004/api',
    compliance:     'https://localhost:7005/api',
    govAuditor:     'https://localhost:7006/api',
  }
};
