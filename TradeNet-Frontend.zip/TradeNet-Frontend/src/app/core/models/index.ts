// ─── Auth ─────────────────────────────────────────────────────────────────────
export interface LoginRequest { email: string; password: string; }

export interface RegisterRequest {
  fullName: string; email: string; password: string; confirmPassword: string;
  role: string; phone?: string;
}

export interface AuthResponse {
  token: string; userId: number; fullName: string; email: string; role: string;
}

// ─── User ─────────────────────────────────────────────────────────────────────
export interface User {
  id: number; fullName: string; email: string; role: string;
  status: string; phone?: string; createdAt: string;
}

export interface CreateUserRequest {
  fullName: string; email: string; password: string; role: string; phone?: string;
}

// ─── BusinessTrader ───────────────────────────────────────────────────────────
export interface BusinessTrader {
  id: number; userId: number; fullName: string; email: string;
  phoneNumber?: string; address?: string; nationality?: string;
  dateOfBirth?: string; verificationStatus: string;
}

// ─── Business ─────────────────────────────────────────────────────────────────
export interface Business {
  id: number; businessTraderId: number; businessName: string;
  businessType: string; address?: string; contactInfo?: string;
  phoneNumber?: string; registrationNumber?: string; description?: string;
  registrationDate: string; status: string; complianceStatus: string;
}

export interface BusinessRegistrationRequest {
  businessName: string; businessType: string; address?: string;
  contactInfo?: string; phoneNumber?: string; description?: string;
}

// ─── Documents ────────────────────────────────────────────────────────────────
export interface TraderDocument {
  id: number; businessTraderId: number; documentType: string;
  fileName: string; filePath?: string; uploadedDate: string;
  verificationStatus: string; rejectionReason?: string;
  verificationDate?: string; verifiedByUserId?: number;
}

export interface BusinessDocument {
  id: number; businessId: number; docType: string; fileName: string;
  fileURL: string; uploadedDate: string; verificationStatus: string;
  rejectionReason?: string;
}

// ─── License & Application ────────────────────────────────────────────────────
export interface TradeLicense {
  id: number; title: string; licenseType: string; description: string;
  category?: string; fee: number; issuedDate?: string; expiryDate?: string;
  postedDate: string; status: string; businessId: number;
}

export interface LicenseApplication {
  id: number; businessTraderId: number; tradeLicenseId: number;
  submittedDate: string; status: string; applicationNotes?: string;
  reviewedDate?: string; reviewNotes?: string; rejectionReason?: string;
  tradeLicense?: TradeLicense; businessTrader?: BusinessTrader;
}

export interface LicenseApplyRequest {
  tradeLicenseId: number; applicationNotes?: string;
}

// ─── Transaction ──────────────────────────────────────────────────────────────
export interface Transaction {
  id: number; businessId: number; transactionType: string; amount: number;
  transactionDate: string; status: string; counterparty?: string;
  invoiceNumber?: string; description?: string; officerNotes?: string;
  monitoredByUserId?: number;
}

export interface TransactionCreateRequest {
  businessId: number; transactionType: string; amount: number;
  counterparty?: string; invoiceNumber?: string; description?: string;
}

// ─── Program & Subsidy ────────────────────────────────────────────────────────
export interface TradeProgram {
  id: number; programName: string; description?: string; programType?: string;
  totalBudget: number; budgetUtilized: number; startDate: string;
  endDate?: string; eligibilityCriteria?: string; status: string;
}

export interface Subsidy {
  id: number; tradeProgramId: number; businessTraderId: number;
  subsidyType: string; amount: number; subsidyDate: string;
  status: string; description?: string;
  tradeProgram?: TradeProgram; businessTrader?: BusinessTrader;
}

export interface Resource {
  id: number; type: string; name?: string; quantity: number;
  status: string; tradeProgramId: number;
}

// ─── Compliance ───────────────────────────────────────────────────────────────
export interface ComplianceRecord {
  id: number; entityId: number; type: string; result: string;
  date: string; notes?: string; recommendedAction?: string;
  officerId?: number;
}

export interface Complaint {
  id: number; userId: number; businessId?: number;
  complaintDescription: string; status: string;
  submittedDate: string; resolution?: string;
  user?: User; business?: Business;
}

export interface Violation {
  id: number; businessId: number; officerId: number;
  violationType: string; description?: string; penalty: number;
  violationDate: string; status: string;
}

// ─── Audit & Report ───────────────────────────────────────────────────────────
export interface Audit {
  id: number; officerId: number; auditTitle: string; scope: string;
  findings?: string; date: string; completedDate?: string; status: string;
}

export interface Report {
  id: number; reportName: string; generatedBy: number;
  generatedDate: string; reportType: string; reportContent?: string;
  startDate?: string; endDate?: string;
}

// ─── Notification & Log ───────────────────────────────────────────────────────
export interface Notification {
  id: number; userId: number; message: string; category?: string;
  entityId?: number; entityType?: string; createdDate: string;
  isRead: boolean; status: string;
}

export interface SystemLog {
  id: number; userId: number; action: string; resource?: string;
  timestamp: string; ipAddress?: string;
}

// ─── Dashboards ───────────────────────────────────────────────────────────────
export interface AdminDashboard {
  totalUsers: number; activeUsers: number; totalBusinessTraders: number;
  totalBusinesses: number; totalLicenses: number; activeLicenses: number;
  totalApplications: number; pendingApplications: number;
  totalTransactions: number; flaggedTransactions: number;
  totalPrograms: number; activePrograms: number;
  pendingDocuments: number; complianceAlerts: number;
  totalAudits: number; openAudits: number; totalReports: number;
  totalComplaints: number; pendingComplaints: number; totalViolations: number;
  totalBudget: number; totalSubsidiesPaid: number;
  recentNotifications: Notification[]; recentLogs: SystemLog[];
  recentLicenses: TradeLicense[]; recentApplications: LicenseApplication[];
  programs: TradeProgram[]; recentCompliance: ComplianceRecord[];
  recentAudits: Audit[];
}

export interface BusinessTraderDashboard {
  businessTrader: BusinessTrader;
  totalBusinesses: number; activeApplications: number; approvedApplications: number;
  totalTransactions: number; totalTradeVolume: number;
  documentCount: number; verifiedDocs: number; pendingDocs: number;
  totalSubsidies: number; totalSubsidyAmount: number;
  recentApplications: LicenseApplication[]; recentTransactions: Transaction[];
  notifications: Notification[]; availableLicenses: TradeLicense[];
}

export interface TradeOfficerDashboard {
  pendingDocuments: number; pendingLicenseApplications: number;
  approvedApplications: number; rejectedApplications: number;
  flaggedTransactions: number; pendingBusinessVerifications: number;
  pendingBizDocs: BusinessDocument[]; pendingTraderDocs: TraderDocument[];
  recentApplications: LicenseApplication[]; suspiciousTransactions: Transaction[];
  flaggedBusinesses: Business[]; notifications: Notification[];
}

export interface ProgramManagerDashboard {
  totalPrograms: number; activePrograms: number;
  totalBudget: number; budgetUtilized: number;
  totalSubsidies: number; totalBeneficiaries: number; totalResources: number;
  programs: TradeProgram[]; recentSubsidies: Subsidy[];
  notifications: Notification[];
}

export interface ComplianceDashboard {
  pendingReviews: number; totalComplaints: number; pendingComplaints: number;
  totalViolations: number; totalInspections: number; nonCompliantBusinesses: number;
  businesses: Business[]; recentComplaints: Complaint[];
  recentViolations: Violation[]; recentRecords: ComplianceRecord[];
}

export interface AuditorDashboard {
  totalAudits: number; openAudits: number; completedAudits: number;
  totalCompliance: number; nonCompliant: number;
  totalPrograms: number; totalReports: number;
  recentAudits: Audit[]; recentCompliance: ComplianceRecord[];
  programs: TradeProgram[]; recentReports: Report[];
  notifications: Notification[];
}

// ─── Generic API Response ─────────────────────────────────────────────────────
export interface ApiResponse<T = any> {
  message?: string; Message?: string;
  [key: string]: any;
}
