import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

const DASH_MAP: Record<string, string> = {
  BusinessTrader:    '/business-trader/dashboard',
  TradeOfficer:      '/trade-officer/dashboard',
  ProgramManager:    '/program-manager/dashboard',
  SystemAdmin:       '/admin/dashboard',
  ComplianceOfficer: '/compliance-officer/dashboard',
  GovernmentAuditor: '/gov-auditor/dashboard',
};

/** Protects routes that require any logged-in user */
export const authGuard: CanActivateFn = () => {
  const auth   = inject(AuthService);
  const router = inject(Router);
  if (auth.isLoggedIn()) return true;
  return router.createUrlTree(['/login']);
};

/** Prevents logged-in users from accessing /login and /register */
export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  if (!auth.isLoggedIn()) return true;
  const dest = DASH_MAP[auth.role()] ?? '/home';
  return inject(Router).createUrlTree([dest]);
};

/** Protects routes that require a specific role */
export const roleGuard = (allowedRoles: string[]): CanActivateFn => () => {
  const auth   = inject(AuthService);
  const router = inject(Router);
  if (!auth.isLoggedIn()) return router.createUrlTree(['/login']);
  if (allowedRoles.includes(auth.role())) return true;
  const dest = DASH_MAP[auth.role()] ?? '/home';
  return router.createUrlTree([dest]);
};
