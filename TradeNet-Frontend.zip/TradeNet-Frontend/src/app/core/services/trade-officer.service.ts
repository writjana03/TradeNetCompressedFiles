import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  TraderDocument, BusinessDocument, LicenseApplication, Transaction,
  Business, Notification, TradeOfficerDashboard, ApiResponse
} from '../models/index';

@Injectable({ providedIn: 'root' })
export class TradeOfficerService {
  private base = environment.apis.tradeOfficer;

  constructor(private http: HttpClient) {}

  getDashboard(): Observable<TradeOfficerDashboard> {
    return this.http.get<TradeOfficerDashboard>(`${this.base}/trade-officer/dashboard`);
  }

  // Document Verification
  getPendingTraderDocs(): Observable<TraderDocument[]> {
    return this.http.get<TraderDocument[]>(`${this.base}/trade-officer/documents/trader/pending`);
  }
  getPendingBusinessDocs(): Observable<BusinessDocument[]> {
    return this.http.get<BusinessDocument[]>(`${this.base}/trade-officer/documents/business/pending`);
  }
  verifyTraderDoc(id: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/documents/trader/${id}/verify`, {});
  }
  rejectTraderDoc(id: number, reason: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/documents/trader/${id}/reject`, JSON.stringify(reason));
  }
  verifyBusinessDoc(id: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/documents/business/${id}/verify`, {});
  }
  rejectBusinessDoc(id: number, reason: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/documents/business/${id}/reject`, JSON.stringify(reason));
  }

  // License Applications
  getPendingApplications(): Observable<LicenseApplication[]> {
    return this.http.get<LicenseApplication[]>(`${this.base}/trade-officer/applications/pending`);
  }
  approveApplication(id: number, expiryDate?: string, notes?: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/applications/${id}/approve`, { expiryDate, notes });
  }
  rejectApplication(id: number, reason: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/applications/${id}/reject`, JSON.stringify(reason));
  }

  // Transactions
  getTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.base}/trade-officer/transactions`);
  }
  getSuspiciousTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.base}/trade-officer/transactions/suspicious`);
  }
  flagTransaction(id: number, notes: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/transactions/${id}/flag`, JSON.stringify(notes));
  }
  clearTransactionFlag(id: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/transactions/${id}/clear`, {});
  }

  // Businesses
  getBusinesses(): Observable<Business[]> {
    return this.http.get<Business[]>(`${this.base}/trade-officer/businesses`);
  }
  verifyBusiness(id: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/businesses/${id}/verify`, {});
  }
  rejectBusiness(id: number, reason: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/trade-officer/businesses/${id}/reject`, JSON.stringify(reason));
  }

  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.base}/trade-officer/notifications`);
  }
}
