import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  AdminDashboard, User, CreateUserRequest, Business, Notification,
  Report, SystemLog, ApiResponse
} from '../models/index';

@Injectable({ providedIn: 'root' })
export class AdminService {
  private base = environment.apis.admin;

  constructor(private http: HttpClient) {}

  // Dashboard
  getDashboard(): Observable<AdminDashboard> {
    return this.http.get<AdminDashboard>(`${this.base}/admin/dashboard`);
  }

  // Users
  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.base}/admin/users`);
  }
  getUser(id: number): Observable<User> {
    return this.http.get<User>(`${this.base}/admin/users/${id}`);
  }
  createUser(req: CreateUserRequest): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/admin/users`, req);
  }
  updateUser(id: number, user: Partial<User>): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/admin/users/${id}`, user);
  }
  deactivateUser(id: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/admin/users/${id}/deactivate`, {});
  }
  activateUser(id: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/admin/users/${id}/activate`, {});
  }
  deleteUser(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(`${this.base}/admin/users/${id}`);
  }

  // Businesses
  getAllBusinesses(status?: string): Observable<Business[]> {
    const q = status ? `?status=${status}` : '';
    return this.http.get<Business[]>(`${this.base}/admin/businesses${q}`);
  }
  suspendBusiness(id: number, reason: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/admin/businesses/${id}/suspend`, JSON.stringify(reason));
  }
  reinstateBusiness(id: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/admin/businesses/${id}/reinstate`, {});
  }

  // Notifications
  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.base}/admin/notifications`);
  }
  broadcastNotification(targetRole: string, message: string): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(
      `${this.base}/admin/notifications/broadcast?targetRole=${encodeURIComponent(targetRole)}`,
      JSON.stringify(message)
    );
  }

  // Reports
  getReports(): Observable<Report[]> {
    return this.http.get<Report[]>(`${this.base}/admin/reports`);
  }
  generateReport(req: { reportName: string; reportType: string; startDate?: string; endDate?: string }): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/admin/reports`, req);
  }
  downloadReport(id: number): Observable<Blob> {
    return this.http.get(`${this.base}/admin/reports/${id}/download`, { responseType: 'blob' });
  }

  // System logs
  getSystemLogs(count: number = 100): Observable<SystemLog[]> {
    return this.http.get<SystemLog[]>(`${this.base}/admin/system-logs?count=${count}`);
  }
}
