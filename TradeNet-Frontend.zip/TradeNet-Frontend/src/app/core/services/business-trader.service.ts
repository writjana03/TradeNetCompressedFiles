import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  BusinessTrader, Business, BusinessRegistrationRequest, TraderDocument,
  BusinessDocument, TradeLicense, LicenseApplication, LicenseApplyRequest,
  Transaction, TransactionCreateRequest, Subsidy, TradeProgram, Complaint,
  Notification, BusinessTraderDashboard, ApiResponse
} from '../models/index';

@Injectable({ providedIn: 'root' })
export class BusinessTraderService {
  private base = environment.apis.businessTrader;

  constructor(private http: HttpClient) {}

  // Dashboard
  getDashboard(): Observable<BusinessTraderDashboard> {
    return this.http.get<BusinessTraderDashboard>(`${this.base}/business-trader/dashboard`);
  }

  // Profile
  getProfile(): Observable<BusinessTrader> {
    return this.http.get<BusinessTrader>(`${this.base}/business-trader/profile`);
  }
  updateProfile(profile: Partial<BusinessTrader>): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/business-trader/profile`, profile);
  }

  // Trader Documents
  getMyDocuments(): Observable<TraderDocument[]> {
    return this.http.get<TraderDocument[]>(`${this.base}/business-trader/documents`);
  }
  uploadDocument(file: File, documentType: string): Observable<ApiResponse> {
    const fd = new FormData();
    fd.append('File', file);
    fd.append('DocumentType', documentType);
    return this.http.post<ApiResponse>(`${this.base}/business-trader/documents/upload`, fd);
  }

  // Businesses
  getMyBusinesses(): Observable<Business[]> {
    return this.http.get<Business[]>(`${this.base}/business-trader/businesses`);
  }
  registerBusiness(req: BusinessRegistrationRequest): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/business-trader/businesses`, req);
  }
  getBusiness(id: number): Observable<Business> {
    return this.http.get<Business>(`${this.base}/business-trader/businesses/${id}`);
  }
  updateBusiness(id: number, biz: Partial<Business>): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/business-trader/businesses/${id}`, biz);
  }
  getBusinessDocuments(id: number): Observable<BusinessDocument[]> {
    return this.http.get<BusinessDocument[]>(`${this.base}/business-trader/businesses/${id}/documents`);
  }
  uploadBusinessDocument(id: number, file: File, documentType: string): Observable<ApiResponse> {
    const fd = new FormData();
    fd.append('File', file);
    fd.append('DocumentType', documentType);
    return this.http.post<ApiResponse>(`${this.base}/business-trader/businesses/${id}/documents/upload`, fd);
  }

  // Licenses
  searchLicenses(keyword?: string, licenseType?: string, category?: string): Observable<{ licenses: TradeLicense[] }> {
    const params = new URLSearchParams();
    if (keyword) params.append('keyword', keyword);
    if (licenseType) params.append('licenseType', licenseType);
    if (category) params.append('category', category);
    return this.http.get<{ licenses: TradeLicense[] }>(`${this.base}/business-trader/licenses/search?${params}`);
  }
  getAllLicenses(): Observable<TradeLicense[]> {
    return this.http.get<TradeLicense[]>(`${this.base}/business-trader/licenses`);
  }
  applyForLicense(licenseId: number, req: LicenseApplyRequest): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/business-trader/licenses/${licenseId}/apply`, req);
  }

  // Applications
  getMyApplications(): Observable<LicenseApplication[]> {
    return this.http.get<LicenseApplication[]>(`${this.base}/business-trader/applications`);
  }
  withdrawApplication(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(`${this.base}/business-trader/applications/${id}`);
  }

  // Transactions
  getMyTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.base}/business-trader/transactions`);
  }
  createTransaction(req: TransactionCreateRequest): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/business-trader/transactions`, req);
  }

  // Subsidies
  getMySubsidies(): Observable<Subsidy[]> {
    return this.http.get<Subsidy[]>(`${this.base}/business-trader/subsidies`);
  }
  applyForSubsidy(programId: number): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/business-trader/subsidies/apply/${programId}`, {});
  }

  // Programs (read-only)
  getPrograms(): Observable<TradeProgram[]> {
    return this.http.get<TradeProgram[]>(`${this.base}/business-trader/programs`);
  }

  // Complaints
  getMyComplaints(): Observable<Complaint[]> {
    return this.http.get<Complaint[]>(`${this.base}/business-trader/complaints`);
  }
  raiseComplaint(businessId: number | null, description: string): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/business-trader/complaints`, { businessId, description });
  }

  // Notifications
  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.base}/business-trader/notifications`);
  }
}
