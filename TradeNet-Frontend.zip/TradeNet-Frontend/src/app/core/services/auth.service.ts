import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuthResponse, LoginRequest, RegisterRequest } from '../models/index';

interface BackendLoginResponse {
  token: string; userId: number; fullName: string; email: string; role: string;
  expiresAt?: string;
  Token?: string; UserId?: number; FullName?: string; Email?: string; Role?: string;
}

const STORAGE_KEY = 'tnet_user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  // Admin API (7001) is the single auth gateway for ALL roles
  private loginUrl    = `${environment.apis.admin}/auth/login`;
  private registerUrl = `${environment.apis.admin}/auth/register`;

  private _user = signal<AuthResponse | null>(this._loadUser());

  readonly currentUser = computed(() => this._user());
  readonly isLoggedIn  = computed(() => {
    const u = this._user();
    return !!(u?.token && u.token.length > 0 && u.role && u.role.length > 0);
  });
  readonly role     = computed(() => this._user()?.role ?? '');
  readonly userId   = computed(() => this._user()?.userId ?? 0);
  readonly fullName = computed(() => this._user()?.fullName ?? '');
  readonly token    = computed(() => this._user()?.token ?? '');
  readonly initials = computed(() =>
    this.fullName().split(' ').map(w => w[0] ?? '').join('').slice(0, 2).toUpperCase()
  );
  readonly accentColor = computed(() => {
    const map: Record<string, string> = {
      BusinessTrader:    '#0ea5e9',
      TradeOfficer:      '#f59e0b',
      ProgramManager:    '#ec4899',
      SystemAdmin:       '#ef4444',
      ComplianceOfficer: '#10b981',
      GovernmentAuditor: '#6366f1',
    };
    return map[this.role()] ?? '#64748b';
  });
  readonly roleLabel = computed(() => {
    const map: Record<string, string> = {
      BusinessTrader:    'Business / Trader',
      TradeOfficer:      'Trade Officer',
      ProgramManager:    'Program Manager',
      SystemAdmin:       'Administrator',
      ComplianceOfficer: 'Compliance Officer',
      GovernmentAuditor: 'Government Auditor',
    };
    return map[this.role()] ?? this.role();
  });

  constructor(private http: HttpClient, private router: Router) {}

  login(req: LoginRequest): Observable<AuthResponse> {
    return this.http
      .post<BackendLoginResponse>(this.loginUrl, {
        email: req.email, password: req.password,
        Email: req.email, Password: req.password,
      })
      .pipe(
        tap((res: BackendLoginResponse) => {
          const user: AuthResponse = {
            token:    res.token    || res.Token    || '',
            userId:   res.userId   ?? res.UserId   ?? 0,
            fullName: res.fullName || res.FullName || '',
            email:    res.email    || res.Email    || '',
            role:     res.role     || res.Role     || '',
          };
          if (!user.token) throw new Error('Login response did not include a token.');
          if (!user.role) throw new Error('Login response did not include a role.');
          this._persist(user);
        })
      ) as Observable<AuthResponse>;
  }

  register(req: RegisterRequest): Observable<{ message?: string; Message?: string }> {
    return this.http.post<{ message?: string; Message?: string }>(this.registerUrl, {
      fullName: req.fullName, email: req.email, password: req.password,
      role: req.role, phone: req.phone ?? null,
      FullName: req.fullName, Email: req.email, Password: req.password,
      Role: req.role, Phone: req.phone ?? null,
    });
  }

  redirectToDashboard(): void {
    const dashMap: Record<string, string> = {
      BusinessTrader:    '/business-trader/dashboard',
      TradeOfficer:      '/trade-officer/dashboard',
      ProgramManager:    '/program-manager/dashboard',
      SystemAdmin:       '/admin/dashboard',
      ComplianceOfficer: '/compliance-officer/dashboard',
      GovernmentAuditor: '/gov-auditor/dashboard',
    };
    const dest = dashMap[this.role()];
    if (!dest) { this.router.navigate(['/home']); return; }
    this.router.navigate([dest]);
  }

  logout(): void {
    localStorage.removeItem(STORAGE_KEY);
    this._user.set(null);
    this.router.navigate(['/login']);
  }

  private _persist(user: AuthResponse): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    this._user.set(user);
  }

  private _loadUser(): AuthResponse | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const u: AuthResponse = JSON.parse(raw);
      return (u?.token && u.role) ? u : null;
    } catch { return null; }
  }
}
