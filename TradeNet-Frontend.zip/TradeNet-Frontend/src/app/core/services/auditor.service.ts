import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  Audit, ComplianceRecord, TradeProgram, Report, Business, Notification,
  AuditorDashboard, ApiResponse
} from '../models/index';

@Injectable({ providedIn: 'root' })
export class AuditorService {
  private base = environment.apis.govAuditor;

  constructor(private http: HttpClient) {}

  getDashboard(): Observable<AuditorDashboard> {
    return this.http.get<AuditorDashboard>(`${this.base}/gov-auditor/dashboard`);
  }

  // Audits
  getAudits(): Observable<Audit[]> {
    return this.http.get<Audit[]>(`${this.base}/gov-auditor/audits`);
  }
  getAudit(id: number): Observable<Audit> {
    return this.http.get<Audit>(`${this.base}/gov-auditor/audits/${id}`);
  }
  createAudit(req: { title: string; scope: string; findings: string }): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/gov-auditor/audits`, req);
  }
  updateAuditStatus(id: number, newStatus: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/gov-auditor/audits/${id}/status`, JSON.stringify(newStatus));
  }
  recordFindings(id: number, findings: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/gov-auditor/audits/${id}/findings`, JSON.stringify(findings));
  }

  // Compliance
  getCompliance(): Observable<ComplianceRecord[]> {
    return this.http.get<ComplianceRecord[]>(`${this.base}/gov-auditor/compliance`);
  }
  escalate(entityId: number, entityType: string, notes: string): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/gov-auditor/compliance/escalate`, { entityId, entityType, notes });
  }

  // Programs
  getPrograms(): Observable<TradeProgram[]> {
    return this.http.get<TradeProgram[]>(`${this.base}/gov-auditor/programs`);
  }
  flagProgram(id: number, reason: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/gov-auditor/programs/${id}/flag`, JSON.stringify(reason));
  }

  // Reports
  getReports(): Observable<Report[]> {
    return this.http.get<Report[]>(`${this.base}/gov-auditor/reports`);
  }
  generateReport(req: { reportName: string; reportType: string; content: string }): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/gov-auditor/reports`, req);
  }

  // Businesses
  getBusinesses(): Observable<Business[]> {
    return this.http.get<Business[]>(`${this.base}/gov-auditor/businesses`);
  }

  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.base}/gov-auditor/notifications`);
  }
}
