import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  Business, Complaint, ComplianceRecord, Violation, Notification,
  ComplianceDashboard, ApiResponse
} from '../models/index';

@Injectable({ providedIn: 'root' })
export class ComplianceService {
  private base = environment.apis.compliance;

  constructor(private http: HttpClient) {}

  getDashboard(): Observable<ComplianceDashboard> {
    return this.http.get<ComplianceDashboard>(`${this.base}/compliance-officer/dashboard`);
  }

  // Businesses
  getBusinesses(status?: string): Observable<Business[]> {
    const q = status ? `?status=${status}` : '';
    return this.http.get<Business[]>(`${this.base}/compliance-officer/businesses${q}`);
  }
  getBusiness(id: number): Observable<Business> {
    return this.http.get<Business>(`${this.base}/compliance-officer/businesses/${id}`);
  }
  flagBusiness(id: number, reason: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/compliance-officer/businesses/${id}/flag`, JSON.stringify(reason));
  }
  clearBusinessFlag(id: number, notes: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/compliance-officer/businesses/${id}/clear`, JSON.stringify(notes));
  }

  // Complaints
  getComplaints(): Observable<Complaint[]> {
    return this.http.get<Complaint[]>(`${this.base}/compliance-officer/complaints`);
  }
  resolveComplaint(id: number, resolution: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/compliance-officer/complaints/${id}/resolve`, JSON.stringify(resolution));
  }

  // Compliance Records
  getRecords(): Observable<ComplianceRecord[]> {
    return this.http.get<ComplianceRecord[]>(`${this.base}/compliance-officer/compliance-records`);
  }
  createRecord(r: Partial<ComplianceRecord>): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/compliance-officer/compliance-records`, r);
  }
  updateRecord(id: number, result: string, notes: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/compliance-officer/compliance-records/${id}`, { result, notes });
  }

  // Violations
  getViolations(): Observable<Violation[]> {
    return this.http.get<Violation[]>(`${this.base}/compliance-officer/violations`);
  }
  createViolation(v: Partial<Violation>): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/compliance-officer/violations`, v);
  }

  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.base}/compliance-officer/notifications`);
  }
}
