import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  TradeProgram, Resource, Subsidy, Notification,
  ProgramManagerDashboard, ApiResponse
} from '../models/index';

@Injectable({ providedIn: 'root' })
export class ProgramManagerService {
  private base = environment.apis.programManager;

  constructor(private http: HttpClient) {}

  getDashboard(): Observable<ProgramManagerDashboard> {
    return this.http.get<ProgramManagerDashboard>(`${this.base}/program-manager/dashboard`);
  }

  // Programs
  getPrograms(): Observable<TradeProgram[]> {
    return this.http.get<TradeProgram[]>(`${this.base}/program-manager/programs`);
  }
  getProgram(id: number): Observable<TradeProgram> {
    return this.http.get<TradeProgram>(`${this.base}/program-manager/programs/${id}`);
  }
  createProgram(p: Partial<TradeProgram>): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/program-manager/programs`, p);
  }
  updateProgram(id: number, p: Partial<TradeProgram>): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/program-manager/programs/${id}`, p);
  }
  deleteProgram(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(`${this.base}/program-manager/programs/${id}`);
  }

  // Resources
  getResources(programId?: number): Observable<Resource[]> {
    const q = programId ? `?programId=${programId}` : '';
    return this.http.get<Resource[]>(`${this.base}/program-manager/resources${q}`);
  }
  createResource(r: Partial<Resource>): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.base}/program-manager/resources`, r);
  }
  updateResource(id: number, r: Partial<Resource>): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/program-manager/resources/${id}`, r);
  }
  deleteResource(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(`${this.base}/program-manager/resources/${id}`);
  }

  // Subsidies
  getPendingSubsidies(): Observable<Subsidy[]> {
    return this.http.get<Subsidy[]>(`${this.base}/program-manager/subsidies/pending`);
  }
  approveSubsidy(id: number, amount: number): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/program-manager/subsidies/${id}/approve`, { amount });
  }
  rejectSubsidy(id: number, reason: string): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(`${this.base}/program-manager/subsidies/${id}/reject`, JSON.stringify(reason));
  }

  // Budget
  getBudgetMonitoring(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/program-manager/budget-monitoring`);
  }

  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.base}/program-manager/notifications`);
  }
}
