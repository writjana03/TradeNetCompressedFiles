import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { TradeOfficerService } from '../../../../core/services/trade-officer.service';
import { AuthService } from '../../../../core/services/auth.service';
import { TradeOfficerDashboard } from '../../../../core/models';

@Component({
  selector: 'app-to-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class TODashboardComponent {
  private to = inject(TradeOfficerService);
  auth = inject(AuthService);
  loading = signal(true);
  dashboard = signal<TradeOfficerDashboard | null>(null);
  error = signal('');

  ngOnInit() {
    this.to.getDashboard().subscribe({
      next: d => { this.dashboard.set(d); this.loading.set(false); },
      error: e => { this.error.set(e?.error?.message || 'Failed.'); this.loading.set(false); }
    });
  }
}
