import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TradeOfficerService } from '../../../../core/services/trade-officer.service';
import { Transaction } from '../../../../core/models';

@Component({
  selector: 'app-to-transactions-monitor',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './transactions-monitor.component.html',
  styleUrl: './transactions-monitor.component.css',
})
export class TOTransactionsMonitorComponent {
  private to = inject(TradeOfficerService);
  transactions = signal<Transaction[]>([]);
  loading = signal(true);
  tab = signal<'all'|'suspicious'>('all');
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    const source = this.tab() === 'all' ? this.to.getTransactions() : this.to.getSuspiciousTransactions();
    source.subscribe({
      next: t => { this.transactions.set(t); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  switchTab(t: 'all'|'suspicious') { this.tab.set(t); this.load(); }

  flag(id: number) {
    const notes = prompt('Reason to flag?');
    if (!notes) return;
    this.to.flagTransaction(id, notes).subscribe({ next: () => { this.message.set('Flagged.'); this.load(); } });
  }
  clear(id: number) {
    this.to.clearTransactionFlag(id).subscribe({ next: () => { this.message.set('Cleared.'); this.load(); } });
  }
}
