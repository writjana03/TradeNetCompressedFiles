import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TradeOfficerService } from '../../../../core/services/trade-officer.service';
import { Business } from '../../../../core/models';

@Component({
  selector: 'app-to-business-verifications',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './business-verifications.component.html',
  styleUrl: './business-verifications.component.css',
})
export class TOBusinessVerificationsComponent {
  private to = inject(TradeOfficerService);
  businesses = signal<Business[]>([]);
  loading = signal(true);
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.to.getBusinesses().subscribe({
      next: b => { this.businesses.set(b); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  verify(id: number) {
    this.to.verifyBusiness(id).subscribe({ next: () => { this.message.set('Verified.'); this.load(); } });
  }

  reject(id: number) {
    const reason = prompt('Reason for rejection?');
    if (!reason) return;
    this.to.rejectBusiness(id, reason).subscribe({ next: () => { this.message.set('Rejected.'); this.load(); } });
  }
}
