import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TradeOfficerService } from '../../../../core/services/trade-officer.service';
import { LicenseApplication } from '../../../../core/models';

@Component({
  selector: 'app-to-applications',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './applications.component.html',
  styleUrl: './applications.component.css',
})
export class TOApplicationsComponent {
  private to = inject(TradeOfficerService);
  applications = signal<LicenseApplication[]>([]);
  loading = signal(true);
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.to.getPendingApplications().subscribe({
      next: a => { this.applications.set(a); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  approve(a: LicenseApplication) {
    const expiry = prompt('Expiry date (YYYY-MM-DD, blank = 1 year):');
    if (expiry === null) return;
    const notes = prompt('Approval notes (optional):') || '';
    this.to.approveApplication(a.id, expiry || undefined, notes).subscribe({
      next: () => { this.message.set('Approved.'); this.load(); }
    });
  }

  reject(a: LicenseApplication) {
    const reason = prompt('Reason for rejection?');
    if (!reason) return;
    this.to.rejectApplication(a.id, reason).subscribe({
      next: () => { this.message.set('Rejected.'); this.load(); }
    });
  }
}
