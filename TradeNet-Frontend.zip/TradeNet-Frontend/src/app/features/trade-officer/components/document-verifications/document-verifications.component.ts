import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TradeOfficerService } from '../../../../core/services/trade-officer.service';
import { TraderDocument, BusinessDocument } from '../../../../core/models';

@Component({
  selector: 'app-to-document-verifications',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './document-verifications.component.html',
  styleUrl: './document-verifications.component.css',
})
export class TODocumentVerificationsComponent {
  private to = inject(TradeOfficerService);
  traderDocs = signal<TraderDocument[]>([]);
  bizDocs = signal<BusinessDocument[]>([]);
  loading = signal(true);
  tab = signal<'trader'|'business'>('trader');
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.to.getPendingTraderDocs().subscribe(d => this.traderDocs.set(d));
    this.to.getPendingBusinessDocs().subscribe({
      next: d => { this.bizDocs.set(d); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  verifyTrader(id: number) {
    this.to.verifyTraderDoc(id).subscribe({ next: () => { this.message.set('Verified.'); this.load(); } });
  }
  rejectTrader(id: number) {
    const reason = prompt('Reason for rejection?');
    if (!reason) return;
    this.to.rejectTraderDoc(id, reason).subscribe({ next: () => { this.message.set('Rejected.'); this.load(); } });
  }
  verifyBusiness(id: number) {
    this.to.verifyBusinessDoc(id).subscribe({ next: () => { this.message.set('Verified.'); this.load(); } });
  }
  rejectBusiness(id: number) {
    const reason = prompt('Reason for rejection?');
    if (!reason) return;
    this.to.rejectBusinessDoc(id, reason).subscribe({ next: () => { this.message.set('Rejected.'); this.load(); } });
  }
}
