import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuditorService } from '../../../../core/services/auditor.service';
import { ComplianceRecord } from '../../../../core/models';

@Component({
  selector: 'app-ga-compliance-monitoring',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './compliance-monitoring.component.html',
  styleUrl: './compliance-monitoring.component.css',
})
export class GAComplianceMonitoringComponent {
  private ga = inject(AuditorService);
  records = signal<ComplianceRecord[]>([]);
  loading = signal(true);
  message = signal('');

  ngOnInit() { this.load(); }
  load() {
    this.ga.getCompliance().subscribe({
      next: r => { this.records.set(r); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  escalate(r: ComplianceRecord) {
    const notes = prompt(`Escalation notes for ${r.type} #${r.entityId}:`);
    if (!notes) return;
    this.ga.escalate(r.entityId, r.type, notes).subscribe({ next: () => { this.message.set('Escalated.'); this.load(); } });
  }
}
