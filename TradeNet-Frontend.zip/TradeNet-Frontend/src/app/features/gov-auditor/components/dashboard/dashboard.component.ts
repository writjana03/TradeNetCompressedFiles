import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuditorService } from '../../../../core/services/auditor.service';
import { AuthService } from '../../../../core/services/auth.service';
import { AuditorDashboard } from '../../../../core/models';

@Component({
  selector: 'app-ga-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class GADashboardComponent {
  private ga = inject(AuditorService);
  auth = inject(AuthService);
  loading = signal(true);
  dashboard = signal<AuditorDashboard | null>(null);
  error = signal('');

  ngOnInit() {
    this.ga.getDashboard().subscribe({
      next: d => { this.dashboard.set(d); this.loading.set(false); },
      error: e => { this.error.set(e?.error?.message || 'Failed.'); this.loading.set(false); }
    });
  }
}
