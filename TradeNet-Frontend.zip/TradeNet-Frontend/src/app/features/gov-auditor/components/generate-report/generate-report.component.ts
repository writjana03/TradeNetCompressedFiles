import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuditorService } from '../../../../core/services/auditor.service';
import { Report } from '../../../../core/models';

@Component({
  selector: 'app-generate-report',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './generate-report.component.html',
  styleUrl: './generate-report.component.css',
})
export class GenerateReportComponent {
  private ga = inject(AuditorService);
  reports = signal<Report[]>([]);
  loading = signal(true);
  message = signal('');
  newReport = { reportName: '', reportType: 'AuditSummary', content: '' };
  types = ['AuditSummary', 'ComplianceReview', 'ProgramAnalysis', 'BusinessAudit'];

  ngOnInit() { this.load(); }
  load() {
    this.ga.getReports().subscribe({
      next: r => { this.reports.set(r); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  generate() {
    if (!this.newReport.reportName) { this.message.set('Name required.'); return; }
    this.ga.generateReport(this.newReport).subscribe({
      next: () => { this.message.set('Report generated.'); this.newReport = { reportName: '', reportType: 'AuditSummary', content: '' }; this.load(); }
    });
  }
}
