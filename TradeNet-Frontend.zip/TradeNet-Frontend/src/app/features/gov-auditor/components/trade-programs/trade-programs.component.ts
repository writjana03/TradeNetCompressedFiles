import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuditorService } from '../../../../core/services/auditor.service';
import { TradeProgram } from '../../../../core/models';

@Component({
  selector: 'app-ga-trade-programs',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trade-programs.component.html',
  styleUrl: './trade-programs.component.css',
})
export class GATradeProgramsComponent {
  private ga = inject(AuditorService);
  programs = signal<TradeProgram[]>([]);
  loading = signal(true);
  message = signal('');

  ngOnInit() { this.load(); }
  load() {
    this.ga.getPrograms().subscribe({
      next: p => { this.programs.set(p); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  flag(p: TradeProgram) {
    const reason = prompt(`Reason for flagging "${p.programName}":`);
    if (!reason) return;
    this.ga.flagProgram(p.id, reason).subscribe({ next: () => { this.message.set('Flagged for review.'); this.load(); } });
  }
}
