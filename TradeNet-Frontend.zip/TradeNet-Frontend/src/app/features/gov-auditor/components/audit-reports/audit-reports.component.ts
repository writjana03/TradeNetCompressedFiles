import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuditorService } from '../../../../core/services/auditor.service';
import { Audit } from '../../../../core/models';

@Component({
  selector: 'app-audit-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './audit-reports.component.html',
  styleUrl: './audit-reports.component.css',
})
export class AuditReportsComponent {
  private ga = inject(AuditorService);
  audits = signal<Audit[]>([]);
  loading = signal(true);
  message = signal('');
  newAudit = { title: '', scope: 'Business', findings: '' };
  scopes = ['Business', 'Transaction', 'Program', 'License'];

  ngOnInit() { this.load(); }
  load() {
    this.ga.getAudits().subscribe({
      next: a => { this.audits.set(a); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  create() {
    if (!this.newAudit.title) { this.message.set('Title required.'); return; }
    this.ga.createAudit(this.newAudit).subscribe({
      next: () => { this.message.set('Audit created.'); this.newAudit = { title: '', scope: 'Business', findings: '' }; this.load(); }
    });
  }

  updateStatus(a: Audit) {
    const status = prompt('New status (Open / InProgress / Completed):', a.status);
    if (!status) return;
    this.ga.updateAuditStatus(a.id, status).subscribe({ next: () => { this.message.set('Updated.'); this.load(); } });
  }

  addFindings(a: Audit) {
    const findings = prompt('Findings:', a.findings || '');
    if (findings === null) return;
    this.ga.recordFindings(a.id, findings).subscribe({ next: () => { this.message.set('Findings saved.'); this.load(); } });
  }
}
