import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  auth = inject(AuthService);

  roles = [
    { name: 'Business / Trader',  icon: 'bi-shop-window',        color: '#0ea5e9', desc: 'Register your business, apply for licenses, manage transactions and subsidies.' },
    { name: 'Trade Officer',      icon: 'bi-shield-check',       color: '#f59e0b', desc: 'Verify documents, approve license applications, and monitor transactions.' },
    { name: 'Program Manager',    icon: 'bi-kanban',             color: '#ec4899', desc: 'Design trade programs, allocate resources, and approve subsidies.' },
    { name: 'Administrator',      icon: 'bi-gear-fill',          color: '#ef4444', desc: 'Manage users, oversee businesses, and generate system reports.' },
    { name: 'Compliance Officer', icon: 'bi-clipboard-check',    color: '#10b981', desc: 'Review compliance, investigate complaints, and record violations.' },
    { name: 'Government Auditor', icon: 'bi-file-earmark-text',  color: '#6366f1', desc: 'Audit businesses and programs; escalate compliance issues.' },
  ];
}
