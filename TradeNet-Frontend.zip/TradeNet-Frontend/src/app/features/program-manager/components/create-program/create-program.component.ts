import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ProgramManagerService } from '../../../../core/services/program-manager.service';

@Component({
  selector: 'app-create-program',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './create-program.component.html',
  styleUrl: './create-program.component.css',
})
export class CreateProgramComponent {
  private fb = inject(FormBuilder);
  private pm = inject(ProgramManagerService);
  private router = inject(Router);

  loading = signal(false);
  error = signal('');
  submitted = false;

  form = this.fb.group({
    programName: ['', [Validators.required, Validators.minLength(3)]],
    description: [''],
    programType: ['ExportPromotion', Validators.required],
    totalBudget: [0, [Validators.required, Validators.min(0)]],
    startDate: [new Date().toISOString().substr(0,10), Validators.required],
    endDate: [''],
    eligibilityCriteria: [''],
    status: ['Active', Validators.required],
  });
  get f() { return this.form.controls; }
  types = ['ExportPromotion', 'Subsidy', 'FinancialSupport', 'TradeFacilitation'];

  onSubmit() {
    this.submitted = true;
    if (this.form.invalid) return;
    this.loading.set(true);
    this.pm.createProgram(this.form.value as any).subscribe({
      next: () => { this.loading.set(false); this.router.navigate(['/program-manager/program-management']); },
      error: e => { this.loading.set(false); this.error.set(e?.error?.message || 'Failed.'); }
    });
  }
}
