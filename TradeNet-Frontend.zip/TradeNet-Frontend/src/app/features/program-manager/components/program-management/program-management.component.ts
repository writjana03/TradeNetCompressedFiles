import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ProgramManagerService } from '../../../../core/services/program-manager.service';
import { TradeProgram } from '../../../../core/models';

@Component({
  selector: 'app-program-management',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './program-management.component.html',
  styleUrl: './program-management.component.css',
})
export class ProgramManagementComponent {
  private pm = inject(ProgramManagerService);
  programs = signal<TradeProgram[]>([]);
  loading = signal(true);

  ngOnInit() { this.load(); }
  load() {
    this.pm.getPrograms().subscribe({
      next: p => { this.programs.set(p); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
  remove(id: number) {
    if (!confirm('Delete this program?')) return;
    this.pm.deleteProgram(id).subscribe({ next: () => this.load() });
  }
}
