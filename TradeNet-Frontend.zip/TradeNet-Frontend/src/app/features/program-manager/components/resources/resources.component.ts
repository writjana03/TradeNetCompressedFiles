import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProgramManagerService } from '../../../../core/services/program-manager.service';
import { Resource, TradeProgram } from '../../../../core/models';

@Component({
  selector: 'app-pm-resources',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './resources.component.html',
  styleUrl: './resources.component.css',
})
export class PMResourcesComponent {
  private pm = inject(ProgramManagerService);
  resources = signal<Resource[]>([]);
  programs = signal<TradeProgram[]>([]);
  loading = signal(true);
  message = signal('');
  newResource: Partial<Resource> = { type: 'Funds', name: '', quantity: 0, status: 'Available', tradeProgramId: 0 };

  ngOnInit() { this.load(); }

  load() {
    this.pm.getPrograms().subscribe(p => this.programs.set(p));
    this.pm.getResources().subscribe({
      next: r => { this.resources.set(r); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  create() {
    if (!this.newResource.tradeProgramId) { this.message.set('Select a program.'); return; }
    this.pm.createResource(this.newResource).subscribe({
      next: () => { this.message.set('Resource added.'); this.newResource = { type: 'Funds', name: '', quantity: 0, status: 'Available', tradeProgramId: 0 }; this.load(); },
      error: e => this.message.set(e?.error?.message || 'Failed.'),
    });
  }

  remove(id: number) {
    if (!confirm('Delete this resource?')) return;
    this.pm.deleteResource(id).subscribe({ next: () => this.load() });
  }
}
