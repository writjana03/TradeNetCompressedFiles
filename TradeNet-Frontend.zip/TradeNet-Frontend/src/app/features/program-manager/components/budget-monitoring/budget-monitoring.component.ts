import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgramManagerService } from '../../../../core/services/program-manager.service';

@Component({
  selector: 'app-budget-monitoring',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './budget-monitoring.component.html',
  styleUrl: './budget-monitoring.component.css',
})
export class BudgetMonitoringComponent {
  private pm = inject(ProgramManagerService);
  programs = signal<any[]>([]);
  loading = signal(true);

  ngOnInit() {
    this.pm.getBudgetMonitoring().subscribe({
      next: p => { this.programs.set(p); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
}
