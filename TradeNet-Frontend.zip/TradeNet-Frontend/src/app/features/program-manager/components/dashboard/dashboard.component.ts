import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ProgramManagerService } from '../../../../core/services/program-manager.service';
import { AuthService } from '../../../../core/services/auth.service';
import { ProgramManagerDashboard } from '../../../../core/models';

@Component({
  selector: 'app-pm-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class PMDashboardComponent {
  private pm = inject(ProgramManagerService);
  auth = inject(AuthService);
  loading = signal(true);
  dashboard = signal<ProgramManagerDashboard | null>(null);
  error = signal('');

  ngOnInit() {
    this.pm.getDashboard().subscribe({
      next: d => { this.dashboard.set(d); this.loading.set(false); },
      error: e => { this.error.set(e?.error?.message || 'Failed.'); this.loading.set(false); }
    });
  }
}
