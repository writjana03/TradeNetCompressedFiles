import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ProgramManagerService } from '../../../../core/services/program-manager.service';
import { TradeProgram } from '../../../../core/models';

@Component({
  selector: 'app-edit-program',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './edit-program.component.html',
  styleUrl: './edit-program.component.css',
})
export class EditProgramComponent {
  private pm = inject(ProgramManagerService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  programId = 0;
  program = signal<TradeProgram | null>(null);
  loading = signal(true);
  error = signal('');
  message = signal('');

  ngOnInit() {
    this.programId = Number(this.route.snapshot.paramMap.get('id'));
    this.pm.getProgram(this.programId).subscribe({
      next: p => { this.program.set(p); this.loading.set(false); },
      error: () => { this.error.set('Program not found.'); this.loading.set(false); }
    });
  }

  save() {
    const p = this.program(); if (!p) return;
    this.pm.updateProgram(this.programId, p).subscribe({
      next: () => { this.message.set('Saved.'); setTimeout(() => this.router.navigate(['/program-manager/program-management']), 800); },
      error: e => this.error.set(e?.error?.message || 'Failed.'),
    });
  }
}
