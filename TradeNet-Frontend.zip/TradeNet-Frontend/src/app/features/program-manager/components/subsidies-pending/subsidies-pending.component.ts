import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgramManagerService } from '../../../../core/services/program-manager.service';
import { Subsidy } from '../../../../core/models';

@Component({
  selector: 'app-subsidies-pending',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './subsidies-pending.component.html',
  styleUrl: './subsidies-pending.component.css',
})
export class SubsidiesPendingComponent {
  private pm = inject(ProgramManagerService);
  subsidies = signal<Subsidy[]>([]);
  loading = signal(true);
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.pm.getPendingSubsidies().subscribe({
      next: s => { this.subsidies.set(s); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  approve(s: Subsidy) {
    const amount = prompt(`Approve subsidy. Enter amount:`, '1000');
    if (!amount || isNaN(+amount)) return;
    this.pm.approveSubsidy(s.id, +amount).subscribe({ next: () => { this.message.set('Approved.'); this.load(); } });
  }
  reject(s: Subsidy) {
    const reason = prompt('Reason for rejection?');
    if (!reason) return;
    this.pm.rejectSubsidy(s.id, reason).subscribe({ next: () => { this.message.set('Rejected.'); this.load(); } });
  }
}
