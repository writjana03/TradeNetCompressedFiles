import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../../core/services/admin.service';
import { Business } from '../../../../core/models';

@Component({
  selector: 'app-admin-businesses',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './businesses.component.html',
  styleUrl: './businesses.component.css',
})
export class AdminBusinessesComponent {
  private admin = inject(AdminService);
  businesses = signal<Business[]>([]);
  loading = signal(true);
  filterStatus = '';
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.admin.getAllBusinesses(this.filterStatus || undefined).subscribe({
      next: b => { this.businesses.set(b); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  suspend(b: Business) {
    const reason = prompt(`Reason to suspend "${b.businessName}"?`);
    if (!reason) return;
    this.admin.suspendBusiness(b.id, reason).subscribe({
      next: () => { this.message.set('Business suspended.'); this.load(); }
    });
  }

  reinstate(b: Business) {
    if (!confirm(`Reinstate "${b.businessName}"?`)) return;
    this.admin.reinstateBusiness(b.id).subscribe({
      next: () => { this.message.set('Business reinstated.'); this.load(); }
    });
  }
}
