import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../../core/services/admin.service';
import { SystemLog } from '../../../../core/models';

@Component({
  selector: 'app-system-monitoring',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './system-monitoring.component.html',
  styleUrl: './system-monitoring.component.css',
})
export class SystemMonitoringComponent {
  private admin = inject(AdminService);
  logs = signal<SystemLog[]>([]);
  loading = signal(true);

  ngOnInit() {
    this.admin.getSystemLogs(200).subscribe({
      next: l => { this.logs.set(l); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
}
