import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AdminService } from '../../../../core/services/admin.service';
import { AuthService } from '../../../../core/services/auth.service';
import { AdminDashboard } from '../../../../core/models';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class AdminDashboardComponent {
  private admin = inject(AdminService);
  auth = inject(AuthService);

  loading = signal(true);
  error = signal('');
  dashboard = signal<AdminDashboard | null>(null);

  ngOnInit() {
    this.admin.getDashboard().subscribe({
      next: d => { this.dashboard.set(d); this.loading.set(false); },
      error: e => { this.error.set(e?.error?.message || 'Failed to load dashboard.'); this.loading.set(false); },
    });
  }
}
