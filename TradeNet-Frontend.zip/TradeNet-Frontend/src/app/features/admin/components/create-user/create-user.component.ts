import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AdminService } from '../../../../core/services/admin.service';

@Component({
  selector: 'app-create-user',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './create-user.component.html',
  styleUrl: './create-user.component.css',
})
export class CreateUserComponent {
  private fb = inject(FormBuilder);
  private admin = inject(AdminService);
  private router = inject(Router);

  loading = signal(false);
  error = signal('');
  success = signal('');
  submitted = false;

  form = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(3)]],
    email:    ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    role:     ['BusinessTrader', Validators.required],
    phone:    [''],
  });

  roles = ['BusinessTrader','TradeOfficer','ProgramManager','SystemAdmin','ComplianceOfficer','GovernmentAuditor'];
  get f() { return this.form.controls; }

  onSubmit() {
    this.submitted = true;
    this.error.set(''); this.success.set('');
    if (this.form.invalid) return;
    this.loading.set(true);
    this.admin.createUser({
      fullName: this.f.fullName.value!,
      email: this.f.email.value!,
      password: this.f.password.value!,
      role: this.f.role.value!,
      phone: this.f.phone.value || undefined,
    }).subscribe({
      next: () => {
        this.loading.set(false);
        this.success.set('User created.');
        setTimeout(() => this.router.navigate(['/admin/manage-users']), 1000);
      },
      error: (e) => { this.loading.set(false); this.error.set(e?.error?.message || 'Failed to create user.'); }
    });
  }
}
