import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AdminService } from '../../../../core/services/admin.service';
import { User } from '../../../../core/models';

@Component({
  selector: 'app-manage-users',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './manage-users.component.html',
  styleUrl: './manage-users.component.css',
})
export class ManageUsersComponent {
  private admin = inject(AdminService);
  users = signal<User[]>([]);
  loading = signal(true);

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.admin.getAllUsers().subscribe({
      next: u => { this.users.set(u); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  deactivate(id: number) {
    if (!confirm('Deactivate this user?')) return;
    this.admin.deactivateUser(id).subscribe({ next: () => this.load() });
  }
  activate(id: number) {
    this.admin.activateUser(id).subscribe({ next: () => this.load() });
  }
  remove(id: number) {
    if (!confirm('Delete this user permanently?')) return;
    this.admin.deleteUser(id).subscribe({ next: () => this.load() });
  }
}
