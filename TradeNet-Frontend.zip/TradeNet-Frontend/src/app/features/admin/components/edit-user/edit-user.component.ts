import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AdminService } from '../../../../core/services/admin.service';

@Component({
  selector: 'app-edit-user',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './edit-user.component.html',
  styleUrl: './edit-user.component.css',
})
export class EditUserComponent {
  private fb = inject(FormBuilder);
  private admin = inject(AdminService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  userId = 0;
  loading = signal(false);
  error = signal('');
  success = signal('');

  form = this.fb.group({
    fullName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    role: ['', Validators.required],
    status: ['Active', Validators.required],
    phone: [''],
    password: [''], // optional - empty means no change
  });

  roles = ['BusinessTrader','TradeOfficer','ProgramManager','SystemAdmin','ComplianceOfficer','GovernmentAuditor'];

  ngOnInit() {
    this.userId = Number(this.route.snapshot.paramMap.get('id'));
    this.admin.getUser(this.userId).subscribe({
      next: u => this.form.patchValue({ ...u, password: '' }),
      error: () => this.error.set('User not found.'),
    });
  }

  onSubmit() {
    if (this.form.invalid) return;
    this.loading.set(true);
    const payload: any = { ...this.form.value };
    if (!payload.password) delete payload.password;
    this.admin.updateUser(this.userId, payload).subscribe({
      next: () => {
        this.loading.set(false);
        this.success.set('Saved.');
        setTimeout(() => this.router.navigate(['/admin/manage-users']), 800);
      },
      error: (e) => { this.loading.set(false); this.error.set(e?.error?.message || 'Failed to update.'); }
    });
  }
}
