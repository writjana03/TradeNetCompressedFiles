import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../../core/services/admin.service';
import { Report } from '../../../../core/models';

@Component({
  selector: 'app-admin-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reports.component.html',
  styleUrl: './reports.component.css',
})
export class AdminReportsComponent {
  private admin = inject(AdminService);
  reports = signal<Report[]>([]);
  loading = signal(true);
  message = signal('');

  reportName = ''; reportType = 'UserActivity';
  startDate = ''; endDate = '';
  reportTypes = ['UserActivity', 'Compliance', 'Business'];

  ngOnInit() { this.load(); }

  load() {
    this.admin.getReports().subscribe({
      next: r => { this.reports.set(r); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  generate() {
    if (!this.reportName) { this.message.set('Report name required.'); return; }
    this.admin.generateReport({
      reportName: this.reportName, reportType: this.reportType,
      startDate: this.startDate || undefined, endDate: this.endDate || undefined,
    }).subscribe({
      next: () => { this.message.set('Report generated.'); this.reportName = ''; this.load(); },
      error: (e) => this.message.set(e?.error?.message || 'Failed to generate.'),
    });
  }

  download(id: number, name: string) {
    this.admin.downloadReport(id).subscribe({
      next: blob => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = `${name}.csv`;
        a.click(); URL.revokeObjectURL(url);
      }
    });
  }
}
