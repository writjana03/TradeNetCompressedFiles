import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { LicenseApplication } from '../../../../core/models';

@Component({
  selector: 'app-my-applications',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-applications.component.html',
  styleUrl: './my-applications.component.css',
})
export class MyApplicationsComponent {
  private bt = inject(BusinessTraderService);
  applications = signal<LicenseApplication[]>([]);
  loading = signal(true);
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.bt.getMyApplications().subscribe({
      next: a => { this.applications.set(a); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  withdraw(id: number) {
    if (!confirm('Withdraw this application?')) return;
    this.bt.withdrawApplication(id).subscribe({
      next: () => { this.message.set('Application withdrawn.'); this.load(); }
    });
  }
}
