import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { Business } from '../../../../core/models';

@Component({
  selector: 'app-bt-businesses',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './businesses.component.html',
  styleUrl: './businesses.component.css',
})
export class BTBusinessesComponent {
  private bt = inject(BusinessTraderService);
  businesses = signal<Business[]>([]);
  loading = signal(true);

  ngOnInit() {
    this.bt.getMyBusinesses().subscribe({
      next: b => { this.businesses.set(b); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
}
