import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { TradeLicense } from '../../../../core/models';

@Component({
  selector: 'app-license-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './license-search.component.html',
  styleUrl: './license-search.component.css',
})
export class LicenseSearchComponent {
  private bt = inject(BusinessTraderService);
  licenses = signal<TradeLicense[]>([]);
  loading = signal(false);
  message = signal('');
  keyword = ''; licenseType = ''; category = '';
  types = ['Import', 'Export', 'Local'];

  ngOnInit() { this.search(); }

  search() {
    this.loading.set(true);
    this.bt.searchLicenses(this.keyword, this.licenseType, this.category).subscribe({
      next: r => { this.licenses.set(r.licenses); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  apply(l: TradeLicense) {
    const notes = prompt(`Apply for "${l.title}"? Add any notes (optional):`);
    if (notes === null) return;
    this.bt.applyForLicense(l.id, { tradeLicenseId: l.id, applicationNotes: notes }).subscribe({
      next: r => this.message.set(r.message || 'Application submitted.'),
      error: e => this.message.set(e?.error?.message || 'Failed to apply.'),
    });
  }
}
