import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { BusinessTrader } from '../../../../core/models';

@Component({
  selector: 'app-bt-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css',
})
export class BTProfileComponent {
  private bt = inject(BusinessTraderService);
  profile = signal<BusinessTrader | null>(null);
  loading = signal(true);
  message = signal('');
  error = signal('');

  ngOnInit() {
    this.bt.getProfile().subscribe({
      next: p => { this.profile.set(p); this.loading.set(false); },
      error: e => {
        // Profile auto-created on first dashboard load; just inform user.
        this.error.set('Profile not yet set up. Visit your dashboard first to initialize.');
        this.loading.set(false);
      }
    });
  }

  save() {
    const p = this.profile();
    if (!p) return;
    this.bt.updateProfile(p).subscribe({
      next: () => this.message.set('Profile saved.'),
      error: e => this.error.set(e?.error?.message || 'Failed.'),
    });
  }
}
