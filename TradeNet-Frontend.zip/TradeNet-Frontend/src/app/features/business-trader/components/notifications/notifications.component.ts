import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { Notification } from '../../../../core/models';

@Component({
  selector: 'app-bt-notifications',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notifications.component.html',
  styleUrl: './notifications.component.css',
})
export class BTNotificationsComponent {
  private bt = inject(BusinessTraderService);
  notifications = signal<Notification[]>([]);
  loading = signal(true);

  ngOnInit() {
    this.bt.getNotifications().subscribe({
      next: n => { this.notifications.set(n); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
}
