import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';

@Component({
  selector: 'app-register-business',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register-business.component.html',
  styleUrl: './register-business.component.css',
})
export class RegisterBusinessComponent {
  private fb = inject(FormBuilder);
  private bt = inject(BusinessTraderService);
  private router = inject(Router);

  loading = signal(false);
  error = signal('');
  submitted = false;

  form = this.fb.group({
    businessName: ['', [Validators.required, Validators.minLength(3)]],
    businessType: ['Trader', Validators.required],
    address: [''],
    contactInfo: [''],
    phoneNumber: [''],
    description: [''],
  });
  get f() { return this.form.controls; }
  types = ['Trader', 'Importer', 'Exporter', 'Manufacturer', 'Retailer', 'Wholesaler'];

  onSubmit() {
    this.submitted = true;
    if (this.form.invalid) return;
    this.loading.set(true);
    this.bt.registerBusiness(this.form.value as any).subscribe({
      next: () => { this.loading.set(false); this.router.navigate(['/business-trader/businesses']); },
      error: e => { this.loading.set(false); this.error.set(e?.error?.message || 'Failed.'); }
    });
  }
}
