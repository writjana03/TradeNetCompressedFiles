import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { Transaction } from '../../../../core/models';

@Component({
  selector: 'app-my-transactions',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './my-transactions.component.html',
  styleUrl: './my-transactions.component.css',
})
export class MyTransactionsComponent {
  private bt = inject(BusinessTraderService);
  transactions = signal<Transaction[]>([]);
  loading = signal(true);

  ngOnInit() {
    this.bt.getMyTransactions().subscribe({
      next: t => { this.transactions.set(t); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }
}
