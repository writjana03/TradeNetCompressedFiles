import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { Subsidy, TradeProgram } from '../../../../core/models';

@Component({
  selector: 'app-bt-subsidies',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './subsidies.component.html',
  styleUrl: './subsidies.component.css',
})
export class BTSubsidiesComponent {
  private bt = inject(BusinessTraderService);
  subsidies = signal<Subsidy[]>([]);
  programs = signal<TradeProgram[]>([]);
  loading = signal(true);
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.bt.getMySubsidies().subscribe(s => this.subsidies.set(s));
    this.bt.getPrograms().subscribe({
      next: p => { this.programs.set(p); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  applyForSubsidy(programId: number, programName: string) {
    if (!confirm(`Apply for subsidy under "${programName}"?`)) return;
    this.bt.applyForSubsidy(programId).subscribe({
      next: () => { this.message.set('Subsidy application submitted.'); this.load(); },
      error: e => this.message.set(e?.error?.message || 'Failed.'),
    });
  }
}
