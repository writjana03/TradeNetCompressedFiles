import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { Complaint, Business } from '../../../../core/models';

@Component({
  selector: 'app-bt-complaints',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './complaints.component.html',
  styleUrl: './complaints.component.css',
})
export class BTComplaintsComponent {
  private bt = inject(BusinessTraderService);
  complaints = signal<Complaint[]>([]);
  businesses = signal<Business[]>([]);
  loading = signal(true);
  message = signal('');
  description = '';
  businessId: number | null = null;

  ngOnInit() { this.load(); }

  load() {
    this.bt.getMyComplaints().subscribe({
      next: c => { this.complaints.set(c); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
    this.bt.getMyBusinesses().subscribe(b => this.businesses.set(b));
  }

  submit() {
    if (!this.description) { this.message.set('Please describe the complaint.'); return; }
    this.bt.raiseComplaint(this.businessId, this.description).subscribe({
      next: () => {
        this.message.set('Complaint submitted.');
        this.description = ''; this.businessId = null;
        this.load();
      },
      error: e => this.message.set(e?.error?.message || 'Failed.'),
    });
  }
}
