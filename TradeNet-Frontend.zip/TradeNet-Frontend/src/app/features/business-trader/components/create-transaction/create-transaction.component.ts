import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { Business } from '../../../../core/models';

@Component({
  selector: 'app-create-transaction',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './create-transaction.component.html',
  styleUrl: './create-transaction.component.css',
})
export class CreateTransactionComponent {
  private fb = inject(FormBuilder);
  private bt = inject(BusinessTraderService);
  private router = inject(Router);

  businesses = signal<Business[]>([]);
  loading = signal(false);
  error = signal('');
  submitted = false;

  form = this.fb.group({
    businessId: [0, [Validators.required, Validators.min(1)]],
    transactionType: ['Sale', Validators.required],
    amount: [0, [Validators.required, Validators.min(0.01)]],
    counterparty: [''],
    invoiceNumber: [''],
    description: [''],
  });
  get f() { return this.form.controls; }
  types = ['Sale', 'Purchase', 'Import', 'Export'];

  ngOnInit() {
    this.bt.getMyBusinesses().subscribe(b => this.businesses.set(b));
  }

  onSubmit() {
    this.submitted = true;
    if (this.form.invalid) return;
    this.loading.set(true);
    this.bt.createTransaction(this.form.value as any).subscribe({
      next: () => { this.loading.set(false); this.router.navigate(['/business-trader/my-transactions']); },
      error: e => { this.loading.set(false); this.error.set(e?.error?.message || 'Failed.'); }
    });
  }
}
