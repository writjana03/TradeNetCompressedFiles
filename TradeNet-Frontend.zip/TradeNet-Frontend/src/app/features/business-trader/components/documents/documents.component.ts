import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { TraderDocument } from '../../../../core/models';

@Component({
  selector: 'app-bt-documents',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './documents.component.html',
  styleUrl: './documents.component.css',
})
export class BTDocumentsComponent {
  private bt = inject(BusinessTraderService);
  documents = signal<TraderDocument[]>([]);
  loading = signal(true);
  message = signal('');
  selectedFile: File | null = null;
  documentType = 'IDProof';
  docTypes = ['IDProof', 'AddressProof', 'TaxCertificate', 'BankStatement', 'Other'];

  ngOnInit() { this.load(); }

  load() {
    this.bt.getMyDocuments().subscribe({
      next: d => { this.documents.set(d); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  upload() {
    if (!this.selectedFile) { this.message.set('Please select a file.'); return; }
    this.bt.uploadDocument(this.selectedFile, this.documentType).subscribe({
      next: () => { this.message.set('Document uploaded.'); this.selectedFile = null; this.load(); },
      error: e => this.message.set(e?.error?.message || 'Upload failed.'),
    });
  }
}
