import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BusinessTraderService } from '../../../../core/services/business-trader.service';
import { AuthService } from '../../../../core/services/auth.service';
import { BusinessTraderDashboard } from '../../../../core/models';

@Component({
  selector: 'app-bt-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class BTDashboardComponent {
  private bt = inject(BusinessTraderService);
  auth = inject(AuthService);
  loading = signal(true);
  dashboard = signal<BusinessTraderDashboard | null>(null);
  error = signal('');

  ngOnInit() {
    this.bt.getDashboard().subscribe({
      next: d => { this.dashboard.set(d); this.loading.set(false); },
      error: e => { this.error.set(e?.error?.message || 'Failed to load.'); this.loading.set(false); }
    });
  }
}
