import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);

  loading = signal(false);
  error = signal('');
  success = signal('');
  submitted = false;

  form = this.fb.group({
    fullName: ['', [Validators.required, Validators.minLength(3)]],
    email:    ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', [Validators.required]],
    phone:    [''],
  });

  get f() { return this.form.controls; }

  onSubmit(): void {
    this.submitted = true;
    this.error.set('');
    this.success.set('');

    if (this.form.invalid) return;
    if (this.f.password.value !== this.f.confirmPassword.value) {
      this.error.set('Passwords do not match.'); return;
    }

    this.loading.set(true);
    this.auth.register({
      fullName: this.f.fullName.value!,
      email: this.f.email.value!,
      password: this.f.password.value!,
      confirmPassword: this.f.confirmPassword.value!,
      role: 'BusinessTrader',
      phone: this.f.phone.value || undefined,
    }).subscribe({
      next: (res) => {
        this.loading.set(false);
        this.success.set(res.message || res.Message || 'Registration successful! Redirecting to login…');
        setTimeout(() => this.router.navigate(['/login']), 1500);
      },
      error: (e) => {
        this.loading.set(false);
        const msg = e?.error?.message || e?.error?.Message || e?.message || 'Registration failed.';
        this.error.set(msg);
      },
    });
  }
}
