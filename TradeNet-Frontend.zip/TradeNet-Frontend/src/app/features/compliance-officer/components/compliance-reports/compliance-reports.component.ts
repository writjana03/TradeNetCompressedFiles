import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ComplianceService } from '../../../../core/services/compliance.service';
import { ComplianceRecord } from '../../../../core/models';

@Component({
  selector: 'app-compliance-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './compliance-reports.component.html',
  styleUrl: './compliance-reports.component.css',
})
export class ComplianceReportsComponent {
  private co = inject(ComplianceService);
  records = signal<ComplianceRecord[]>([]);
  loading = signal(true);
  message = signal('');
  newRecord: Partial<ComplianceRecord> = { entityId: 0, type: 'Business', result: 'Under Review', notes: '' };

  ngOnInit() { this.load(); }
  load() {
    this.co.getRecords().subscribe({
      next: r => { this.records.set(r); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  create() {
    if (!this.newRecord.entityId) { this.message.set('Entity ID required.'); return; }
    this.co.createRecord(this.newRecord).subscribe({
      next: () => { this.message.set('Record created.'); this.newRecord = { entityId: 0, type: 'Business', result: 'Under Review', notes: '' }; this.load(); }
    });
  }

  updateResult(r: ComplianceRecord) {
    const result = prompt('New result (Compliant / Non-Compliant / Under Review):', r.result);
    if (!result) return;
    const notes = prompt('Notes:', r.notes || '') || '';
    this.co.updateRecord(r.id, result, notes).subscribe({ next: () => { this.message.set('Updated.'); this.load(); } });
  }
}
