import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComplianceService } from '../../../../core/services/compliance.service';
import { Complaint } from '../../../../core/models';

@Component({
  selector: 'app-investigate-complaint',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './investigate-complaint.component.html',
  styleUrl: './investigate-complaint.component.css',
})
export class InvestigateComplaintComponent {
  private co = inject(ComplianceService);
  complaints = signal<Complaint[]>([]);
  loading = signal(true);
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.co.getComplaints().subscribe({
      next: c => { this.complaints.set(c); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  resolve(c: Complaint) {
    const resolution = prompt(`Resolution for complaint:`, '');
    if (!resolution) return;
    this.co.resolveComplaint(c.id, resolution).subscribe({ next: () => { this.message.set('Resolved.'); this.load(); } });
  }
}
