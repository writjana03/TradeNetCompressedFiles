import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ComplianceService } from '../../../../core/services/compliance.service';
import { Violation } from '../../../../core/models';

@Component({
  selector: 'app-violations',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './violations.component.html',
  styleUrl: './violations.component.css',
})
export class ViolationsComponent {
  private co = inject(ComplianceService);
  violations = signal<Violation[]>([]);
  loading = signal(true);
  message = signal('');
  newViolation: Partial<Violation> = { businessId: 0, violationType: 'Documentation', description: '', penalty: 0, status: 'Active' };

  ngOnInit() { this.load(); }
  load() {
    this.co.getViolations().subscribe({
      next: v => { this.violations.set(v); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  create() {
    if (!this.newViolation.businessId) { this.message.set('Business ID required.'); return; }
    this.co.createViolation(this.newViolation).subscribe({
      next: () => { this.message.set('Violation recorded.'); this.newViolation = { businessId: 0, violationType: 'Documentation', description: '', penalty: 0, status: 'Active' }; this.load(); }
    });
  }
}
