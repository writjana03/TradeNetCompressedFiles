import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ComplianceService } from '../../../../core/services/compliance.service';
import { Business } from '../../../../core/models';

@Component({
  selector: 'app-business-review',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './business-review.component.html',
  styleUrl: './business-review.component.css',
})
export class BusinessReviewComponent {
  private co = inject(ComplianceService);
  businesses = signal<Business[]>([]);
  loading = signal(true);
  filter = '';
  message = signal('');

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.co.getBusinesses(this.filter || undefined).subscribe({
      next: b => { this.businesses.set(b); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  flag(b: Business) {
    const reason = prompt(`Reason for flagging "${b.businessName}":`);
    if (!reason) return;
    this.co.flagBusiness(b.id, reason).subscribe({ next: () => { this.message.set('Flagged.'); this.load(); } });
  }

  clear(b: Business) {
    const notes = prompt(`Notes for clearing flag on "${b.businessName}":`) || 'Cleared';
    this.co.clearBusinessFlag(b.id, notes).subscribe({ next: () => { this.message.set('Cleared.'); this.load(); } });
  }
}
