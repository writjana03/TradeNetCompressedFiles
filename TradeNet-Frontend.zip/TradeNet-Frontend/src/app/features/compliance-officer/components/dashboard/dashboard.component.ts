import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ComplianceService } from '../../../../core/services/compliance.service';
import { AuthService } from '../../../../core/services/auth.service';
import { ComplianceDashboard } from '../../../../core/models';

@Component({
  selector: 'app-co-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class CODashboardComponent {
  private co = inject(ComplianceService);
  auth = inject(AuthService);
  loading = signal(true);
  dashboard = signal<ComplianceDashboard | null>(null);
  error = signal('');

  ngOnInit() {
    this.co.getDashboard().subscribe({
      next: d => { this.dashboard.set(d); this.loading.set(false); },
      error: e => { this.error.set(e?.error?.message || 'Failed.'); this.loading.set(false); }
    });
  }
}
