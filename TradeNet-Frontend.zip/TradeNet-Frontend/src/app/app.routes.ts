import { Routes } from '@angular/router';
import { guestGuard, roleGuard } from './core/guards/auth.guard';
import { LayoutComponent } from './shared/components/layout/layout.component';

export const routes: Routes = [
  // ── Public ──────────────────────────────────────────────────────────────────
  { path: '',     redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadComponent: () => import('./features/Home/home.component').then(m => m.HomeComponent) },
  { path: 'login',    canActivate: [guestGuard], loadComponent: () => import('./features/auth/components/login/login.component').then(m => m.LoginComponent) },
  { path: 'register', canActivate: [guestGuard], loadComponent: () => import('./features/auth/components/register/register.component').then(m => m.RegisterComponent) },

  // ── Admin (SystemAdmin) ─────────────────────────────────────────────────────
  { path: 'admin', component: LayoutComponent, canActivate: [roleGuard(['SystemAdmin'])], children: [
    { path: '',                  redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'dashboard',         loadComponent: () => import('./features/admin/components/dashboard/dashboard.component').then(m => m.AdminDashboardComponent) },
    { path: 'manage-users',      loadComponent: () => import('./features/admin/components/manage-users/manage-users.component').then(m => m.ManageUsersComponent) },
    { path: 'create-user',       loadComponent: () => import('./features/admin/components/create-user/create-user.component').then(m => m.CreateUserComponent) },
    { path: 'edit-user/:id',     loadComponent: () => import('./features/admin/components/edit-user/edit-user.component').then(m => m.EditUserComponent) },
    { path: 'reports',           loadComponent: () => import('./features/admin/components/reports/reports.component').then(m => m.AdminReportsComponent) },
    { path: 'system-monitoring', loadComponent: () => import('./features/admin/components/system-monitoring/system-monitoring.component').then(m => m.SystemMonitoringComponent) },
    { path: 'businesses',        loadComponent: () => import('./features/admin/components/businesses/businesses.component').then(m => m.AdminBusinessesComponent) },
  ]},

  // ── Business Trader ─────────────────────────────────────────────────────────
  { path: 'business-trader', component: LayoutComponent, canActivate: [roleGuard(['BusinessTrader'])], children: [
    { path: '',                  redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'dashboard',         loadComponent: () => import('./features/business-trader/components/dashboard/dashboard.component').then(m => m.BTDashboardComponent) },
    { path: 'profile',           loadComponent: () => import('./features/business-trader/components/profile/profile.component').then(m => m.BTProfileComponent) },
    { path: 'businesses',        loadComponent: () => import('./features/business-trader/components/businesses/businesses.component').then(m => m.BTBusinessesComponent) },
    { path: 'register-business', loadComponent: () => import('./features/business-trader/components/register-business/register-business.component').then(m => m.RegisterBusinessComponent) },
    { path: 'license-search',    loadComponent: () => import('./features/business-trader/components/license-search/license-search.component').then(m => m.LicenseSearchComponent) },
    { path: 'my-applications',   loadComponent: () => import('./features/business-trader/components/my-applications/my-applications.component').then(m => m.MyApplicationsComponent) },
    { path: 'my-transactions',   loadComponent: () => import('./features/business-trader/components/my-transactions/my-transactions.component').then(m => m.MyTransactionsComponent) },
    { path: 'create-transaction',loadComponent: () => import('./features/business-trader/components/create-transaction/create-transaction.component').then(m => m.CreateTransactionComponent) },
    { path: 'subsidies',         loadComponent: () => import('./features/business-trader/components/subsidies/subsidies.component').then(m => m.BTSubsidiesComponent) },
    { path: 'documents',         loadComponent: () => import('./features/business-trader/components/documents/documents.component').then(m => m.BTDocumentsComponent) },
    { path: 'complaints',        loadComponent: () => import('./features/business-trader/components/complaints/complaints.component').then(m => m.BTComplaintsComponent) },
    { path: 'notifications',     loadComponent: () => import('./features/business-trader/components/notifications/notifications.component').then(m => m.BTNotificationsComponent) },
  ]},

  // ── Trade Officer ───────────────────────────────────────────────────────────
  { path: 'trade-officer', component: LayoutComponent, canActivate: [roleGuard(['TradeOfficer'])], children: [
    { path: '',                       redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'dashboard',              loadComponent: () => import('./features/trade-officer/components/dashboard/dashboard.component').then(m => m.TODashboardComponent) },
    { path: 'document-verifications', loadComponent: () => import('./features/trade-officer/components/document-verifications/document-verifications.component').then(m => m.TODocumentVerificationsComponent) },
    { path: 'applications',           loadComponent: () => import('./features/trade-officer/components/applications/applications.component').then(m => m.TOApplicationsComponent) },
    { path: 'business-verifications', loadComponent: () => import('./features/trade-officer/components/business-verifications/business-verifications.component').then(m => m.TOBusinessVerificationsComponent) },
    { path: 'transactions-monitor',   loadComponent: () => import('./features/trade-officer/components/transactions-monitor/transactions-monitor.component').then(m => m.TOTransactionsMonitorComponent) },
  ]},

  // ── Program Manager ─────────────────────────────────────────────────────────
  { path: 'program-manager', component: LayoutComponent, canActivate: [roleGuard(['ProgramManager'])], children: [
    { path: '',                   redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'dashboard',          loadComponent: () => import('./features/program-manager/components/dashboard/dashboard.component').then(m => m.PMDashboardComponent) },
    { path: 'program-management', loadComponent: () => import('./features/program-manager/components/program-management/program-management.component').then(m => m.ProgramManagementComponent) },
    { path: 'create-program',     loadComponent: () => import('./features/program-manager/components/create-program/create-program.component').then(m => m.CreateProgramComponent) },
    { path: 'edit-program/:id',   loadComponent: () => import('./features/program-manager/components/edit-program/edit-program.component').then(m => m.EditProgramComponent) },
    { path: 'resources',          loadComponent: () => import('./features/program-manager/components/resources/resources.component').then(m => m.PMResourcesComponent) },
    { path: 'subsidies-pending',  loadComponent: () => import('./features/program-manager/components/subsidies-pending/subsidies-pending.component').then(m => m.SubsidiesPendingComponent) },
    { path: 'budget-monitoring',  loadComponent: () => import('./features/program-manager/components/budget-monitoring/budget-monitoring.component').then(m => m.BudgetMonitoringComponent) },
  ]},

  // ── Compliance Officer ──────────────────────────────────────────────────────
  { path: 'compliance-officer', component: LayoutComponent, canActivate: [roleGuard(['ComplianceOfficer'])], children: [
    { path: '',                      redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'dashboard',             loadComponent: () => import('./features/compliance-officer/components/dashboard/dashboard.component').then(m => m.CODashboardComponent) },
    { path: 'business-review',       loadComponent: () => import('./features/compliance-officer/components/business-review/business-review.component').then(m => m.BusinessReviewComponent) },
    { path: 'investigate-complaint', loadComponent: () => import('./features/compliance-officer/components/investigate-complaint/investigate-complaint.component').then(m => m.InvestigateComplaintComponent) },
    { path: 'compliance-reports',    loadComponent: () => import('./features/compliance-officer/components/compliance-reports/compliance-reports.component').then(m => m.ComplianceReportsComponent) },
    { path: 'violations',            loadComponent: () => import('./features/compliance-officer/components/violations/violations.component').then(m => m.ViolationsComponent) },
  ]},

  // ── Government Auditor ──────────────────────────────────────────────────────
  { path: 'gov-auditor', component: LayoutComponent, canActivate: [roleGuard(['GovernmentAuditor'])], children: [
    { path: '',                      redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'dashboard',             loadComponent: () => import('./features/gov-auditor/components/dashboard/dashboard.component').then(m => m.GADashboardComponent) },
    { path: 'audit-reports',         loadComponent: () => import('./features/gov-auditor/components/audit-reports/audit-reports.component').then(m => m.AuditReportsComponent) },
    { path: 'compliance-monitoring', loadComponent: () => import('./features/gov-auditor/components/compliance-monitoring/compliance-monitoring.component').then(m => m.GAComplianceMonitoringComponent) },
    { path: 'trade-programs',        loadComponent: () => import('./features/gov-auditor/components/trade-programs/trade-programs.component').then(m => m.GATradeProgramsComponent) },
    { path: 'generate-report',       loadComponent: () => import('./features/gov-auditor/components/generate-report/generate-report.component').then(m => m.GenerateReportComponent) },
  ]},

  { path: '**', redirectTo: 'home' },
];
