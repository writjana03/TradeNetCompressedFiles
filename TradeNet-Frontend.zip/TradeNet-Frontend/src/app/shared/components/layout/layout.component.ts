import { Component, inject, computed, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

interface NavItem { label: string; icon: string; route: string; }

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, CommonModule],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css'
})
export class LayoutComponent {
  auth = inject(AuthService);
  sidebarOpen = signal(true);

  navItems = computed<NavItem[]>(() => {
    const role = this.auth.role();
    const map: Record<string, NavItem[]> = {
      SystemAdmin: [
        { label: 'Dashboard',     icon: 'bi-speedometer2',      route: '/admin/dashboard' },
        { label: 'Manage Users',  icon: 'bi-people-fill',       route: '/admin/manage-users' },
        { label: 'Businesses',    icon: 'bi-building',          route: '/admin/businesses' },
        { label: 'Reports',       icon: 'bi-bar-chart-fill',    route: '/admin/reports' },
        { label: 'System Logs',   icon: 'bi-activity',          route: '/admin/system-monitoring' },
      ],
      BusinessTrader: [
        { label: 'Dashboard',         icon: 'bi-speedometer2',      route: '/business-trader/dashboard' },
        { label: 'My Businesses',     icon: 'bi-building',          route: '/business-trader/businesses' },
        { label: 'License Search',    icon: 'bi-search',            route: '/business-trader/license-search' },
        { label: 'My Applications',   icon: 'bi-file-earmark-text', route: '/business-trader/my-applications' },
        { label: 'My Transactions',   icon: 'bi-cash-coin',         route: '/business-trader/my-transactions' },
        { label: 'Subsidies',         icon: 'bi-gift',              route: '/business-trader/subsidies' },
        { label: 'Documents',         icon: 'bi-folder2',           route: '/business-trader/documents' },
        { label: 'Complaints',        icon: 'bi-chat-square-text',  route: '/business-trader/complaints' },
        { label: 'Profile',           icon: 'bi-person-circle',     route: '/business-trader/profile' },
        { label: 'Notifications',     icon: 'bi-bell',              route: '/business-trader/notifications' },
      ],
      TradeOfficer: [
        { label: 'Dashboard',          icon: 'bi-speedometer2',  route: '/trade-officer/dashboard' },
        { label: 'Doc Verifications',  icon: 'bi-shield-check',  route: '/trade-officer/document-verifications' },
        { label: 'License Approvals',  icon: 'bi-file-text',     route: '/trade-officer/applications' },
        { label: 'Business Verify',    icon: 'bi-building-check',route: '/trade-officer/business-verifications' },
        { label: 'Transactions',       icon: 'bi-graph-up',      route: '/trade-officer/transactions-monitor' },
      ],
      ProgramManager: [
        { label: 'Dashboard',        icon: 'bi-speedometer2',      route: '/program-manager/dashboard' },
        { label: 'Programs',         icon: 'bi-kanban',            route: '/program-manager/program-management' },
        { label: 'Resources',        icon: 'bi-stack',             route: '/program-manager/resources' },
        { label: 'Pending Subsidies',icon: 'bi-gift',              route: '/program-manager/subsidies-pending' },
        { label: 'Budget Monitor',   icon: 'bi-wallet2',           route: '/program-manager/budget-monitoring' },
      ],
      ComplianceOfficer: [
        { label: 'Dashboard',        icon: 'bi-speedometer2',      route: '/compliance-officer/dashboard' },
        { label: 'Business Review',  icon: 'bi-building',          route: '/compliance-officer/business-review' },
        { label: 'Complaints',       icon: 'bi-chat-square-text',  route: '/compliance-officer/investigate-complaint' },
        { label: 'Compliance Records',icon: 'bi-clipboard-check',  route: '/compliance-officer/compliance-reports' },
        { label: 'Violations',       icon: 'bi-exclamation-triangle', route: '/compliance-officer/violations' },
      ],
      GovernmentAuditor: [
        { label: 'Dashboard',        icon: 'bi-speedometer2',      route: '/gov-auditor/dashboard' },
        { label: 'Audit Reports',    icon: 'bi-clipboard-data',    route: '/gov-auditor/audit-reports' },
        { label: 'Compliance',       icon: 'bi-shield-check',      route: '/gov-auditor/compliance-monitoring' },
        { label: 'Trade Programs',   icon: 'bi-diagram-3',         route: '/gov-auditor/trade-programs' },
        { label: 'Generate Report',  icon: 'bi-file-earmark-plus', route: '/gov-auditor/generate-report' },
      ],
    };
    return map[role] ?? [];
  });

  toggleSidebar() { this.sidebarOpen.update(v => !v); }
  logout() { this.auth.logout(); }
}
