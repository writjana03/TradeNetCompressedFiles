# TradeNet — Angular 21 Frontend

A modern Angular 21 single-page application for the TradeNet trade licensing platform. It talks to 6 .NET 10 microservices (one per role) over HTTPS.

## Running

```bash
npm install
npm start
```

The dev server runs at <http://localhost:4200>. Make sure all 6 TradeNet backend APIs are running on ports 7001–7006 first.

## Architecture

- **Standalone components** with zoneless change detection (Angular 21 default).
- **Lazy-loaded routes** for each role's feature area.
- **Signals** for reactive state in core services.
- **Bootstrap 5.3 + Bootstrap Icons** for styling.
- **Role-aware UI** — sidebar, accent colors, and dashboard layouts all driven by the authenticated user's role.

## Project Structure

```
src/
├── environments/
│   ├── environment.ts          # 6 API URLs (default development)
│   └── environment.prod.ts
└── app/
    ├── app.config.ts           # Provides router, HTTP, and JWT interceptor
    ├── app.routes.ts           # Lazy routes for all roles
    ├── app.ts / app.html
    ├── core/
    │   ├── models/             # All TypeScript interfaces (one barrel file)
    │   ├── services/           # auth + 6 role services
    │   ├── guards/             # authGuard, guestGuard, roleGuard
    │   └── interceptors/       # jwt.interceptor
    ├── shared/
    │   ├── header/             # Optional standalone header
    │   └── layout/             # Sidebar + topbar + router-outlet wrapper
    └── features/
        ├── Home/               # Public landing page
        ├── auth/components/
        │   ├── login/
        │   └── register/
        ├── admin/components/        # 7 components
        ├── business-trader/components/  # 12 components
        ├── trade-officer/components/    # 5 components
        ├── program-manager/components/  # 7 components
        ├── compliance-officer/components/  # 5 components
        └── gov-auditor/components/         # 5 components
```

## API Routing

The frontend talks to **6 separate APIs**, one per role. The Admin API at port 7001 is the **single auth gateway** for all roles — `/api/auth/login` and `/api/auth/register` are only there. Once a JWT is issued, the same token works on all six APIs (they share the JWT key, issuer, audience, and database).

| Frontend service                  | Base URL                          | Backend                                |
|-----------------------------------|-----------------------------------|----------------------------------------|
| `AuthService` (login/register)    | `https://localhost:7001/api/auth` | TradeNet.Admin.API                     |
| `AdminService`                    | `https://localhost:7001/api/admin` | TradeNet.Admin.API                     |
| `BusinessTraderService`           | `https://localhost:7002/api/business-trader` | TradeNet.BusinessTrader.API |
| `TradeOfficerService`             | `https://localhost:7003/api/trade-officer` | TradeNet.TradeOfficer.API     |
| `ProgramManagerService`           | `https://localhost:7004/api/program-manager` | TradeNet.ProgramManager.API |
| `ComplianceService`               | `https://localhost:7005/api/compliance-officer` | TradeNet.ComplianceOfficer.API |
| `AuditorService`                  | `https://localhost:7006/api/gov-auditor` | TradeNet.GovernmentAuditor.API |

To change ports/hosts, edit `src/environments/environment.ts` and `environment.prod.ts`.

## Authentication

- After successful login, the JWT (and basic user info) is stored under `localStorage` key `tnet_user`.
- `jwt.interceptor.ts` attaches `Authorization: Bearer <token>` and `X-User-Id: <userId>` headers to every authenticated request.
- `authGuard` / `guestGuard` / `roleGuard(allowedRoles)` protect routes.
- On `401` the interceptor clears local storage and redirects to `/login`.

## Test Accounts (all password `password123`)

| Email                          | Role               | Dashboard route                |
|--------------------------------|--------------------|--------------------------------|
| trader@tradenet.local          | BusinessTrader     | `/business-trader/dashboard`   |
| officer@tradenet.local         | TradeOfficer       | `/trade-officer/dashboard`     |
| manager@tradenet.local         | ProgramManager     | `/program-manager/dashboard`   |
| admin@tradenet.local           | SystemAdmin        | `/admin/dashboard`             |
| compliance@tradenet.local      | ComplianceOfficer  | `/compliance-officer/dashboard` |
| auditor@tradenet.local         | GovernmentAuditor  | `/gov-auditor/dashboard`       |

Self-registration via `/register` always creates a `BusinessTrader` account; other roles must be assigned by an administrator.

## End-to-end Wired Endpoints

Every role's full set of API endpoints is wired through. For example:

- **BusinessTrader**: register/edit businesses, upload documents, search licenses, apply, view applications, create transactions, request subsidies, raise complaints, view notifications.
- **TradeOfficer**: verify/reject trader documents and business documents, approve/reject license applications, flag/clear transactions, verify/reject businesses.
- **ProgramManager**: CRUD trade programs and resources, approve/reject pending subsidies, monitor budget utilization.
- **ComplianceOfficer**: flag/clear non-compliant businesses, resolve complaints, create compliance records, record violations.
- **GovernmentAuditor**: create audits, update status, record findings, escalate compliance issues, flag programs for review, generate reports.
- **SystemAdmin**: manage users (CRUD + activate/deactivate), suspend/reinstate businesses, broadcast notifications, generate reports (CSV download), view system logs.

All `(method, path)` combinations on the frontend services match the corresponding controllers on the backend exactly.
