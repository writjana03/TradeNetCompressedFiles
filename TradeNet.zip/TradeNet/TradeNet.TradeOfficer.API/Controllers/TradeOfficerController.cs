using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;

namespace TradeNetProject.Controllers
{
    [Route("api/trade-officer")]
    [ApiController]
    [Authorize]
    [Produces("application/json")]
    public class TradeOfficerController : ControllerBase
    {
        private readonly ITradeOfficerService _officer;
        private readonly INotificationService _notifications;
        private readonly ISystemLogService _logs;
        private readonly ITransactionService _tx;

        public TradeOfficerController(ITradeOfficerService officer, INotificationService n, ISystemLogService logs, ITransactionService tx)
        {
            _officer = officer; _notifications = n; _logs = logs; _tx = tx;
        }

        private int GetUserId()
        {
            var c = User.FindFirst(ClaimTypes.NameIdentifier);
            if (c != null && int.TryParse(c.Value, out int id)) return id;
            throw new UnauthorizedAccessException("Valid JWT required.");
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard() => Ok(await _officer.GetDashboardAsync(GetUserId()));

        // ── DOCUMENT VERIFICATION ───────────────────────────────────────
        [HttpGet("documents/trader/pending")]
        public async Task<IActionResult> GetPendingTraderDocs() =>
            Ok(await _officer.GetPendingTraderDocumentsAsync());

        [HttpGet("documents/business/pending")]
        public async Task<IActionResult> GetPendingBusinessDocs() =>
            Ok(await _officer.GetPendingBusinessDocumentsAsync());

        [HttpPut("documents/trader/{id}/verify")]
        public async Task<IActionResult> VerifyTraderDoc(int id)
        {
            var (ok, msg) = await _officer.VerifyTraderDocumentAsync(id, GetUserId());
            if (ok) await _logs.LogAsync(GetUserId(), "VerifyTraderDoc", $"DocId={id}");
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("documents/trader/{id}/reject")]
        public async Task<IActionResult> RejectTraderDoc(int id, [FromBody] string reason)
        {
            var (ok, msg) = await _officer.RejectTraderDocumentAsync(id, GetUserId(), reason);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("documents/business/{id}/verify")]
        public async Task<IActionResult> VerifyBusinessDoc(int id)
        {
            var (ok, msg) = await _officer.VerifyBusinessDocumentAsync(id, GetUserId());
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("documents/business/{id}/reject")]
        public async Task<IActionResult> RejectBusinessDoc(int id, [FromBody] string reason)
        {
            var (ok, msg) = await _officer.RejectBusinessDocumentAsync(id, GetUserId(), reason);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── LICENSE APPLICATIONS ────────────────────────────────────────
        [HttpGet("applications/pending")]
        public async Task<IActionResult> GetPendingApps() =>
            Ok(await _officer.GetPendingApplicationsAsync());

        public record ApproveApplicationRequest(DateTime? ExpiryDate, string? Notes);

        [HttpPut("applications/{id}/approve")]
        public async Task<IActionResult> ApproveApp(int id, [FromBody] ApproveApplicationRequest req)
        {
            var (ok, msg) = await _officer.ApproveApplicationAsync(id, GetUserId(), req.ExpiryDate, req.Notes);
            if (ok) await _logs.LogAsync(GetUserId(), "ApproveLicenseApp", $"AppId={id}");
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("applications/{id}/reject")]
        public async Task<IActionResult> RejectApp(int id, [FromBody] string reason)
        {
            var (ok, msg) = await _officer.RejectApplicationAsync(id, GetUserId(), reason);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── TRANSACTIONS MONITORING ─────────────────────────────────────
        [HttpGet("transactions")]
        public async Task<IActionResult> GetTransactions() => Ok(await _officer.GetTransactionsAsync());

        [HttpGet("transactions/suspicious")]
        public async Task<IActionResult> GetSuspicious() => Ok(await _officer.GetSuspiciousTransactionsAsync());

        [HttpPut("transactions/{id}/flag")]
        public async Task<IActionResult> FlagTransaction(int id, [FromBody] string notes)
        {
            var (ok, msg) = await _officer.FlagTransactionAsync(id, GetUserId(), notes);
            if (ok) await _logs.LogAsync(GetUserId(), "FlagTransaction", $"TxId={id}");
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("transactions/{id}/clear")]
        public async Task<IActionResult> ClearTransactionFlag(int id)
        {
            var (ok, msg) = await _officer.ClearTransactionFlagAsync(id, GetUserId());
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── BUSINESS VERIFICATION ───────────────────────────────────────
        [HttpGet("businesses")]
        public async Task<IActionResult> GetBusinesses() => Ok(await _officer.GetAllBusinessesAsync());

        [HttpPut("businesses/{id}/verify")]
        public async Task<IActionResult> VerifyBusiness(int id)
        {
            var (ok, msg) = await _officer.VerifyBusinessAsync(id, GetUserId());
            if (ok) await _logs.LogAsync(GetUserId(), "VerifyBusiness", $"BizId={id}");
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("businesses/{id}/reject")]
        public async Task<IActionResult> RejectBusiness(int id, [FromBody] string reason)
        {
            var (ok, msg) = await _officer.RejectBusinessAsync(id, GetUserId(), reason);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── NOTIFICATIONS ───────────────────────────────────────────────
        [HttpGet("notifications")]
        public async Task<IActionResult> GetNotifications()
        {
            var uid = GetUserId();
            var n = await _notifications.GetByUserAsync(uid);
            await _notifications.MarkAllReadAsync(uid);
            return Ok(n);
        }
    }
}
