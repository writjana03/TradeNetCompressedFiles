using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;

namespace TradeNetProject.Controllers
{
    [Route("api/program-manager")]
    [ApiController]
    [Authorize]
    [Produces("application/json")]
    public class ProgramManagerController : ControllerBase
    {
        private readonly IProgramManagerService _pm;
        private readonly INotificationService _notifications;
        private readonly ISystemLogService _logs;

        public ProgramManagerController(IProgramManagerService pm, INotificationService n, ISystemLogService logs)
        {
            _pm = pm; _notifications = n; _logs = logs;
        }

        private int GetUserId()
        {
            var c = User.FindFirst(ClaimTypes.NameIdentifier);
            if (c != null && int.TryParse(c.Value, out int id)) return id;
            throw new UnauthorizedAccessException("Valid JWT required.");
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard() => Ok(await _pm.GetDashboardAsync(GetUserId()));

        // ── PROGRAMS ────────────────────────────────────────────────────
        [HttpGet("programs")]
        public async Task<IActionResult> GetPrograms() => Ok(await _pm.GetAllProgramsAsync());

        [HttpGet("programs/{id}")]
        public async Task<IActionResult> GetProgram(int id)
        {
            var p = await _pm.GetProgramByIdAsync(id);
            return p == null ? NotFound() : Ok(p);
        }

        [HttpPost("programs")]
        public async Task<IActionResult> CreateProgram([FromBody] TradeProgram program)
        {
            var (ok, msg, p) = await _pm.CreateProgramAsync(program);
            if (ok) await _logs.LogAsync(GetUserId(), "CreateProgram", program.ProgramName);
            return ok ? Ok(new { Message = msg, Program = p }) : BadRequest(new { Message = msg });
        }

        [HttpPut("programs/{id}")]
        public async Task<IActionResult> UpdateProgram(int id, [FromBody] TradeProgram program)
        {
            program.Id = id;
            var (ok, msg) = await _pm.UpdateProgramAsync(program);
            return ok ? Ok(new { Message = msg, Program = program }) : BadRequest(new { Message = msg });
        }

        [HttpDelete("programs/{id}")]
        public async Task<IActionResult> DeleteProgram(int id)
        {
            var (ok, msg) = await _pm.DeleteProgramAsync(id);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── RESOURCES ───────────────────────────────────────────────────
        [HttpGet("resources")]
        public async Task<IActionResult> GetResources([FromQuery] int? programId) =>
            Ok(await _pm.GetResourcesAsync(programId));

        [HttpPost("resources")]
        public async Task<IActionResult> CreateResource([FromBody] Resource r)
        {
            var (ok, msg) = await _pm.AddResourceAsync(r);
            return ok ? Ok(new { Message = msg, Resource = r }) : BadRequest(new { Message = msg });
        }

        [HttpPut("resources/{id}")]
        public async Task<IActionResult> UpdateResource(int id, [FromBody] Resource r)
        {
            r.Id = id;
            var (ok, msg) = await _pm.UpdateResourceAsync(r);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpDelete("resources/{id}")]
        public async Task<IActionResult> DeleteResource(int id)
        {
            var (ok, msg) = await _pm.DeleteResourceAsync(id);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── SUBSIDIES ───────────────────────────────────────────────────
        [HttpGet("subsidies/pending")]
        public async Task<IActionResult> GetPendingSubsidies() =>
            Ok(await _pm.GetPendingSubsidiesAsync());

        public record ApproveSubsidyRequest(decimal Amount);

        [HttpPut("subsidies/{id}/approve")]
        public async Task<IActionResult> ApproveSubsidy(int id, [FromBody] ApproveSubsidyRequest req)
        {
            var (ok, msg) = await _pm.ApproveSubsidyAsync(id, GetUserId(), req.Amount, _notifications);
            if (ok) await _logs.LogAsync(GetUserId(), "ApproveSubsidy", $"Id={id}");
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("subsidies/{id}/reject")]
        public async Task<IActionResult> RejectSubsidy(int id, [FromBody] string reason)
        {
            var (ok, msg) = await _pm.RejectSubsidyAsync(id, GetUserId(), reason, _notifications);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── BUDGET MONITORING ───────────────────────────────────────────
        [HttpGet("budget-monitoring")]
        public async Task<IActionResult> GetBudget()
        {
            var programs = await _pm.GetAllProgramsAsync();
            return Ok(programs.Select(p => new {
                p.Id, p.ProgramName, p.TotalBudget, p.BudgetUtilized,
                RemainingBudget = p.TotalBudget - p.BudgetUtilized,
                UtilizationPercent = p.TotalBudget > 0 ? (p.BudgetUtilized / p.TotalBudget * 100) : 0
            }));
        }

        // ── NOTIFICATIONS ───────────────────────────────────────────────
        [HttpGet("notifications")]
        public async Task<IActionResult> GetNotifications()
        {
            var uid = GetUserId();
            var n = await _notifications.GetByUserAsync(uid);
            await _notifications.MarkAllReadAsync(uid);
            return Ok(n);
        }
    }
}
