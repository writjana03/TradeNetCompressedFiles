using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Serilog;
using TradeNetProject.Authentication;
using TradeNetProject.Data;
using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Middleware;
using TradeNetProject.Repositories.Common;
using TradeNetProject.Repositories.BusinessTrader;
using TradeNetProject.Repositories.Business;
using TradeNetProject.Services.Common;
using TradeNetProject.Services.Admin;
using TradeNetProject.Services.BusinessTrader;
using TradeNetProject.Services.Business;
using TradeNetProject.Services.TradeOfficer;
using TradeNetProject.Services.ProgramManager;
using TradeNetProject.Services.ComplianceOfficer;
using TradeNetProject.Services.GovernmentAuditor;

Log.Logger = new LoggerConfiguration().WriteTo.Console().CreateBootstrapLogger();

try
{
    Log.Information("Starting TradeNet ProgramManager API");

    var builder = WebApplication.CreateBuilder(args);

    builder.Host.UseSerilog((ctx, services, config) =>
        config.ReadFrom.Configuration(ctx.Configuration)
              .ReadFrom.Services(services)
              .Enrich.FromLogContext()
              .Enrich.WithProperty("Application", "ProgramManager.API"));

    builder.Services.AddDbContext<ApplicationDbContext>(o =>
        o.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

    builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
    builder.Services.AddProblemDetails();

    var jwtSection = builder.Configuration.GetSection("Jwt");
    var jwtKey = Encoding.UTF8.GetBytes(jwtSection["Key"]!);

    builder.Services
        .AddAuthentication(o => {
            o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            o.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(o => {
            o.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true, ValidateAudience = true,
                ValidateLifetime = true, ValidateIssuerSigningKey = true,
                ValidIssuer = jwtSection["Issuer"], ValidAudience = jwtSection["Audience"],
                IssuerSigningKey = new SymmetricSecurityKey(jwtKey),
                ClockSkew = TimeSpan.Zero
            };
        })
        .AddScheme<AuthenticationSchemeOptions, XUserIdAuthenticationHandler>("XUserId", _ => { });

    builder.Services.AddAuthorization();
    builder.Services.AddControllers().AddJsonOptions(o => {
        o.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
        o.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
    });

    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(c => {
        c.SwaggerDoc("v1", new() { Title = "TradeNet — ProgramManager API", Version = "v1" });
        c.EnableAnnotations();
    });

    // ─── Repositories ───
    builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
    builder.Services.AddScoped<IUserRepository, UserRepository>();
    builder.Services.AddScoped<ISystemLogRepository, SystemLogRepository>();
    builder.Services.AddScoped<INotificationRepository, NotificationRepository>();
    builder.Services.AddScoped<IAuditRepository, AuditRepository>();
    builder.Services.AddScoped<IReportRepository, ReportRepository>();
    builder.Services.AddScoped<ITradeProgramRepository, TradeProgramRepository>();
    builder.Services.AddScoped<IResourceRepository, ResourceRepository>();
    builder.Services.AddScoped<IComplianceRecordRepository, ComplianceRecordRepository>();
    builder.Services.AddScoped<IComplaintRepository, ComplaintRepository>();
    builder.Services.AddScoped<IViolationRepository, ViolationRepository>();
    builder.Services.AddScoped<IBusinessTraderRepository, BusinessTraderRepository>();
    builder.Services.AddScoped<ITraderDocumentRepository, TraderDocumentRepository>();
    builder.Services.AddScoped<ILicenseApplicationRepository, LicenseApplicationRepository>();
    builder.Services.AddScoped<ISubsidyRepository, SubsidyRepository>();
    builder.Services.AddScoped<IBusinessRepository, BusinessRepository>();
    builder.Services.AddScoped<IBusinessDocumentRepository, BusinessDocumentRepository>();
    builder.Services.AddScoped<ITradeLicenseRepository, TradeLicenseRepository>();
    builder.Services.AddScoped<ITransactionRepository, TransactionRepository>();

    // ─── Services ───
    builder.Services.AddScoped<IAccountService, AccountService>();
    builder.Services.AddScoped<INotificationService, NotificationService>();
    builder.Services.AddScoped<ISystemLogService, SystemLogService>();
    builder.Services.AddScoped<ITradeProgramService, TradeProgramService>();
    builder.Services.AddScoped<IResourceService, ResourceService>();
    builder.Services.AddScoped<IReportService, ReportService>();
    builder.Services.AddScoped<IBusinessTraderService, BusinessTraderService>();
    builder.Services.AddScoped<ILicenseApplicationService, LicenseApplicationService>();
    builder.Services.AddScoped<ISubsidyService, SubsidyService>();
    builder.Services.AddScoped<IBusinessService, BusinessService>();
    builder.Services.AddScoped<ITradeLicenseService, TradeLicenseService>();
    builder.Services.AddScoped<ITransactionService, TransactionService>();
    builder.Services.AddScoped<IAdminService, AdminService>();
    builder.Services.AddScoped<ITradeOfficerService, TradeOfficerService>();
    builder.Services.AddScoped<IProgramManagerService, ProgramManagerService>();
    builder.Services.AddScoped<IComplianceOfficerService, ComplianceOfficerService>();
    builder.Services.AddScoped<IGovernmentAuditorService, GovernmentAuditorService>();

    builder.Services.AddCors(o =>
        o.AddPolicy("AllowAll", p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

    var app = builder.Build();

    app.UseSerilogRequestLogging();
    app.UseCors("AllowAll");
    app.UseSwagger();
    app.UseSwaggerUI(c => {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "ProgramManager API v1");
        c.RoutePrefix = string.Empty;
        c.DocumentTitle = "TradeNet — ProgramManager API";
    });

    app.UseExceptionHandler();
    app.UseStaticFiles();
    app.UseAuthentication();
    app.UseAuthorization();
    app.MapControllers();

    // Auto-migrate database on startup (dev only)
    using (var scope = app.Services.CreateScope())
    {
        try { scope.ServiceProvider.GetRequiredService<ApplicationDbContext>().Database.EnsureCreated(); }
        catch (Exception ex) { Log.Warning(ex, "Database creation skipped."); }
    }

    app.Run();
}
catch (Exception ex) when (ex is not HostAbortedException)
{
    Log.Fatal(ex, "ProgramManager API terminated unexpectedly");
}
finally
{
    Log.CloseAndFlush();
}
