using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Security.Claims;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Controllers
{
    [Route("api/business-trader")]
    [ApiController]
    [Authorize]
    [Produces("application/json")]
    public class BusinessTraderController : ControllerBase
    {
        private readonly IBusinessTraderService _trader;
        private readonly IBusinessService _business;
        private readonly ITradeLicenseService _licenses;
        private readonly ILicenseApplicationService _apps;
        private readonly ITransactionService _tx;
        private readonly ISubsidyService _subsidies;
        private readonly INotificationService _notifications;
        private readonly ITradeProgramService _programs;
        private readonly IAccountService _account;
        private readonly ISystemLogService _logs;

        public BusinessTraderController(
            IBusinessTraderService trader, IBusinessService business, ITradeLicenseService licenses,
            ILicenseApplicationService apps, ITransactionService tx, ISubsidyService subsidies,
            INotificationService notifications, ITradeProgramService programs,
            IAccountService account, ISystemLogService logs)
        {
            _trader = trader; _business = business; _licenses = licenses; _apps = apps;
            _tx = tx; _subsidies = subsidies; _notifications = notifications;
            _programs = programs; _account = account; _logs = logs;
        }

        private int GetUserId()
        {
            var c = User.FindFirst(ClaimTypes.NameIdentifier);
            if (c != null && int.TryParse(c.Value, out int id)) return id;
            throw new UnauthorizedAccessException("Valid JWT required.");
        }

        // ── DASHBOARD ───────────────────────────────────────────────────
        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard() => Ok(await _trader.GetDashboardAsync(GetUserId()));

        // ── PROFILE ─────────────────────────────────────────────────────
        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            return t == null ? NotFound(new { Message = "Profile not found." }) : Ok(t);
        }

        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] BusinessTrader model)
        {
            var uid = GetUserId();
            var existing = await _trader.GetByUserIdAsync(uid);
            if (existing == null) return NotFound(new { Message = "Profile not found." });
            existing.FullName = model.FullName; existing.PhoneNumber = model.PhoneNumber;
            existing.Address = model.Address; existing.Nationality = model.Nationality;
            existing.DateOfBirth = model.DateOfBirth;
            var (ok, msg) = await _trader.UpdateProfileAsync(existing);
            return ok ? Ok(new { Message = "Profile updated.", BusinessTrader = existing }) : BadRequest(new { Message = msg });
        }

        // ── DOCUMENTS ───────────────────────────────────────────────────
        [HttpGet("documents")]
        public async Task<IActionResult> GetDocuments()
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return NotFound(new { Message = "Profile not found." });
            var docs = (await _trader.GetDocumentsAsync(t.Id)).ToList();
            var baseUrl = $"{Request.Scheme}://{Request.Host}";
            foreach (var d in docs)
                if (!string.IsNullOrEmpty(d.FilePath) && d.FilePath.StartsWith("/uploads"))
                    d.FilePath = $"{baseUrl}{d.FilePath}";
            return Ok(docs);
        }

        [HttpPost("documents/upload")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadDocument([FromForm] DocumentUploadRequest request)
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return NotFound(new { Message = "Profile not found." });
            if (request.File == null || request.File.Length == 0)
                return BadRequest(new { Message = "No file selected." });

            var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "documents");
            if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);

            var unique = $"{Guid.NewGuid()}_{Path.GetFileName(request.File.FileName)}";
            var physical = Path.Combine(uploadsFolder, unique);
            using (var s = new FileStream(physical, FileMode.Create)) { await request.File.CopyToAsync(s); }
            var dbPath = $"/uploads/documents/{unique}";
            var (ok, msg) = await _trader.UploadDocumentAsync(t.Id, request.DocumentType, request.File.FileName, dbPath);
            return ok ? Ok(new { Message = "Upload success", FilePath = dbPath }) : BadRequest(new { Message = msg });
        }

        // ── BUSINESSES ──────────────────────────────────────────────────
        [HttpGet("businesses")]
        public async Task<IActionResult> GetMyBusinesses()
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return Ok(new List<Business>());
            return Ok(await _business.GetByBusinessTraderAsync(t.Id));
        }

        [HttpPost("businesses")]
        public async Task<IActionResult> RegisterBusiness([FromBody] BusinessRegistrationRequest req)
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return NotFound(new { Message = "Trader profile required." });
            var (ok, msg, b) = await _business.RegisterAsync(t.Id, req);
            return ok ? Ok(new { Message = msg, Business = b }) : BadRequest(new { Message = msg });
        }

        [HttpGet("businesses/{id}")]
        public async Task<IActionResult> GetBusiness(int id) {
            var b = await _business.GetByIdAsync(id);
            return b == null ? NotFound() : Ok(b);
        }

        [HttpPut("businesses/{id}")]
        public async Task<IActionResult> UpdateBusiness(int id, [FromBody] Business model)
        {
            var existing = await _business.GetByIdAsync(id);
            if (existing == null) return NotFound();
            existing.BusinessName = model.BusinessName; existing.BusinessType = model.BusinessType;
            existing.Address = model.Address; existing.ContactInfo = model.ContactInfo;
            existing.PhoneNumber = model.PhoneNumber; existing.Description = model.Description;
            var (ok, msg) = await _business.UpdateAsync(existing);
            return ok ? Ok(new { Message = msg, Business = existing }) : BadRequest(new { Message = msg });
        }

        [HttpGet("businesses/{id}/documents")]
        public async Task<IActionResult> GetBusinessDocuments(int id) =>
            Ok(await _business.GetDocumentsAsync(id));

        [HttpPost("businesses/{id}/documents/upload")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadBusinessDocument(int id, [FromForm] DocumentUploadRequest request)
        {
            if (request.File == null || request.File.Length == 0) return BadRequest(new { Message = "No file." });
            var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "business-docs");
            if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);
            var unique = $"{Guid.NewGuid()}_{Path.GetFileName(request.File.FileName)}";
            var physical = Path.Combine(uploadsFolder, unique);
            using (var s = new FileStream(physical, FileMode.Create)) { await request.File.CopyToAsync(s); }
            var dbPath = $"/uploads/business-docs/{unique}";
            var (ok, msg, doc) = await _business.UploadDocumentAsync(id, request.DocumentType, request.File.FileName, dbPath);
            return ok ? Ok(new { Message = msg, Document = doc }) : BadRequest(new { Message = msg });
        }

        // ── LICENSES ────────────────────────────────────────────────────
        [HttpGet("licenses/search")]
        public async Task<IActionResult> SearchLicenses(
            [FromQuery] string? keyword, [FromQuery] string? licenseType, [FromQuery] string? category)
        {
            var results = await _licenses.SearchAsync(keyword ?? "", licenseType ?? "", category ?? "");
            return Ok(new { Keyword = keyword, LicenseType = licenseType, Category = category, Licenses = results });
        }

        [HttpGet("licenses")]
        public async Task<IActionResult> GetAllLicenses() => Ok(await _licenses.GetAllAsync());

        [HttpPost("licenses/{licenseId}/apply")]
        public async Task<IActionResult> ApplyForLicense(int licenseId, [FromBody] LicenseApplyRequest req)
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return NotFound(new { Message = "Profile required." });
            var (ok, msg) = await _trader.ApplyForLicenseAsync(t.Id, licenseId, req.ApplicationNotes);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── APPLICATIONS ────────────────────────────────────────────────
        [HttpGet("applications")]
        public async Task<IActionResult> GetMyApplications()
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return Ok(new List<LicenseApplication>());
            return Ok(await _trader.GetApplicationsAsync(t.Id));
        }

        [HttpDelete("applications/{id}")]
        public async Task<IActionResult> WithdrawApplication(int id)
        {
            var (ok, msg) = await _trader.WithdrawApplicationAsync(id);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── TRANSACTIONS ────────────────────────────────────────────────
        [HttpGet("transactions")]
        public async Task<IActionResult> GetMyTransactions()
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return Ok(new List<Transaction>());
            var bizes = await _business.GetByBusinessTraderAsync(t.Id);
            var all = new List<Transaction>();
            foreach (var b in bizes) all.AddRange(await _tx.GetByBusinessAsync(b.Id));
            return Ok(all.OrderByDescending(x => x.TransactionDate));
        }

        [HttpPost("transactions")]
        public async Task<IActionResult> CreateTransaction([FromBody] TransactionCreateRequest req)
        {
            var (ok, msg, tx) = await _tx.CreateAsync(req);
            if (ok) await _logs.LogAsync(GetUserId(), "CreateTransaction", $"BusinessId={req.BusinessId}");
            return ok ? Ok(new { Message = msg, Transaction = tx }) : BadRequest(new { Message = msg });
        }

        // ── SUBSIDIES ───────────────────────────────────────────────────
        [HttpGet("subsidies")]
        public async Task<IActionResult> GetMySubsidies()
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return Ok(new List<Subsidy>());
            return Ok(await _trader.GetSubsidiesAsync(t.Id));
        }

        [HttpPost("subsidies/apply/{programId}")]
        public async Task<IActionResult> ApplyForSubsidy(int programId)
        {
            var t = await _trader.GetByUserIdAsync(GetUserId());
            if (t == null) return NotFound(new { Message = "Profile required." });
            var (ok, msg) = await _trader.ApplyForSubsidyAsync(t.Id, programId);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── PROGRAMS (read-only for traders) ────────────────────────────
        [HttpGet("programs")]
        public async Task<IActionResult> GetPrograms() => Ok(await _programs.GetAllAsync());

        // ── COMPLAINTS ──────────────────────────────────────────────────
        [HttpGet("complaints")]
        public async Task<IActionResult> GetComplaints() => Ok(await _trader.GetMyComplaintsAsync(GetUserId()));

        public record RaiseComplaintRequest(int? BusinessId, string Description);

        [HttpPost("complaints")]
        public async Task<IActionResult> RaiseComplaint([FromBody] RaiseComplaintRequest req)
        {
            var (ok, msg, c) = await _trader.RaiseComplaintAsync(GetUserId(), req.BusinessId, req.Description);
            return ok ? Ok(new { Message = msg, Complaint = c }) : BadRequest(new { Message = msg });
        }

        // ── NOTIFICATIONS ───────────────────────────────────────────────
        [HttpGet("notifications")]
        public async Task<IActionResult> GetNotifications()
        {
            var uid = GetUserId();
            var notifs = await _notifications.GetByUserAsync(uid);
            await _notifications.MarkAllReadAsync(uid);
            return Ok(notifs);
        }
    }
}
