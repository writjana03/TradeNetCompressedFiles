using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class TradeProgram
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(200)]
        public string ProgramName { get; set; } = string.Empty;

        public string? Description { get; set; }

        [StringLength(50)]
        public string? ProgramType { get; set; } // ExportPromotion/Subsidy/FinancialSupport

        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalBudget { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal BudgetUtilized { get; set; }

        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; }

        [StringLength(1000)]
        public string? EligibilityCriteria { get; set; }

        [StringLength(30)]
        public string Status { get; set; } = "Active";

        public virtual ICollection<Subsidy> Subsidies { get; set; } = new List<Subsidy>();
        public virtual ICollection<Resource> Resources { get; set; } = new List<Resource>();
    }
}
