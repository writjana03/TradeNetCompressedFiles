using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class Audit
    {
        [Key]
        public int Id { get; set; }

        public int OfficerId { get; set; }
        [ForeignKey("OfficerId")]
        public virtual User Officer { get; set; } = null!;

        [StringLength(200)]
        public string AuditTitle { get; set; } = string.Empty;

        [StringLength(50)]
        public string Scope { get; set; } = string.Empty; // Business/Transaction/Program/License

        public string? Findings { get; set; }

        public DateTime Date { get; set; } = DateTime.Now;

        public DateTime? CompletedDate { get; set; }

        [StringLength(30)]
        public string Status { get; set; } = "Open"; // Open/InProgress/Completed
    }
}
