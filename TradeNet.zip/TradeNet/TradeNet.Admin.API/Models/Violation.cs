using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class Violation
    {
        [Key]
        public int Id { get; set; }

        public int BusinessId { get; set; }
        [ForeignKey("BusinessId")]
        public virtual Business Business { get; set; } = null!;

        public int OfficerId { get; set; }
        [ForeignKey("OfficerId")]
        public virtual User Officer { get; set; } = null!;

        [StringLength(100)]
        public string ViolationType { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Penalty { get; set; }

        public DateTime ViolationDate { get; set; } = DateTime.Now;

        [StringLength(30)]
        public string Status { get; set; } = "Active";
    }
}
