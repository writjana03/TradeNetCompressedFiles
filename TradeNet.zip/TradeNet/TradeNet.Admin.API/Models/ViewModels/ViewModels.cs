namespace TradeNetProject.Models.ViewModels
{
    public class LoginViewModel
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class RegisterViewModel
    {
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string ConfirmPassword { get; set; } = string.Empty;
        public string Role { get; set; } = "BusinessTrader";
        public string? Phone { get; set; }
    }

    public class CreateUserViewModel
    {
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Role { get; set; } = "BusinessTrader";
        public string? Phone { get; set; }
    }

    public class DocumentUploadRequest
    {
        public IFormFile File { get; set; } = null!;
        public string DocumentType { get; set; } = null!;
    }

    public class BusinessRegistrationRequest
    {
        public string BusinessName { get; set; } = string.Empty;
        public string BusinessType { get; set; } = "Trader";
        public string? Address { get; set; }
        public string? ContactInfo { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Description { get; set; }
    }

    public class LicenseApplyRequest
    {
        public int TradeLicenseId { get; set; }
        public string? ApplicationNotes { get; set; }
    }

    public class TransactionCreateRequest
    {
        public int BusinessId { get; set; }
        public string TransactionType { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string? Counterparty { get; set; }
        public string? InvoiceNumber { get; set; }
        public string? Description { get; set; }
    }

    public class DashboardViewModel
    {
        public int TotalUsers { get; set; }
        public int ActiveUsers { get; set; }
        public int TotalBusinessTraders { get; set; }
        public int TotalBusinesses { get; set; }
        public int TotalLicenses { get; set; }
        public int ActiveLicenses { get; set; }
        public int TotalApplications { get; set; }
        public int PendingApplications { get; set; }
        public int TotalTransactions { get; set; }
        public int FlaggedTransactions { get; set; }
        public int TotalPrograms { get; set; }
        public int ActivePrograms { get; set; }
        public int PendingDocuments { get; set; }
        public int ComplianceAlerts { get; set; }
        public int TotalAudits { get; set; }
        public int OpenAudits { get; set; }
        public int TotalReports { get; set; }
        public int TotalComplaints { get; set; }
        public int PendingComplaints { get; set; }
        public int TotalViolations { get; set; }
        public decimal TotalBudget { get; set; }
        public decimal TotalSubsidiesPaid { get; set; }
        public List<Notification> RecentNotifications { get; set; } = new();
        public List<SystemLog> RecentLogs { get; set; } = new();
        public List<TradeLicense> RecentLicenses { get; set; } = new();
        public List<LicenseApplication> RecentApplications { get; set; } = new();
        public List<TradeProgram> Programs { get; set; } = new();
        public List<ComplianceRecord> RecentCompliance { get; set; } = new();
        public List<Audit> RecentAudits { get; set; } = new();
    }

    public class BusinessTraderDashboardViewModel
    {
        public BusinessTrader BusinessTrader { get; set; } = null!;
        public int TotalBusinesses { get; set; }
        public int ActiveApplications { get; set; }
        public int ApprovedApplications { get; set; }
        public int TotalTransactions { get; set; }
        public decimal TotalTradeVolume { get; set; }
        public int DocumentCount { get; set; }
        public int VerifiedDocs { get; set; }
        public int PendingDocs { get; set; }
        public int TotalSubsidies { get; set; }
        public decimal TotalSubsidyAmount { get; set; }
        public List<LicenseApplication> RecentApplications { get; set; } = new();
        public List<Transaction> RecentTransactions { get; set; } = new();
        public List<Notification> Notifications { get; set; } = new();
        public List<TradeLicense> AvailableLicenses { get; set; } = new();
    }

    public class TradeOfficerDashboardViewModel
    {
        public int PendingDocuments { get; set; }
        public int PendingLicenseApplications { get; set; }
        public int ApprovedApplications { get; set; }
        public int RejectedApplications { get; set; }
        public int FlaggedTransactions { get; set; }
        public int PendingBusinessVerifications { get; set; }
        public List<BusinessDocument> PendingBizDocs { get; set; } = new();
        public List<TraderDocument> PendingTraderDocs { get; set; } = new();
        public List<LicenseApplication> RecentApplications { get; set; } = new();
        public List<Transaction> SuspiciousTransactions { get; set; } = new();
        public List<Business> FlaggedBusinesses { get; set; } = new();
        public List<Notification> Notifications { get; set; } = new();
    }

    public class ProgramManagerDashboardViewModel
    {
        public int TotalPrograms { get; set; }
        public int ActivePrograms { get; set; }
        public decimal TotalBudget { get; set; }
        public decimal BudgetUtilized { get; set; }
        public int TotalSubsidies { get; set; }
        public int TotalBeneficiaries { get; set; }
        public int TotalResources { get; set; }
        public List<TradeProgram> Programs { get; set; } = new();
        public List<Subsidy> RecentSubsidies { get; set; } = new();
        public List<Notification> Notifications { get; set; } = new();
    }

    public class ComplianceDashboardViewModel
    {
        public int PendingReviews { get; set; }
        public int TotalComplaints { get; set; }
        public int PendingComplaints { get; set; }
        public int TotalViolations { get; set; }
        public int TotalInspections { get; set; }
        public int NonCompliantBusinesses { get; set; }
        public List<Business> Businesses { get; set; } = new();
        public List<Complaint> RecentComplaints { get; set; } = new();
        public List<Violation> RecentViolations { get; set; } = new();
        public List<ComplianceRecord> RecentRecords { get; set; } = new();
    }

    public class AuditorDashboardViewModel
    {
        public int TotalAudits { get; set; }
        public int OpenAudits { get; set; }
        public int CompletedAudits { get; set; }
        public int TotalCompliance { get; set; }
        public int NonCompliant { get; set; }
        public int TotalPrograms { get; set; }
        public int TotalReports { get; set; }
        public List<Audit> RecentAudits { get; set; } = new();
        public List<ComplianceRecord> RecentCompliance { get; set; } = new();
        public List<TradeProgram> Programs { get; set; } = new();
        public List<Report> RecentReports { get; set; } = new();
        public List<Notification> Notifications { get; set; } = new();
    }

    public class ErrorViewModel
    {
        public string? RequestId { get; set; }
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
