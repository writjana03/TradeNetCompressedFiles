using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class BusinessTrader
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        [Required, EmailAddress, StringLength(100)]
        public string Email { get; set; } = string.Empty;

        [StringLength(20)]
        public string? PhoneNumber { get; set; }

        [StringLength(500)]
        public string? Address { get; set; }

        [StringLength(100)]
        public string? Nationality { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        [StringLength(30)]
        public string VerificationStatus { get; set; } = "Pending";

        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public virtual User User { get; set; } = null!;

        public virtual ICollection<TraderDocument> Documents { get; set; } = new List<TraderDocument>();
        public virtual ICollection<Business> Businesses { get; set; } = new List<Business>();
        public virtual ICollection<LicenseApplication> Applications { get; set; } = new List<LicenseApplication>();
        public virtual ICollection<Subsidy> Subsidies { get; set; } = new List<Subsidy>();
    }
}
