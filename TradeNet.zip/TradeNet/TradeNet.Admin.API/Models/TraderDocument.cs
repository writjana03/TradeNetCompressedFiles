using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class TraderDocument
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int BusinessTraderId { get; set; }
        [ForeignKey("BusinessTraderId")]
        public virtual BusinessTrader BusinessTrader { get; set; } = null!;

        [Required, StringLength(50)]
        public string DocumentType { get; set; } = string.Empty;

        [Required, StringLength(200)]
        public string FileName { get; set; } = string.Empty;

        [StringLength(500)]
        public string? FilePath { get; set; }

        public DateTime UploadedDate { get; set; } = DateTime.Now;

        [Required, StringLength(30)]
        public string VerificationStatus { get; set; } = "Pending";

        [StringLength(500)]
        public string? RejectionReason { get; set; }

        public DateTime? VerificationDate { get; set; }

        public int? VerifiedByUserId { get; set; }
        [ForeignKey("VerifiedByUserId")]
        public virtual User? VerifiedBy { get; set; }
    }
}
