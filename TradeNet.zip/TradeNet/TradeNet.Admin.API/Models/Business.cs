using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class Business
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(200)]
        public string BusinessName { get; set; } = string.Empty;

        [Required, StringLength(50)]
        public string BusinessType { get; set; } = "Trader"; // Trader/Importer/Exporter

        [StringLength(500)]
        public string? Address { get; set; }

        [StringLength(100)]
        public string? ContactInfo { get; set; }

        [StringLength(20)]
        public string? PhoneNumber { get; set; }

        [StringLength(100)]
        public string? RegistrationNumber { get; set; }

        [StringLength(1000)]
        public string? Description { get; set; }

        public DateTime RegistrationDate { get; set; } = DateTime.Now;

        [StringLength(30)]
        public string Status { get; set; } = "Pending"; // Pending/Verified/Suspended/Active

        [StringLength(30)]
        public string ComplianceStatus { get; set; } = "Compliant";

        public int BusinessTraderId { get; set; }
        [ForeignKey("BusinessTraderId")]
        public virtual BusinessTrader BusinessTrader { get; set; } = null!;

        public virtual ICollection<BusinessDocument> Documents { get; set; } = new List<BusinessDocument>();
        public virtual ICollection<TradeLicense> TradeLicenses { get; set; } = new List<TradeLicense>();
        public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
    }
}
