using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class Subsidy
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int TradeProgramId { get; set; }
        [ForeignKey("TradeProgramId")]
        public virtual TradeProgram TradeProgram { get; set; } = null!;

        [Required]
        public int BusinessTraderId { get; set; }
        [ForeignKey("BusinessTraderId")]
        public virtual BusinessTrader BusinessTrader { get; set; } = null!;

        [Required, StringLength(50)]
        public string SubsidyType { get; set; } = string.Empty;

        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        public DateTime SubsidyDate { get; set; } = DateTime.Now;

        [StringLength(30)]
        public string Status { get; set; } = "Pending";

        [StringLength(500)]
        public string? Description { get; set; }
    }
}
