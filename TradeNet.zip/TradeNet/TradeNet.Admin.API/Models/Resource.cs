using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class Resource
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Type { get; set; } = string.Empty; // Funds/Materials/Personnel

        [StringLength(200)]
        public string? Name { get; set; }

        public int Quantity { get; set; }

        [StringLength(30)]
        public string Status { get; set; } = "Available";

        [Required]
        public int TradeProgramId { get; set; }
        [ForeignKey("TradeProgramId")]
        public virtual TradeProgram TradeProgram { get; set; } = null!;
    }
}
