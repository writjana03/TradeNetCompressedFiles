using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class BusinessDocument
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int BusinessId { get; set; }
        [ForeignKey("BusinessId")]
        public virtual Business Business { get; set; } = null!;

        [Required, StringLength(100)]
        public string DocType { get; set; } = string.Empty; // TradeRegistration, TaxCertificate, License, IDProof

        [Required, StringLength(200)]
        public string FileName { get; set; } = string.Empty;

        [Required, StringLength(500)]
        public string FileURL { get; set; } = string.Empty;

        public DateTime UploadedDate { get; set; } = DateTime.Now;

        [StringLength(30)]
        public string VerificationStatus { get; set; } = "Pending";

        [StringLength(500)]
        public string? RejectionReason { get; set; }
    }
}
