using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class LicenseApplication
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int BusinessTraderId { get; set; }
        [ForeignKey("BusinessTraderId")]
        public virtual BusinessTrader BusinessTrader { get; set; } = null!;

        [Required]
        public int TradeLicenseId { get; set; }
        [ForeignKey("TradeLicenseId")]
        public virtual TradeLicense TradeLicense { get; set; } = null!;

        public DateTime SubmittedDate { get; set; } = DateTime.Now;

        [Required, StringLength(30)]
        public string Status { get; set; } = "Pending"; // Pending/Approved/Rejected

        [StringLength(2000)]
        public string? ApplicationNotes { get; set; }

        public DateTime? ReviewedDate { get; set; }

        [StringLength(1000)]
        public string? ReviewNotes { get; set; }

        [StringLength(500)]
        public string? RejectionReason { get; set; }
    }
}
