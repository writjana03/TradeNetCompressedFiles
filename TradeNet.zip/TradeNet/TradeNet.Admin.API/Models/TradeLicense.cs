using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class TradeLicense
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required, StringLength(50)]
        public string LicenseType { get; set; } = string.Empty; // Import/Export/Local

        [Required]
        public string Description { get; set; } = string.Empty;

        [StringLength(100)]
        public string? Category { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Fee { get; set; }

        public DateTime? IssuedDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public DateTime PostedDate { get; set; } = DateTime.Now;

        [StringLength(30)]
        public string Status { get; set; } = "Available"; // Available/Pending/Approved/Rejected/Expired

        [Required]
        public int BusinessId { get; set; }
        [ForeignKey("BusinessId")]
        public virtual Business Business { get; set; } = null!;

        public virtual ICollection<LicenseApplication> Applications { get; set; } = new List<LicenseApplication>();
    }
}
