using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TradeNetProject.Models
{
    public class Transaction
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int BusinessId { get; set; }
        [ForeignKey("BusinessId")]
        public virtual Business Business { get; set; } = null!;

        [Required, StringLength(30)]
        public string TransactionType { get; set; } = string.Empty; // Sale/Purchase/Import/Export

        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        public DateTime TransactionDate { get; set; } = DateTime.Now;

        [StringLength(30)]
        public string Status { get; set; } = "Pending"; // Pending/Completed/Failed/Flagged

        [StringLength(200)]
        public string? Counterparty { get; set; }

        [StringLength(100)]
        public string? InvoiceNumber { get; set; }

        [StringLength(1000)]
        public string? Description { get; set; }

        [StringLength(1000)]
        public string? OfficerNotes { get; set; }

        public int? MonitoredByUserId { get; set; }
        [ForeignKey("MonitoredByUserId")]
        public virtual User? MonitoredBy { get; set; }
    }
}
