using Microsoft.EntityFrameworkCore;
using TradeNetProject.Models;

namespace TradeNetProject.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<BusinessTrader> BusinessTraders { get; set; }
        public DbSet<TraderDocument> TraderDocuments { get; set; }
        public DbSet<Business> Businesses { get; set; }
        public DbSet<BusinessDocument> BusinessDocuments { get; set; }
        public DbSet<TradeLicense> TradeLicenses { get; set; }
        public DbSet<LicenseApplication> LicenseApplications { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<TradeProgram> TradePrograms { get; set; }
        public DbSet<Subsidy> Subsidies { get; set; }
        public DbSet<Resource> Resources { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<ComplianceRecord> ComplianceRecords { get; set; }
        public DbSet<Audit> Audits { get; set; }
        public DbSet<Report> Reports { get; set; }
        public DbSet<SystemLog> SystemLogs { get; set; }
        public DbSet<Complaint> Complaints { get; set; }
        public DbSet<Violation> Violations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // User <-> BusinessTrader (1:1)
            modelBuilder.Entity<User>()
                .HasOne(u => u.BusinessTrader)
                .WithOne(t => t.User)
                .HasForeignKey<BusinessTrader>(t => t.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            // BusinessTrader -> Businesses (1:N)
            modelBuilder.Entity<Business>()
                .HasOne(b => b.BusinessTrader)
                .WithMany(t => t.Businesses)
                .HasForeignKey(b => b.BusinessTraderId)
                .OnDelete(DeleteBehavior.Restrict);

            // BusinessTrader -> Documents (1:N)
            modelBuilder.Entity<TraderDocument>()
                .HasOne(d => d.BusinessTrader)
                .WithMany(t => t.Documents)
                .HasForeignKey(d => d.BusinessTraderId)
                .OnDelete(DeleteBehavior.Cascade);

            // Business -> Documents (1:N)
            modelBuilder.Entity<BusinessDocument>()
                .HasOne(d => d.Business)
                .WithMany(b => b.Documents)
                .HasForeignKey(d => d.BusinessId)
                .OnDelete(DeleteBehavior.Cascade);

            // Business -> TradeLicenses (1:N)
            modelBuilder.Entity<TradeLicense>()
                .HasOne(l => l.Business)
                .WithMany(b => b.TradeLicenses)
                .HasForeignKey(l => l.BusinessId)
                .OnDelete(DeleteBehavior.Cascade);

            // Business -> Transactions (1:N)
            modelBuilder.Entity<Transaction>()
                .HasOne(t => t.Business)
                .WithMany(b => b.Transactions)
                .HasForeignKey(t => t.BusinessId)
                .OnDelete(DeleteBehavior.Cascade);

            // Transaction -> MonitoredBy
            modelBuilder.Entity<Transaction>()
                .HasOne(t => t.MonitoredBy)
                .WithMany()
                .HasForeignKey(t => t.MonitoredByUserId)
                .OnDelete(DeleteBehavior.Restrict);

            // BusinessTrader -> Applications (1:N)
            modelBuilder.Entity<LicenseApplication>()
                .HasOne(a => a.BusinessTrader)
                .WithMany(t => t.Applications)
                .HasForeignKey(a => a.BusinessTraderId)
                .OnDelete(DeleteBehavior.Restrict);

            // TradeLicense -> Applications (1:N)
            modelBuilder.Entity<LicenseApplication>()
                .HasOne(a => a.TradeLicense)
                .WithMany(l => l.Applications)
                .HasForeignKey(a => a.TradeLicenseId)
                .OnDelete(DeleteBehavior.Restrict);

            // TradeProgram -> Subsidies / Resources
            modelBuilder.Entity<Subsidy>()
                .HasOne(s => s.TradeProgram)
                .WithMany(p => p.Subsidies)
                .HasForeignKey(s => s.TradeProgramId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Subsidy>()
                .HasOne(s => s.BusinessTrader)
                .WithMany(t => t.Subsidies)
                .HasForeignKey(s => s.BusinessTraderId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Resource>()
                .HasOne(r => r.TradeProgram)
                .WithMany(p => p.Resources)
                .HasForeignKey(r => r.TradeProgramId)
                .OnDelete(DeleteBehavior.Cascade);

            // Notification -> User
            modelBuilder.Entity<Notification>()
                .HasOne(n => n.User)
                .WithMany(u => u.Notifications)
                .HasForeignKey(n => n.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // SystemLog -> User
            modelBuilder.Entity<SystemLog>()
                .HasOne(s => s.User)
                .WithMany(u => u.SystemLogs)
                .HasForeignKey(s => s.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Audit -> Officer
            modelBuilder.Entity<Audit>()
                .HasOne(a => a.Officer)
                .WithMany(u => u.Audits)
                .HasForeignKey(a => a.OfficerId)
                .OnDelete(DeleteBehavior.Restrict);

            // Report -> User
            modelBuilder.Entity<Report>()
                .HasOne(r => r.GeneratedByUser)
                .WithMany(u => u.Reports)
                .HasForeignKey(r => r.GeneratedBy)
                .OnDelete(DeleteBehavior.Restrict);

            // Complaint -> User / Business
            modelBuilder.Entity<Complaint>()
                .HasOne(c => c.User)
                .WithMany()
                .HasForeignKey(c => c.UserId)
                .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Complaint>()
                .HasOne(c => c.Business)
                .WithMany()
                .HasForeignKey(c => c.BusinessId)
                .OnDelete(DeleteBehavior.Restrict);

            // Violation -> Business / Officer
            modelBuilder.Entity<Violation>()
                .HasOne(v => v.Business)
                .WithMany()
                .HasForeignKey(v => v.BusinessId)
                .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Violation>()
                .HasOne(v => v.Officer)
                .WithMany()
                .HasForeignKey(v => v.OfficerId)
                .OnDelete(DeleteBehavior.Restrict);

            // ComplianceRecord -> Officer
            modelBuilder.Entity<ComplianceRecord>()
                .HasOne(c => c.Officer)
                .WithMany()
                .HasForeignKey(c => c.OfficerId)
                .OnDelete(DeleteBehavior.Restrict);

            // TraderDocument -> VerifiedBy
            modelBuilder.Entity<TraderDocument>()
                .HasOne(d => d.VerifiedBy)
                .WithMany()
                .HasForeignKey(d => d.VerifiedByUserId)
                .OnDelete(DeleteBehavior.Restrict);

            // Unique email index
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();

            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(
                new User { Id = 1, FullName = "John Trader", Email = "trader@tradenet.local", Password = "password123", Role = "BusinessTrader", Phone = "555-0001", Status = "Active", CreatedAt = new DateTime(2026, 1, 1) },
                new User { Id = 2, FullName = "Officer Smith", Email = "officer@tradenet.local", Password = "password123", Role = "TradeOfficer", Phone = "555-0002", Status = "Active", CreatedAt = new DateTime(2026, 1, 1) },
                new User { Id = 3, FullName = "Manager Davis", Email = "manager@tradenet.local", Password = "password123", Role = "ProgramManager", Phone = "555-0003", Status = "Active", CreatedAt = new DateTime(2026, 1, 1) },
                new User { Id = 4, FullName = "Admin User", Email = "admin@tradenet.local", Password = "password123", Role = "SystemAdmin", Phone = "555-0004", Status = "Active", CreatedAt = new DateTime(2026, 1, 1) },
                new User { Id = 5, FullName = "Compliance Officer", Email = "compliance@tradenet.local", Password = "password123", Role = "ComplianceOfficer", Phone = "555-0005", Status = "Active", CreatedAt = new DateTime(2026, 1, 1) },
                new User { Id = 6, FullName = "Auditor Brown", Email = "auditor@tradenet.local", Password = "password123", Role = "GovernmentAuditor", Phone = "555-0006", Status = "Active", CreatedAt = new DateTime(2026, 1, 1) }
            );

            modelBuilder.Entity<BusinessTrader>().HasData(
                new BusinessTrader { Id = 1, UserId = 1, FullName = "John Trader", Email = "trader@tradenet.local", PhoneNumber = "555-0001", Address = "123 Trade Street", Nationality = "USA", VerificationStatus = "Verified" }
            );

            modelBuilder.Entity<Business>().HasData(
                new Business { Id = 1, BusinessTraderId = 1, BusinessName = "Alpha Trading Co.", BusinessType = "Exporter", Address = "123 Trade Street", ContactInfo = "alpha@trading.com", PhoneNumber = "555-1111", RegistrationNumber = "REG-001", Description = "Electronics exporter", RegistrationDate = new DateTime(2026, 1, 15), Status = "Verified", ComplianceStatus = "Compliant" },
                new Business { Id = 2, BusinessTraderId = 1, BusinessName = "Beta Imports Ltd.", BusinessType = "Importer", Address = "456 Import Ave", ContactInfo = "beta@imports.com", PhoneNumber = "555-2222", RegistrationNumber = "REG-002", Description = "Textile importer", RegistrationDate = new DateTime(2026, 2, 10), Status = "Verified", ComplianceStatus = "Compliant" }
            );

            modelBuilder.Entity<TradeLicense>().HasData(
                new TradeLicense { Id = 1, BusinessId = 1, Title = "Standard Export License", LicenseType = "Export", Description = "General-purpose export license for goods", Category = "Electronics", Fee = 500m, IssuedDate = new DateTime(2026, 2, 1), ExpiryDate = new DateTime(2027, 2, 1), PostedDate = new DateTime(2026, 1, 20), Status = "Approved" },
                new TradeLicense { Id = 2, BusinessId = 1, Title = "Standard Import License", LicenseType = "Import", Description = "General-purpose import license", Category = "Electronics", Fee = 400m, PostedDate = new DateTime(2026, 1, 25), Status = "Available" },
                new TradeLicense { Id = 3, BusinessId = 2, Title = "Local Trade License", LicenseType = "Local", Description = "Domestic market trade license", Category = "Textiles", Fee = 200m, IssuedDate = new DateTime(2026, 3, 1), ExpiryDate = new DateTime(2027, 3, 1), PostedDate = new DateTime(2026, 2, 20), Status = "Approved" }
            );

            modelBuilder.Entity<Transaction>().HasData(
                new Transaction { Id = 1, BusinessId = 1, TransactionType = "Sale", Amount = 15000m, TransactionDate = new DateTime(2026, 3, 15), Status = "Completed", Counterparty = "Buyer XYZ", InvoiceNumber = "INV-001", Description = "Electronics shipment" },
                new Transaction { Id = 2, BusinessId = 1, TransactionType = "Export", Amount = 25000m, TransactionDate = new DateTime(2026, 3, 20), Status = "Completed", Counterparty = "Overseas Inc.", InvoiceNumber = "INV-002", Description = "Export deal" },
                new Transaction { Id = 3, BusinessId = 2, TransactionType = "Purchase", Amount = 8000m, TransactionDate = new DateTime(2026, 4, 1), Status = "Pending", Counterparty = "Supplier ABC", InvoiceNumber = "INV-003", Description = "Raw materials" }
            );

            modelBuilder.Entity<TradeProgram>().HasData(
                new TradeProgram { Id = 1, ProgramName = "Export Promotion 2026", Description = "Annual export promotion program with subsidies", ProgramType = "ExportPromotion", TotalBudget = 500000m, BudgetUtilized = 75000m, StartDate = new DateTime(2026, 1, 1), EndDate = new DateTime(2026, 12, 31), EligibilityCriteria = "Active exporters with verified status", Status = "Active" },
                new TradeProgram { Id = 2, ProgramName = "SME Support Initiative", Description = "Supporting small and medium trader enterprises", ProgramType = "Subsidy", TotalBudget = 200000m, BudgetUtilized = 30000m, StartDate = new DateTime(2026, 2, 1), EndDate = new DateTime(2027, 1, 31), EligibilityCriteria = "Annual revenue under $5M", Status = "Active" },
                new TradeProgram { Id = 3, ProgramName = "Import Tariff Reduction", Description = "Tariff-reduction program for essential imports", ProgramType = "FinancialSupport", TotalBudget = 300000m, BudgetUtilized = 0m, StartDate = new DateTime(2026, 4, 1), EndDate = new DateTime(2027, 3, 31), Status = "Active" }
            );

            modelBuilder.Entity<ComplianceRecord>().HasData(
                new ComplianceRecord { Id = 1, EntityId = 1, Type = "Business", Result = "Compliant", Notes = "Quarterly review passed", Date = new DateTime(2026, 3, 1), OfficerId = 5 },
                new ComplianceRecord { Id = 2, EntityId = 1, Type = "Transaction", Result = "Under Review", Notes = "High-value transaction flagged for review", Date = new DateTime(2026, 3, 22), OfficerId = 5 }
            );

            modelBuilder.Entity<Audit>().HasData(
                new Audit { Id = 1, OfficerId = 6, AuditTitle = "Q1 Business Compliance Audit", Scope = "Business", Findings = "Initial review of trading practices and license usage", Date = new DateTime(2026, 3, 5), Status = "Open" },
                new Audit { Id = 2, OfficerId = 6, AuditTitle = "Program Effectiveness Review", Scope = "Program", Findings = "Evaluation of Export Promotion 2026 program outcomes", Date = new DateTime(2026, 2, 25), Status = "Completed", CompletedDate = new DateTime(2026, 3, 10) }
            );
        }
    }
}
