using Microsoft.EntityFrameworkCore;
using TradeNetProject.Data;
using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Models;
using TradeNetProject.Repositories.Common;

namespace TradeNetProject.Repositories.Business
{
    public class BusinessRepository : Repository<TradeNetProject.Models.Business>, IBusinessRepository
    {
        public BusinessRepository(ApplicationDbContext ctx) : base(ctx) { }

        public async Task<IEnumerable<TradeNetProject.Models.Business>> GetByBusinessTraderAsync(int businessTraderId) =>
            await _set.Where(b => b.BusinessTraderId == businessTraderId).ToListAsync();

        public async Task<IEnumerable<TradeNetProject.Models.Business>> GetByStatusAsync(string status) =>
            await _set.Include(b => b.BusinessTrader).Where(b => b.Status == status).ToListAsync();

        public async Task<TradeNetProject.Models.Business?> GetWithDetailsAsync(int id) =>
            await _set.Include(b => b.BusinessTrader).Include(b => b.Documents).Include(b => b.TradeLicenses)
                .FirstOrDefaultAsync(b => b.Id == id);
    }

    public class BusinessDocumentRepository : Repository<BusinessDocument>, IBusinessDocumentRepository
    {
        public BusinessDocumentRepository(ApplicationDbContext ctx) : base(ctx) { }

        public async Task<IEnumerable<BusinessDocument>> GetByBusinessAsync(int businessId) =>
            await _set.Where(d => d.BusinessId == businessId)
                      .OrderByDescending(d => d.UploadedDate).ToListAsync();

        public async Task<IEnumerable<BusinessDocument>> GetPendingAsync() =>
            await _set.Include(d => d.Business)
                      .Where(d => d.VerificationStatus == "Pending").ToListAsync();
    }

    public class TradeLicenseRepository : Repository<TradeLicense>, ITradeLicenseRepository
    {
        public TradeLicenseRepository(ApplicationDbContext ctx) : base(ctx) { }

        public async Task<IEnumerable<TradeLicense>> GetByBusinessAsync(int businessId) =>
            await _set.Where(l => l.BusinessId == businessId).ToListAsync();

        public async Task<IEnumerable<TradeLicense>> GetByStatusAsync(string status) =>
            await _set.Include(l => l.Business).Where(l => l.Status == status).ToListAsync();

        public async Task<IEnumerable<TradeLicense>> SearchAsync(string keyword, string licenseType, string category)
        {
            var q = _set.Include(l => l.Business).AsQueryable();
            if (!string.IsNullOrWhiteSpace(keyword))
                q = q.Where(l => l.Title.Contains(keyword) || l.Description.Contains(keyword));
            if (!string.IsNullOrWhiteSpace(licenseType))
                q = q.Where(l => l.LicenseType == licenseType);
            if (!string.IsNullOrWhiteSpace(category))
                q = q.Where(l => l.Category == category);
            return await q.ToListAsync();
        }
    }

    public class TransactionRepository : Repository<Transaction>, ITransactionRepository
    {
        public TransactionRepository(ApplicationDbContext ctx) : base(ctx) { }

        public async Task<IEnumerable<Transaction>> GetByBusinessAsync(int businessId) =>
            await _set.Where(t => t.BusinessId == businessId)
                      .OrderByDescending(t => t.TransactionDate).ToListAsync();

        public async Task<IEnumerable<Transaction>> GetByStatusAsync(string status) =>
            await _set.Include(t => t.Business).Where(t => t.Status == status).ToListAsync();

        public async Task<IEnumerable<Transaction>> GetSuspiciousAsync() =>
            await _set.Include(t => t.Business)
                      .Where(t => t.Status == "Flagged" || t.Amount > 50000)
                      .OrderByDescending(t => t.TransactionDate).ToListAsync();
    }
}
