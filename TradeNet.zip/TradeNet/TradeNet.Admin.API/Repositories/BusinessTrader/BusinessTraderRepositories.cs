using Microsoft.EntityFrameworkCore;
using TradeNetProject.Data;
using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Models;
using TradeNetProject.Repositories.Common;

namespace TradeNetProject.Repositories.BusinessTrader
{
    public class BusinessTraderRepository : Repository<TradeNetProject.Models.BusinessTrader>, IBusinessTraderRepository
    {
        public BusinessTraderRepository(ApplicationDbContext ctx) : base(ctx) { }

        public async Task<TradeNetProject.Models.BusinessTrader?> GetByUserIdAsync(int userId) =>
            await _set.FirstOrDefaultAsync(t => t.UserId == userId);

        public async Task<TradeNetProject.Models.BusinessTrader?> GetWithDetailsAsync(int id) =>
            await _set.Include(t => t.User).Include(t => t.Documents).Include(t => t.Businesses)
                .FirstOrDefaultAsync(t => t.Id == id);
    }

    public class TraderDocumentRepository : Repository<TraderDocument>, ITraderDocumentRepository
    {
        public TraderDocumentRepository(ApplicationDbContext ctx) : base(ctx) { }

        public async Task<IEnumerable<TraderDocument>> GetByBusinessTraderAsync(int businessTraderId) =>
            await _set.Where(d => d.BusinessTraderId == businessTraderId)
                      .OrderByDescending(d => d.UploadedDate).ToListAsync();

        public async Task<IEnumerable<TraderDocument>> GetPendingAsync() =>
            await _set.Include(d => d.BusinessTrader)
                      .Where(d => d.VerificationStatus == "Pending").ToListAsync();
    }

    public class LicenseApplicationRepository : Repository<LicenseApplication>, ILicenseApplicationRepository
    {
        public LicenseApplicationRepository(ApplicationDbContext ctx) : base(ctx) { }

        public async Task<IEnumerable<LicenseApplication>> GetByBusinessTraderAsync(int businessTraderId) =>
            await _set.Include(a => a.TradeLicense)
                      .Where(a => a.BusinessTraderId == businessTraderId)
                      .OrderByDescending(a => a.SubmittedDate).ToListAsync();

        public async Task<IEnumerable<LicenseApplication>> GetByLicenseAsync(int tradeLicenseId) =>
            await _set.Include(a => a.BusinessTrader)
                      .Where(a => a.TradeLicenseId == tradeLicenseId).ToListAsync();

        public async Task<IEnumerable<LicenseApplication>> GetByStatusAsync(string status) =>
            await _set.Include(a => a.BusinessTrader).Include(a => a.TradeLicense)
                      .Where(a => a.Status == status).ToListAsync();

        public async Task<LicenseApplication?> GetWithDetailsAsync(int id) =>
            await _set.Include(a => a.BusinessTrader).Include(a => a.TradeLicense).ThenInclude(l => l.Business)
                      .FirstOrDefaultAsync(a => a.Id == id);

        public async Task<IEnumerable<LicenseApplication>> GetAllWithDetailsAsync() =>
            await _set.Include(a => a.BusinessTrader).Include(a => a.TradeLicense).ThenInclude(l => l.Business)
                      .OrderByDescending(a => a.SubmittedDate).ToListAsync();
    }

    public class SubsidyRepository : Repository<Subsidy>, ISubsidyRepository
    {
        public SubsidyRepository(ApplicationDbContext ctx) : base(ctx) { }

        public async Task<IEnumerable<Subsidy>> GetByBusinessTraderAsync(int businessTraderId) =>
            await _set.Include(s => s.TradeProgram).Where(s => s.BusinessTraderId == businessTraderId).ToListAsync();

        public async Task<IEnumerable<Subsidy>> GetByProgramAsync(int tradeProgramId) =>
            await _set.Include(s => s.BusinessTrader).Where(s => s.TradeProgramId == tradeProgramId).ToListAsync();
    }
}
