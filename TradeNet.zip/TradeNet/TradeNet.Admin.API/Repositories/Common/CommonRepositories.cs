using Microsoft.EntityFrameworkCore;
using TradeNetProject.Data;
using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Models;

namespace TradeNetProject.Repositories.Common
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(ApplicationDbContext ctx) : base(ctx) { }
        public async Task<User?> GetByEmailAsync(string email) =>
            await _set.FirstOrDefaultAsync(u => u.Email == email);
        public async Task<IEnumerable<User>> GetByRoleAsync(string role) =>
            await _set.Where(u => u.Role == role).ToListAsync();
    }

    public class SystemLogRepository : Repository<SystemLog>, ISystemLogRepository
    {
        public SystemLogRepository(ApplicationDbContext ctx) : base(ctx) { }
    }

    public class NotificationRepository : Repository<Notification>, INotificationRepository
    {
        public NotificationRepository(ApplicationDbContext ctx) : base(ctx) { }
        public async Task<IEnumerable<Notification>> GetByUserAsync(int userId) =>
            await _set.Where(n => n.UserId == userId).OrderByDescending(n => n.CreatedDate).ToListAsync();
        public async Task<int> GetUnreadCountAsync(int userId) =>
            await _set.CountAsync(n => n.UserId == userId && !n.IsRead);
        public async Task MarkAllReadAsync(int userId)
        {
            var unread = await _set.Where(n => n.UserId == userId && !n.IsRead).ToListAsync();
            foreach (var n in unread) n.IsRead = true;
            await _ctx.SaveChangesAsync();
        }
    }

    public class AuditRepository : Repository<Audit>, IAuditRepository
    {
        public AuditRepository(ApplicationDbContext ctx) : base(ctx) { }
        public async Task<IEnumerable<Audit>> GetByOfficerAsync(int officerId) =>
            await _set.Where(a => a.OfficerId == officerId).ToListAsync();
        public async Task<IEnumerable<Audit>> GetByStatusAsync(string status) =>
            await _set.Where(a => a.Status == status).ToListAsync();
    }

    public class ReportRepository : Repository<Report>, IReportRepository
    {
        public ReportRepository(ApplicationDbContext ctx) : base(ctx) { }
    }

    public class TradeProgramRepository : Repository<TradeProgram>, ITradeProgramRepository
    {
        public TradeProgramRepository(ApplicationDbContext ctx) : base(ctx) { }
    }

    public class ResourceRepository : Repository<Resource>, IResourceRepository
    {
        public ResourceRepository(ApplicationDbContext ctx) : base(ctx) { }
    }

    public class ComplianceRecordRepository : Repository<ComplianceRecord>, IComplianceRecordRepository
    {
        public ComplianceRecordRepository(ApplicationDbContext ctx) : base(ctx) { }
    }

    public class ComplaintRepository : Repository<Complaint>, IComplaintRepository
    {
        public ComplaintRepository(ApplicationDbContext ctx) : base(ctx) { }
    }

    public class ViolationRepository : Repository<Violation>, IViolationRepository
    {
        public ViolationRepository(ApplicationDbContext ctx) : base(ctx) { }
    }
}
