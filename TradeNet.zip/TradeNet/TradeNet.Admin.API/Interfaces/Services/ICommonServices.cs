using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Interfaces.Services
{
    public interface IAccountService
    {
        Task<(bool Success, string Message, User? User)> LoginAsync(string email, string password);
        Task<User?> GetByIdAsync(int id);
        Task<IEnumerable<User>> GetAllUsersAsync();
        Task<(bool Success, string Message)> CreateUserAsync(CreateUserViewModel model);
        Task<(bool Success, string Message)> UpdateUserAsync(User user);
        Task<(bool Success, string Message)> DeactivateUserAsync(int id);
        Task<(bool Success, string Message)> DeleteUserAsync(int id);
    }

    public interface INotificationService
    {
        Task<IEnumerable<Notification>> GetByUserAsync(int userId);
        Task<int> GetUnreadCountAsync(int userId);
        Task CreateAsync(int userId, string message, string category, int? entityId = null, string? entityType = null);
        Task MarkAllReadAsync(int userId);
    }

    public interface ISystemLogService
    {
        Task LogAsync(int userId, string action, string? resource = null, string? ip = null);
        Task<IEnumerable<SystemLog>> GetRecentAsync(int count = 50);
    }

    public interface ITradeProgramService
    {
        Task<IEnumerable<TradeProgram>> GetAllAsync();
        Task<TradeProgram?> GetByIdAsync(int id);
        Task<(bool Success, string Message)> CreateAsync(TradeProgram program);
        Task<(bool Success, string Message)> UpdateAsync(TradeProgram program);
        Task<(bool Success, string Message)> DeleteAsync(int id);
    }

    public interface IResourceService
    {
        Task<IEnumerable<Resource>> GetAllAsync();
        Task<Resource?> GetByIdAsync(int id);
        Task<IEnumerable<Resource>> GetByProgramAsync(int programId);
        Task<(bool Success, string Message)> CreateAsync(Resource r);
        Task<(bool Success, string Message)> UpdateAsync(Resource r);
        Task<(bool Success, string Message)> DeleteAsync(int id);
    }

    public interface IReportService
    {
        Task<IEnumerable<Report>> GetAllAsync();
        Task<Report?> GetByIdAsync(int id);
        Task<(bool Success, string Message)> GenerateAsync(Report report);
    }
}
