using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Interfaces.Services
{
    public interface IBusinessTraderService
    {
        Task<BusinessTrader?> GetByIdAsync(int id);
        Task<BusinessTrader?> GetByUserIdAsync(int userId);
        Task<(bool Success, string Message)> CreateProfileAsync(int userId, string name, string email);
        Task<(bool Success, string Message)> UpdateProfileAsync(BusinessTrader trader);

        Task<IEnumerable<TraderDocument>> GetDocumentsAsync(int businessTraderId);
        Task<(bool Success, string Message)> UploadDocumentAsync(int businessTraderId, string docType, string fileName, string filePath);

        Task<IEnumerable<LicenseApplication>> GetApplicationsAsync(int businessTraderId);
        Task<(bool Success, string Message)> ApplyForLicenseAsync(int businessTraderId, int tradeLicenseId, string? notes);
        Task<(bool Success, string Message)> WithdrawApplicationAsync(int applicationId);

        Task<IEnumerable<Subsidy>> GetSubsidiesAsync(int businessTraderId);
        Task<(bool Success, string Message)> ApplyForSubsidyAsync(int businessTraderId, int programId);

        Task<IEnumerable<Complaint>> GetMyComplaintsAsync(int userId);
        Task<(bool Success, string Message, Complaint? Complaint)> RaiseComplaintAsync(int userId, int? businessId, string description);

        Task<BusinessTraderDashboardViewModel> GetDashboardAsync(int userId);
    }

    public interface IBusinessService
    {
        Task<Business?> GetByIdAsync(int id);
        Task<IEnumerable<Business>> GetByBusinessTraderAsync(int businessTraderId);
        Task<(bool Success, string Message, Business? Business)> RegisterAsync(int businessTraderId, BusinessRegistrationRequest req);
        Task<(bool Success, string Message)> UpdateAsync(Business business);

        Task<IEnumerable<BusinessDocument>> GetDocumentsAsync(int businessId);
        Task<(bool Success, string Message, BusinessDocument? Document)> UploadDocumentAsync(int businessId, string docType, string fileName, string fileUrl);
    }

    public interface ITradeLicenseService
    {
        Task<IEnumerable<TradeLicense>> GetAllAsync();
        Task<TradeLicense?> GetByIdAsync(int id);
        Task<IEnumerable<TradeLicense>> GetByBusinessAsync(int businessId);
        Task<IEnumerable<TradeLicense>> SearchAsync(string keyword, string licenseType, string category);
        Task<(bool Success, string Message)> CreateAsync(TradeLicense license);
        Task<(bool Success, string Message)> UpdateAsync(TradeLicense license);
        Task<(bool Success, string Message)> ApproveAsync(int id, DateTime expiryDate);
        Task<(bool Success, string Message)> RejectAsync(int id, string reason);
    }

    public interface ILicenseApplicationService
    {
        Task<IEnumerable<LicenseApplication>> GetAllAsync();
        Task<LicenseApplication?> GetByIdAsync(int id);
        Task<IEnumerable<LicenseApplication>> GetByBusinessTraderAsync(int businessTraderId);
        Task<IEnumerable<LicenseApplication>> GetByStatusAsync(string status);
        Task<(bool Success, string Message)> UpdateStatusAsync(int id, string status, string? notes);
        Task<(bool Success, string Message)> WithdrawAsync(int id);
    }

    public interface ITransactionService
    {
        Task<IEnumerable<Transaction>> GetAllAsync();
        Task<Transaction?> GetByIdAsync(int id);
        Task<IEnumerable<Transaction>> GetByBusinessAsync(int businessId);
        Task<IEnumerable<Transaction>> GetSuspiciousAsync();
        Task<(bool Success, string Message, Transaction? Transaction)> CreateAsync(TransactionCreateRequest req);
        Task<(bool Success, string Message)> UpdateStatusAsync(int id, string status, string? notes, int officerId);
        Task<(bool Success, string Message)> FlagAsync(int id, int officerId, string notes);
    }

    public interface ISubsidyService
    {
        Task<IEnumerable<Subsidy>> GetAllAsync();
        Task<Subsidy?> GetByIdAsync(int id);
        Task<IEnumerable<Subsidy>> GetByBusinessTraderAsync(int businessTraderId);
        Task<IEnumerable<Subsidy>> GetByProgramAsync(int programId);
        Task<IEnumerable<Subsidy>> GetPendingAsync();
        Task<(bool Success, string Message)> ApplyAsync(int businessTraderId, int programId);
        Task<(bool Success, string Message)> ApproveAsync(int id, decimal amount, INotificationService notificationService);
        Task<(bool Success, string Message)> RejectAsync(int id, string reason, INotificationService notificationService);
    }

    public interface IAdminService
    {
        Task<IEnumerable<Business>> GetAllBusinessesAsync(string? status = null);
        Task<(bool Success, string Message)> SuspendBusinessAsync(int businessId, string reason);
        Task<(bool Success, string Message)> ReinstateBusinessAsync(int businessId);
        Task<(bool Success, string Message)> BroadcastNotificationAsync(string targetRole, string message, INotificationService notificationService);
        Task<DashboardViewModel> GetFullDashboardAsync();
    }

    public interface ITradeOfficerService
    {
        Task<IEnumerable<TraderDocument>> GetPendingTraderDocumentsAsync();
        Task<IEnumerable<BusinessDocument>> GetPendingBusinessDocumentsAsync();
        Task<(bool Success, string Message)> VerifyTraderDocumentAsync(int documentId, int officerId);
        Task<(bool Success, string Message)> RejectTraderDocumentAsync(int documentId, int officerId, string reason);
        Task<(bool Success, string Message)> VerifyBusinessDocumentAsync(int documentId, int officerId);
        Task<(bool Success, string Message)> RejectBusinessDocumentAsync(int documentId, int officerId, string reason);

        Task<IEnumerable<LicenseApplication>> GetPendingApplicationsAsync();
        Task<(bool Success, string Message)> ApproveApplicationAsync(int applicationId, int officerId, DateTime? expiryDate, string? notes);
        Task<(bool Success, string Message)> RejectApplicationAsync(int applicationId, int officerId, string reason);

        Task<IEnumerable<Transaction>> GetTransactionsAsync();
        Task<IEnumerable<Transaction>> GetSuspiciousTransactionsAsync();
        Task<(bool Success, string Message)> FlagTransactionAsync(int transactionId, int officerId, string notes);
        Task<(bool Success, string Message)> ClearTransactionFlagAsync(int transactionId, int officerId);

        Task<IEnumerable<Business>> GetAllBusinessesAsync();
        Task<(bool Success, string Message)> VerifyBusinessAsync(int businessId, int officerId);
        Task<(bool Success, string Message)> RejectBusinessAsync(int businessId, int officerId, string reason);

        Task<TradeOfficerDashboardViewModel> GetDashboardAsync(int userId);
    }

    public interface IProgramManagerService
    {
        Task<IEnumerable<TradeProgram>> GetAllProgramsAsync();
        Task<TradeProgram?> GetProgramByIdAsync(int id);
        Task<(bool Success, string Message, TradeProgram? Program)> CreateProgramAsync(TradeProgram program);
        Task<(bool Success, string Message)> UpdateProgramAsync(TradeProgram program);
        Task<(bool Success, string Message)> DeleteProgramAsync(int id);

        Task<IEnumerable<Resource>> GetResourcesAsync(int? programId = null);
        Task<(bool Success, string Message)> AddResourceAsync(Resource r);
        Task<(bool Success, string Message)> UpdateResourceAsync(Resource r);
        Task<(bool Success, string Message)> DeleteResourceAsync(int id);

        Task<IEnumerable<Subsidy>> GetPendingSubsidiesAsync();
        Task<(bool Success, string Message)> ApproveSubsidyAsync(int subsidyId, int managerUserId, decimal amount, INotificationService notificationService);
        Task<(bool Success, string Message)> RejectSubsidyAsync(int subsidyId, int managerUserId, string reason, INotificationService notificationService);

        Task<ProgramManagerDashboardViewModel> GetDashboardAsync(int userId);
    }

    public interface IComplianceOfficerService
    {
        Task<IEnumerable<Business>> GetAllBusinessesAsync();
        Task<IEnumerable<Business>> GetBusinessesByStatusAsync(string status);
        Task<Business?> GetBusinessDetailsAsync(int businessId);
        Task<(bool Success, string Message)> FlagBusinessNonCompliantAsync(int businessId, int officerId, string reason);
        Task<(bool Success, string Message)> ClearNonComplianceFlagAsync(int businessId, int officerId, string notes);

        Task<IEnumerable<Complaint>> GetAllComplaintsAsync();
        Task<(bool Success, string Message)> ResolveComplaintAsync(int complaintId, int officerId, string resolution);

        Task<IEnumerable<ComplianceRecord>> GetAllComplianceRecordsAsync();
        Task<(bool Success, string Message)> CreateComplianceRecordAsync(ComplianceRecord record);
        Task<(bool Success, string Message)> UpdateComplianceResultAsync(int recordId, string result, string notes);

        Task<IEnumerable<Violation>> GetAllViolationsAsync();
        Task<(bool Success, string Message)> RecordViolationAsync(Violation violation);

        Task<ComplianceDashboardViewModel> GetDashboardAsync(int userId);
    }

    public interface IGovernmentAuditorService
    {
        Task<IEnumerable<Audit>> GetAllAuditsAsync();
        Task<Audit?> GetAuditByIdAsync(int auditId);
        Task<(bool Success, string Message, Audit? Audit)> CreateAuditAsync(int officerId, string title, string scope, string findings);
        Task<(bool Success, string Message)> UpdateAuditStatusAsync(int auditId, string newStatus);
        Task<(bool Success, string Message)> RecordAuditFindingsAsync(int auditId, string findings);

        Task<IEnumerable<ComplianceRecord>> GetComplianceRecordsAsync();
        Task<(bool Success, string Message)> EscalateComplianceIssueAsync(int entityId, string entityType, int auditorId, string notes);

        Task<IEnumerable<TradeProgram>> GetAllProgramsAsync();
        Task<(bool Success, string Message)> FlagProgramForReviewAsync(int programId, int auditorId, string reason);

        Task<IEnumerable<Report>> GetAuditReportsAsync();
        Task<(bool Success, string Message, Report? Report)> GenerateAuditReportAsync(int auditorId, string reportName, string reportType, string content);

        Task<IEnumerable<Business>> GetAllBusinessesAsync();
        Task<AuditorDashboardViewModel> GetDashboardAsync(int userId);
    }
}
