using TradeNetProject.Models;

namespace TradeNetProject.Interfaces.Repositories
{
    public interface IBusinessRepository : IRepository<Business>
    {
        Task<IEnumerable<Business>> GetByBusinessTraderAsync(int businessTraderId);
        Task<IEnumerable<Business>> GetByStatusAsync(string status);
        Task<Business?> GetWithDetailsAsync(int id);
    }

    public interface IBusinessDocumentRepository : IRepository<BusinessDocument>
    {
        Task<IEnumerable<BusinessDocument>> GetByBusinessAsync(int businessId);
        Task<IEnumerable<BusinessDocument>> GetPendingAsync();
    }

    public interface ITradeLicenseRepository : IRepository<TradeLicense>
    {
        Task<IEnumerable<TradeLicense>> GetByBusinessAsync(int businessId);
        Task<IEnumerable<TradeLicense>> GetByStatusAsync(string status);
        Task<IEnumerable<TradeLicense>> SearchAsync(string keyword, string licenseType, string category);
    }

    public interface ITransactionRepository : IRepository<Transaction>
    {
        Task<IEnumerable<Transaction>> GetByBusinessAsync(int businessId);
        Task<IEnumerable<Transaction>> GetByStatusAsync(string status);
        Task<IEnumerable<Transaction>> GetSuspiciousAsync();
    }
}
