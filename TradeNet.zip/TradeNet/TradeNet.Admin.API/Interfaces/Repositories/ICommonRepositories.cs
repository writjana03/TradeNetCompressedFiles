using TradeNetProject.Models;

namespace TradeNetProject.Interfaces.Repositories
{
    public interface IUserRepository : IRepository<User>
    {
        Task<User?> GetByEmailAsync(string email);
        Task<IEnumerable<User>> GetByRoleAsync(string role);
    }

    public interface ISystemLogRepository : IRepository<SystemLog> { }
    public interface INotificationRepository : IRepository<Notification>
    {
        Task<IEnumerable<Notification>> GetByUserAsync(int userId);
        Task<int> GetUnreadCountAsync(int userId);
        Task MarkAllReadAsync(int userId);
    }

    public interface IAuditRepository : IRepository<Audit>
    {
        Task<IEnumerable<Audit>> GetByOfficerAsync(int officerId);
        Task<IEnumerable<Audit>> GetByStatusAsync(string status);
    }

    public interface IReportRepository : IRepository<Report> { }
    public interface ITradeProgramRepository : IRepository<TradeProgram> { }
    public interface IResourceRepository : IRepository<Resource> { }
    public interface IComplianceRecordRepository : IRepository<ComplianceRecord> { }
    public interface IComplaintRepository : IRepository<Complaint> { }
    public interface IViolationRepository : IRepository<Violation> { }
}
