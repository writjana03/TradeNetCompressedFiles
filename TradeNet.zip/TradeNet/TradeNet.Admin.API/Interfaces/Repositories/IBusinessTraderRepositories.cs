using TradeNetProject.Models;

namespace TradeNetProject.Interfaces.Repositories
{
    public interface IBusinessTraderRepository : IRepository<BusinessTrader>
    {
        Task<BusinessTrader?> GetByUserIdAsync(int userId);
        Task<BusinessTrader?> GetWithDetailsAsync(int id);
    }

    public interface ITraderDocumentRepository : IRepository<TraderDocument>
    {
        Task<IEnumerable<TraderDocument>> GetByBusinessTraderAsync(int businessTraderId);
        Task<IEnumerable<TraderDocument>> GetPendingAsync();
    }

    public interface ILicenseApplicationRepository : IRepository<LicenseApplication>
    {
        Task<IEnumerable<LicenseApplication>> GetByBusinessTraderAsync(int businessTraderId);
        Task<IEnumerable<LicenseApplication>> GetByLicenseAsync(int tradeLicenseId);
        Task<IEnumerable<LicenseApplication>> GetByStatusAsync(string status);
        Task<LicenseApplication?> GetWithDetailsAsync(int id);
        Task<IEnumerable<LicenseApplication>> GetAllWithDetailsAsync();
    }

    public interface ISubsidyRepository : IRepository<Subsidy>
    {
        Task<IEnumerable<Subsidy>> GetByBusinessTraderAsync(int businessTraderId);
        Task<IEnumerable<Subsidy>> GetByProgramAsync(int tradeProgramId);
    }
}
