using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Services.Common
{
    public class AccountService : IAccountService
    {
        private readonly IUserRepository _users;
        public AccountService(IUserRepository users) { _users = users; }

        public async Task<(bool, string, User?)> LoginAsync(string email, string password)
        {
            var user = await _users.GetByEmailAsync(email);
            if (user == null) return (false, "Invalid email or password.", null);
            if (user.Password != password) return (false, "Invalid email or password.", null);
            if (user.Status != "Active") return (false, "Account is inactive.", null);
            return (true, "Login successful.", user);
        }

        public async Task<User?> GetByIdAsync(int id) => await _users.GetByIdAsync(id);
        public async Task<IEnumerable<User>> GetAllUsersAsync() => await _users.GetAllAsync();

        public async Task<(bool, string)> CreateUserAsync(CreateUserViewModel model)
        {
            if (await _users.AnyAsync(u => u.Email == model.Email))
                return (false, "Email already exists.");
            await _users.AddAsync(new User
            {
                FullName = model.FullName, Email = model.Email, Password = model.Password,
                Role = model.Role, Phone = model.Phone
            });
            await _users.SaveAsync();
            return (true, "User created.");
        }

        public async Task<(bool, string)> UpdateUserAsync(User user)
        {
            _users.Update(user);
            await _users.SaveAsync();
            return (true, "User updated.");
        }

        public async Task<(bool, string)> DeactivateUserAsync(int id)
        {
            var user = await _users.GetByIdAsync(id);
            if (user == null) return (false, "User not found.");
            user.Status = "Inactive";
            _users.Update(user);
            await _users.SaveAsync();
            return (true, "User deactivated.");
        }

        public async Task<(bool, string)> DeleteUserAsync(int id)
        {
            var user = await _users.GetByIdAsync(id);
            if (user == null) return (false, "User not found.");
            _users.Remove(user);
            await _users.SaveAsync();
            return (true, "User deleted.");
        }
    }

    public class NotificationService : INotificationService
    {
        private readonly INotificationRepository _n;
        public NotificationService(INotificationRepository n) { _n = n; }

        public async Task<IEnumerable<Notification>> GetByUserAsync(int userId) => await _n.GetByUserAsync(userId);
        public async Task<int> GetUnreadCountAsync(int userId) => await _n.GetUnreadCountAsync(userId);

        public async Task CreateAsync(int userId, string message, string category, int? entityId = null, string? entityType = null)
        {
            await _n.AddAsync(new Notification
            {
                UserId = userId, Message = message, Category = category,
                EntityId = entityId, EntityType = entityType
            });
            await _n.SaveAsync();
        }

        public async Task MarkAllReadAsync(int userId) => await _n.MarkAllReadAsync(userId);
    }

    public class SystemLogService : ISystemLogService
    {
        private readonly ISystemLogRepository _logs;
        public SystemLogService(ISystemLogRepository l) { _logs = l; }

        public async Task LogAsync(int userId, string action, string? resource = null, string? ip = null)
        {
            await _logs.AddAsync(new SystemLog { UserId = userId, Action = action, Resource = resource, IpAddress = ip });
            await _logs.SaveAsync();
        }

        public async Task<IEnumerable<SystemLog>> GetRecentAsync(int count = 50) =>
            (await _logs.GetAllAsync()).OrderByDescending(l => l.Timestamp).Take(count);
    }

    public class TradeProgramService : ITradeProgramService
    {
        private readonly ITradeProgramRepository _p;
        public TradeProgramService(ITradeProgramRepository p) { _p = p; }

        public async Task<IEnumerable<TradeProgram>> GetAllAsync() => await _p.GetAllAsync();
        public async Task<TradeProgram?> GetByIdAsync(int id) => await _p.GetByIdAsync(id);

        public async Task<(bool, string)> CreateAsync(TradeProgram program)
        {
            await _p.AddAsync(program);
            await _p.SaveAsync();
            return (true, "Program created.");
        }

        public async Task<(bool, string)> UpdateAsync(TradeProgram program)
        {
            _p.Update(program);
            await _p.SaveAsync();
            return (true, "Program updated.");
        }

        public async Task<(bool, string)> DeleteAsync(int id)
        {
            var p = await _p.GetByIdAsync(id);
            if (p == null) return (false, "Not found.");
            _p.Remove(p);
            await _p.SaveAsync();
            return (true, "Deleted.");
        }
    }

    public class ResourceService : IResourceService
    {
        private readonly IResourceRepository _r;
        public ResourceService(IResourceRepository r) { _r = r; }

        public async Task<IEnumerable<Resource>> GetAllAsync() => await _r.GetAllAsync();
        public async Task<Resource?> GetByIdAsync(int id) => await _r.GetByIdAsync(id);
        public async Task<IEnumerable<Resource>> GetByProgramAsync(int programId) =>
            await _r.FindAsync(x => x.TradeProgramId == programId);

        public async Task<(bool, string)> CreateAsync(Resource r)
        {
            await _r.AddAsync(r); await _r.SaveAsync();
            return (true, "Resource created.");
        }

        public async Task<(bool, string)> UpdateAsync(Resource r)
        {
            _r.Update(r); await _r.SaveAsync();
            return (true, "Updated.");
        }

        public async Task<(bool, string)> DeleteAsync(int id)
        {
            var r = await _r.GetByIdAsync(id);
            if (r == null) return (false, "Not found.");
            _r.Remove(r); await _r.SaveAsync();
            return (true, "Deleted.");
        }
    }

    public class ReportService : IReportService
    {
        private readonly IReportRepository _r;
        public ReportService(IReportRepository r) { _r = r; }

        public async Task<IEnumerable<Report>> GetAllAsync() => await _r.GetAllAsync();
        public async Task<Report?> GetByIdAsync(int id) => await _r.GetByIdAsync(id);

        public async Task<(bool, string)> GenerateAsync(Report report)
        {
            await _r.AddAsync(report); await _r.SaveAsync();
            return (true, "Report generated.");
        }
    }
}
