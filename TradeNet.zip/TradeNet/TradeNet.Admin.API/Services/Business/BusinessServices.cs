using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Services.Business
{
    public class BusinessService : IBusinessService
    {
        private readonly IBusinessRepository _biz;
        private readonly IBusinessDocumentRepository _docs;
        public BusinessService(IBusinessRepository biz, IBusinessDocumentRepository docs)
        {
            _biz = biz; _docs = docs;
        }

        public async Task<TradeNetProject.Models.Business?> GetByIdAsync(int id) => await _biz.GetWithDetailsAsync(id);
        public async Task<IEnumerable<TradeNetProject.Models.Business>> GetByBusinessTraderAsync(int btId) =>
            await _biz.GetByBusinessTraderAsync(btId);

        public async Task<(bool, string, TradeNetProject.Models.Business?)> RegisterAsync(int btId, BusinessRegistrationRequest req)
        {
            var b = new TradeNetProject.Models.Business
            {
                BusinessTraderId = btId,
                BusinessName = req.BusinessName,
                BusinessType = req.BusinessType,
                Address = req.Address,
                ContactInfo = req.ContactInfo,
                PhoneNumber = req.PhoneNumber,
                Description = req.Description,
                Status = "Pending",
                ComplianceStatus = "Compliant",
                RegistrationDate = DateTime.Now
            };
            await _biz.AddAsync(b);
            await _biz.SaveAsync();
            return (true, "Business registered.", b);
        }

        public async Task<(bool, string)> UpdateAsync(TradeNetProject.Models.Business business)
        {
            _biz.Update(business);
            await _biz.SaveAsync();
            return (true, "Updated.");
        }

        public async Task<IEnumerable<BusinessDocument>> GetDocumentsAsync(int businessId) =>
            await _docs.GetByBusinessAsync(businessId);

        public async Task<(bool, string, BusinessDocument?)> UploadDocumentAsync(int businessId, string docType, string fileName, string fileUrl)
        {
            var biz = await _biz.GetByIdAsync(businessId);
            if (biz == null) return (false, "Business not found.", null);
            var d = new BusinessDocument
            {
                BusinessId = businessId, DocType = docType, FileName = fileName,
                FileURL = fileUrl, VerificationStatus = "Pending"
            };
            await _docs.AddAsync(d);
            // Set business back to Pending until reviewed
            if (biz.Status != "Pending")
            {
                biz.Status = "Pending";
                _biz.Update(biz);
            }
            await _docs.SaveAsync();
            return (true, "Uploaded.", d);
        }
    }

    public class TradeLicenseService : ITradeLicenseService
    {
        private readonly ITradeLicenseRepository _l;
        public TradeLicenseService(ITradeLicenseRepository l) { _l = l; }

        public async Task<IEnumerable<TradeLicense>> GetAllAsync() => await _l.GetAllAsync();
        public async Task<TradeLicense?> GetByIdAsync(int id) => await _l.GetByIdAsync(id);
        public async Task<IEnumerable<TradeLicense>> GetByBusinessAsync(int businessId) => await _l.GetByBusinessAsync(businessId);
        public async Task<IEnumerable<TradeLicense>> SearchAsync(string keyword, string licenseType, string category) =>
            await _l.SearchAsync(keyword, licenseType, category);

        public async Task<(bool, string)> CreateAsync(TradeLicense license)
        {
            license.PostedDate = DateTime.Now;
            license.Status = string.IsNullOrEmpty(license.Status) ? "Available" : license.Status;
            await _l.AddAsync(license); await _l.SaveAsync();
            return (true, "License created.");
        }

        public async Task<(bool, string)> UpdateAsync(TradeLicense license)
        {
            _l.Update(license); await _l.SaveAsync();
            return (true, "Updated.");
        }

        public async Task<(bool, string)> ApproveAsync(int id, DateTime expiryDate)
        {
            var l = await _l.GetByIdAsync(id);
            if (l == null) return (false, "Not found.");
            l.Status = "Approved";
            l.IssuedDate = DateTime.Now;
            l.ExpiryDate = expiryDate;
            _l.Update(l); await _l.SaveAsync();
            return (true, "License approved.");
        }

        public async Task<(bool, string)> RejectAsync(int id, string reason)
        {
            var l = await _l.GetByIdAsync(id);
            if (l == null) return (false, "Not found.");
            l.Status = "Rejected";
            _l.Update(l); await _l.SaveAsync();
            return (true, "License rejected.");
        }
    }

    public class TransactionService : ITransactionService
    {
        private readonly ITransactionRepository _tx;
        public TransactionService(ITransactionRepository tx) { _tx = tx; }

        public async Task<IEnumerable<Transaction>> GetAllAsync() => await _tx.GetAllAsync();
        public async Task<Transaction?> GetByIdAsync(int id) => await _tx.GetByIdAsync(id);
        public async Task<IEnumerable<Transaction>> GetByBusinessAsync(int businessId) => await _tx.GetByBusinessAsync(businessId);
        public async Task<IEnumerable<Transaction>> GetSuspiciousAsync() => await _tx.GetSuspiciousAsync();

        public async Task<(bool, string, Transaction?)> CreateAsync(TransactionCreateRequest req)
        {
            var t = new Transaction
            {
                BusinessId = req.BusinessId, TransactionType = req.TransactionType,
                Amount = req.Amount, Counterparty = req.Counterparty,
                InvoiceNumber = req.InvoiceNumber, Description = req.Description,
                Status = "Pending"
            };
            await _tx.AddAsync(t); await _tx.SaveAsync();
            return (true, "Transaction recorded.", t);
        }

        public async Task<(bool, string)> UpdateStatusAsync(int id, string status, string? notes, int officerId)
        {
            var t = await _tx.GetByIdAsync(id);
            if (t == null) return (false, "Not found.");
            t.Status = status; t.OfficerNotes = notes; t.MonitoredByUserId = officerId;
            _tx.Update(t); await _tx.SaveAsync();
            return (true, "Updated.");
        }

        public async Task<(bool, string)> FlagAsync(int id, int officerId, string notes)
        {
            var t = await _tx.GetByIdAsync(id);
            if (t == null) return (false, "Not found.");
            t.Status = "Flagged"; t.OfficerNotes = notes; t.MonitoredByUserId = officerId;
            _tx.Update(t); await _tx.SaveAsync();
            return (true, "Transaction flagged.");
        }
    }
}
