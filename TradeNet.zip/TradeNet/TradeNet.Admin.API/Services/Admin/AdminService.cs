using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Services.Admin
{
    public class AdminService : IAdminService
    {
        private readonly IBusinessRepository _biz;
        private readonly IUserRepository _users;
        private readonly ITradeLicenseRepository _licenses;
        private readonly ILicenseApplicationRepository _apps;
        private readonly ITransactionRepository _tx;
        private readonly ITradeProgramRepository _programs;
        private readonly IAuditRepository _audits;
        private readonly ISubsidyRepository _subs;
        private readonly ISystemLogRepository _logs;
        private readonly IComplianceRecordRepository _compRecs;
        private readonly IComplaintRepository _complaints;
        private readonly IViolationRepository _violations;
        private readonly IReportRepository _reports;
        private readonly IBusinessTraderRepository _traders;

        public AdminService(
            IBusinessRepository biz, IUserRepository users, ITradeLicenseRepository licenses,
            ILicenseApplicationRepository apps, ITransactionRepository tx, ITradeProgramRepository programs,
            IAuditRepository audits, ISubsidyRepository subs, ISystemLogRepository logs,
            IComplianceRecordRepository compRecs, IComplaintRepository complaints,
            IViolationRepository violations, IReportRepository reports, IBusinessTraderRepository traders)
        {
            _biz = biz; _users = users; _licenses = licenses; _apps = apps; _tx = tx;
            _programs = programs; _audits = audits; _subs = subs; _logs = logs;
            _compRecs = compRecs; _complaints = complaints; _violations = violations;
            _reports = reports; _traders = traders;
        }

        public async Task<IEnumerable<TradeNetProject.Models.Business>> GetAllBusinessesAsync(string? status = null) =>
            string.IsNullOrWhiteSpace(status) ? await _biz.GetAllAsync() : await _biz.GetByStatusAsync(status);

        public async Task<(bool, string)> SuspendBusinessAsync(int businessId, string reason)
        {
            var b = await _biz.GetByIdAsync(businessId);
            if (b == null) return (false, "Business not found.");
            if (b.Status == "Suspended") return (false, "Already suspended.");
            b.Status = "Suspended";
            b.Description = $"[SUSPENDED] {reason} — {DateTime.Now:yyyy-MM-dd HH:mm}";
            _biz.Update(b);
            await _biz.SaveAsync();
            return (true, $"Business '{b.BusinessName}' suspended.");
        }

        public async Task<(bool, string)> ReinstateBusinessAsync(int businessId)
        {
            var b = await _biz.GetByIdAsync(businessId);
            if (b == null) return (false, "Business not found.");
            if (b.Status != "Suspended") return (false, "Business is not suspended.");
            b.Status = "Active";
            b.Description = b.Description?.Replace("[SUSPENDED] ", "").Split("—")[0].Trim();
            _biz.Update(b);
            await _biz.SaveAsync();
            return (true, $"Business '{b.BusinessName}' reinstated.");
        }

        public async Task<(bool, string)> BroadcastNotificationAsync(string targetRole, string message, INotificationService ns)
        {
            IEnumerable<User> targets = targetRole.Equals("All", StringComparison.OrdinalIgnoreCase)
                ? await _users.GetAllAsync()
                : await _users.GetByRoleAsync(targetRole);
            var recipients = targets.Where(u => u.Status == "Active").ToList();
            if (!recipients.Any()) return (false, $"No active users found for role '{targetRole}'.");
            foreach (var u in recipients)
                await ns.CreateAsync(u.Id, message, "Admin", null, "Broadcast");
            return (true, $"Notification sent to {recipients.Count} user(s).");
        }

        public async Task<DashboardViewModel> GetFullDashboardAsync()
        {
            var users = (await _users.GetAllAsync()).ToList();
            var businesses = (await _biz.GetAllAsync()).ToList();
            var traders = (await _traders.GetAllAsync()).ToList();
            var licenses = (await _licenses.GetAllAsync()).ToList();
            var apps = (await _apps.GetAllAsync()).ToList();
            var tx = (await _tx.GetAllAsync()).ToList();
            var programs = (await _programs.GetAllAsync()).ToList();
            var audits = (await _audits.GetAllAsync()).ToList();
            var subs = (await _subs.GetAllAsync()).ToList();
            var comps = (await _complaints.GetAllAsync()).ToList();
            var viols = (await _violations.GetAllAsync()).ToList();
            var compRecs = (await _compRecs.GetAllAsync()).ToList();
            var reports = (await _reports.GetAllAsync()).ToList();
            var logs = (await _logs.GetAllAsync()).OrderByDescending(l => l.Timestamp).Take(10).ToList();

            return new DashboardViewModel
            {
                TotalUsers = users.Count,
                ActiveUsers = users.Count(u => u.Status == "Active"),
                TotalBusinessTraders = traders.Count,
                TotalBusinesses = businesses.Count,
                TotalLicenses = licenses.Count,
                ActiveLicenses = licenses.Count(l => l.Status == "Approved"),
                TotalApplications = apps.Count,
                PendingApplications = apps.Count(a => a.Status == "Pending"),
                TotalTransactions = tx.Count,
                FlaggedTransactions = tx.Count(t => t.Status == "Flagged"),
                TotalPrograms = programs.Count,
                ActivePrograms = programs.Count(p => p.Status == "Active"),
                TotalAudits = audits.Count,
                OpenAudits = audits.Count(a => a.Status == "Open"),
                TotalReports = reports.Count,
                TotalComplaints = comps.Count,
                PendingComplaints = comps.Count(c => c.Status == "Pending"),
                TotalViolations = viols.Count,
                TotalBudget = programs.Sum(p => p.TotalBudget),
                TotalSubsidiesPaid = subs.Where(s => s.Status == "Approved").Sum(s => s.Amount),
                RecentLicenses = licenses.OrderByDescending(l => l.PostedDate).Take(5).ToList(),
                RecentLogs = logs,
                Programs = programs.OrderByDescending(p => p.Id).Take(5).ToList(),
                RecentAudits = audits.OrderByDescending(a => a.Date).Take(5).ToList(),
                RecentCompliance = compRecs.OrderByDescending(c => c.Date).Take(5).ToList()
            };
        }
    }
}
