using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Services.ComplianceOfficer
{
    public class ComplianceOfficerService : IComplianceOfficerService
    {
        private readonly IBusinessRepository _biz;
        private readonly IComplaintRepository _complaints;
        private readonly IComplianceRecordRepository _records;
        private readonly IViolationRepository _violations;
        private readonly INotificationRepository _notifs;

        public ComplianceOfficerService(
            IBusinessRepository biz, IComplaintRepository c, IComplianceRecordRepository r,
            IViolationRepository v, INotificationRepository n)
        {
            _biz = biz; _complaints = c; _records = r; _violations = v; _notifs = n;
        }

        public async Task<IEnumerable<TradeNetProject.Models.Business>> GetAllBusinessesAsync() => await _biz.GetAllAsync();
        public async Task<IEnumerable<TradeNetProject.Models.Business>> GetBusinessesByStatusAsync(string status) =>
            await _biz.GetByStatusAsync(status);
        public async Task<TradeNetProject.Models.Business?> GetBusinessDetailsAsync(int businessId) =>
            await _biz.GetWithDetailsAsync(businessId);

        public async Task<(bool, string)> FlagBusinessNonCompliantAsync(int businessId, int officerId, string reason)
        {
            var b = await _biz.GetByIdAsync(businessId);
            if (b == null) return (false, "Not found.");
            b.ComplianceStatus = "Non-Compliant";
            b.Status = "Flagged";
            _biz.Update(b);

            await _records.AddAsync(new ComplianceRecord
            {
                EntityId = businessId, Type = "Business", Result = "Non-Compliant",
                Notes = reason, OfficerId = officerId
            });
            await _records.SaveAsync();
            return (true, "Business flagged as non-compliant.");
        }

        public async Task<(bool, string)> ClearNonComplianceFlagAsync(int businessId, int officerId, string notes)
        {
            var b = await _biz.GetByIdAsync(businessId);
            if (b == null) return (false, "Not found.");
            b.ComplianceStatus = "Compliant";
            b.Status = "Active";
            _biz.Update(b);

            await _records.AddAsync(new ComplianceRecord
            {
                EntityId = businessId, Type = "Business", Result = "Compliant",
                Notes = notes, OfficerId = officerId
            });
            await _records.SaveAsync();
            return (true, "Flag cleared.");
        }

        public async Task<IEnumerable<Complaint>> GetAllComplaintsAsync() => await _complaints.GetAllAsync();

        public async Task<(bool, string)> ResolveComplaintAsync(int complaintId, int officerId, string resolution)
        {
            var c = await _complaints.GetByIdAsync(complaintId);
            if (c == null) return (false, "Not found.");
            c.Status = "Resolved";
            c.Resolution = resolution;
            _complaints.Update(c); await _complaints.SaveAsync();
            await _notifs.AddAsync(new Notification { UserId = c.UserId, Message = $"Complaint resolved: {resolution}", Category = "Complaint", EntityId = c.Id });
            await _notifs.SaveAsync();
            return (true, "Complaint resolved.");
        }

        public async Task<IEnumerable<ComplianceRecord>> GetAllComplianceRecordsAsync() => await _records.GetAllAsync();

        public async Task<(bool, string)> CreateComplianceRecordAsync(ComplianceRecord record)
        {
            await _records.AddAsync(record); await _records.SaveAsync();
            return (true, "Compliance record created.");
        }

        public async Task<(bool, string)> UpdateComplianceResultAsync(int recordId, string result, string notes)
        {
            var r = await _records.GetByIdAsync(recordId);
            if (r == null) return (false, "Not found.");
            r.Result = result; r.Notes = notes;
            _records.Update(r); await _records.SaveAsync();
            return (true, "Updated.");
        }

        public async Task<IEnumerable<Violation>> GetAllViolationsAsync() => await _violations.GetAllAsync();

        public async Task<(bool, string)> RecordViolationAsync(Violation violation)
        {
            await _violations.AddAsync(violation); await _violations.SaveAsync();
            return (true, "Violation recorded.");
        }

        public async Task<ComplianceDashboardViewModel> GetDashboardAsync(int userId)
        {
            var businesses = (await _biz.GetAllAsync()).ToList();
            var complaints = (await _complaints.GetAllAsync()).ToList();
            var violations = (await _violations.GetAllAsync()).ToList();
            var records = (await _records.GetAllAsync()).ToList();

            return new ComplianceDashboardViewModel
            {
                PendingReviews = businesses.Count(b => b.Status == "Pending"),
                TotalComplaints = complaints.Count,
                PendingComplaints = complaints.Count(c => c.Status == "Pending"),
                TotalViolations = violations.Count,
                TotalInspections = records.Count,
                NonCompliantBusinesses = businesses.Count(b => b.ComplianceStatus == "Non-Compliant"),
                Businesses = businesses.Take(10).ToList(),
                RecentComplaints = complaints.OrderByDescending(c => c.SubmittedDate).Take(10).ToList(),
                RecentViolations = violations.OrderByDescending(v => v.ViolationDate).Take(10).ToList(),
                RecentRecords = records.OrderByDescending(r => r.Date).Take(10).ToList()
            };
        }
    }
}
