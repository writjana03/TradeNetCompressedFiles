using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Services.BusinessTrader
{
    public class BusinessTraderService : IBusinessTraderService
    {
        private readonly IBusinessTraderRepository _trader;
        private readonly ITraderDocumentRepository _docs;
        private readonly ILicenseApplicationRepository _apps;
        private readonly ITradeLicenseRepository _licenses;
        private readonly ISubsidyRepository _subsidies;
        private readonly IBusinessRepository _biz;
        private readonly ITransactionRepository _tx;
        private readonly INotificationRepository _notifs;
        private readonly ITradeProgramRepository _programs;
        private readonly IComplaintRepository _complaints;
        private readonly IUserRepository _users;

        public BusinessTraderService(
            IBusinessTraderRepository trader, ITraderDocumentRepository docs,
            ILicenseApplicationRepository apps, ITradeLicenseRepository licenses,
            ISubsidyRepository subsidies, IBusinessRepository biz,
            ITransactionRepository tx, INotificationRepository notifs,
            ITradeProgramRepository programs, IComplaintRepository complaints,
            IUserRepository users)
        {
            _trader = trader; _docs = docs; _apps = apps; _licenses = licenses;
            _subsidies = subsidies; _biz = biz; _tx = tx; _notifs = notifs;
            _programs = programs; _complaints = complaints; _users = users;
        }

        public async Task<TradeNetProject.Models.BusinessTrader?> GetByIdAsync(int id) => await _trader.GetByIdAsync(id);
        public async Task<TradeNetProject.Models.BusinessTrader?> GetByUserIdAsync(int userId) => await _trader.GetByUserIdAsync(userId);

        public async Task<(bool, string)> CreateProfileAsync(int userId, string name, string email)
        {
            if (await _trader.AnyAsync(t => t.UserId == userId))
                return (false, "Profile already exists.");
            await _trader.AddAsync(new TradeNetProject.Models.BusinessTrader
            {
                UserId = userId, FullName = name, Email = email, VerificationStatus = "Pending"
            });
            await _trader.SaveAsync();
            return (true, "Profile created.");
        }

        public async Task<(bool, string)> UpdateProfileAsync(TradeNetProject.Models.BusinessTrader trader)
        {
            _trader.Update(trader);
            await _trader.SaveAsync();
            return (true, "Profile updated.");
        }

        public async Task<IEnumerable<TraderDocument>> GetDocumentsAsync(int businessTraderId) =>
            await _docs.GetByBusinessTraderAsync(businessTraderId);

        public async Task<(bool, string)> UploadDocumentAsync(int businessTraderId, string docType, string fileName, string filePath)
        {
            await _docs.AddAsync(new TraderDocument
            {
                BusinessTraderId = businessTraderId, DocumentType = docType,
                FileName = fileName, FilePath = filePath, VerificationStatus = "Pending"
            });
            await _docs.SaveAsync();
            return (true, "Document uploaded.");
        }

        public async Task<IEnumerable<LicenseApplication>> GetApplicationsAsync(int businessTraderId) =>
            await _apps.GetByBusinessTraderAsync(businessTraderId);

        public async Task<(bool, string)> ApplyForLicenseAsync(int businessTraderId, int tradeLicenseId, string? notes)
        {
            var license = await _licenses.GetByIdAsync(tradeLicenseId);
            if (license == null) return (false, "License not found.");
            if (await _apps.AnyAsync(a => a.BusinessTraderId == businessTraderId && a.TradeLicenseId == tradeLicenseId && a.Status == "Pending"))
                return (false, "Application already exists.");
            await _apps.AddAsync(new LicenseApplication
            {
                BusinessTraderId = businessTraderId, TradeLicenseId = tradeLicenseId,
                ApplicationNotes = notes, Status = "Pending"
            });
            await _apps.SaveAsync();
            return (true, "Application submitted.");
        }

        public async Task<(bool, string)> WithdrawApplicationAsync(int applicationId)
        {
            var app = await _apps.GetByIdAsync(applicationId);
            if (app == null) return (false, "Application not found.");
            _apps.Remove(app);
            await _apps.SaveAsync();
            return (true, "Application withdrawn.");
        }

        public async Task<IEnumerable<Subsidy>> GetSubsidiesAsync(int businessTraderId) =>
            await _subsidies.GetByBusinessTraderAsync(businessTraderId);

        public async Task<(bool, string)> ApplyForSubsidyAsync(int businessTraderId, int programId)
        {
            var program = await _programs.GetByIdAsync(programId);
            if (program == null) return (false, "Program not found.");
            await _subsidies.AddAsync(new Subsidy
            {
                BusinessTraderId = businessTraderId, TradeProgramId = programId,
                SubsidyType = program.ProgramType ?? "General", Status = "Pending"
            });
            await _subsidies.SaveAsync();
            return (true, "Subsidy applied.");
        }

        public async Task<IEnumerable<Complaint>> GetMyComplaintsAsync(int userId) =>
            await _complaints.FindAsync(c => c.UserId == userId);

        public async Task<(bool, string, Complaint?)> RaiseComplaintAsync(int userId, int? businessId, string description)
        {
            var c = new Complaint { UserId = userId, BusinessId = businessId, ComplaintDescription = description, Status = "Pending" };
            await _complaints.AddAsync(c);
            await _complaints.SaveAsync();
            return (true, "Complaint submitted.", c);
        }

        public async Task<BusinessTraderDashboardViewModel> GetDashboardAsync(int userId)
        {
            var trader = await _trader.GetByUserIdAsync(userId);
            if (trader == null)
            {
                var user = await _users.GetByIdAsync(userId);
                trader = new TradeNetProject.Models.BusinessTrader
                {
                    UserId = userId,
                    FullName = user?.FullName ?? "Trader",
                    Email = user?.Email ?? "",
                    VerificationStatus = "Pending"
                };
                await _trader.AddAsync(trader);
                await _trader.SaveAsync();
            }

            var businesses = (await _biz.GetByBusinessTraderAsync(trader.Id)).ToList();
            var businessIds = businesses.Select(b => b.Id).ToList();
            var apps = (await _apps.GetByBusinessTraderAsync(trader.Id)).ToList();
            var docs = (await _docs.GetByBusinessTraderAsync(trader.Id)).ToList();
            var subs = (await _subsidies.GetByBusinessTraderAsync(trader.Id)).ToList();
            var allTx = (await _tx.GetAllAsync()).Where(t => businessIds.Contains(t.BusinessId)).ToList();
            var allLicenses = (await _licenses.GetAllAsync()).Where(l => l.Status == "Available").ToList();
            var notifs = (await _notifs.GetByUserAsync(userId)).Take(5).ToList();

            return new BusinessTraderDashboardViewModel
            {
                BusinessTrader = trader,
                TotalBusinesses = businesses.Count,
                ActiveApplications = apps.Count(a => a.Status == "Pending"),
                ApprovedApplications = apps.Count(a => a.Status == "Approved"),
                TotalTransactions = allTx.Count,
                TotalTradeVolume = allTx.Sum(t => t.Amount),
                DocumentCount = docs.Count,
                VerifiedDocs = docs.Count(d => d.VerificationStatus == "Verified"),
                PendingDocs = docs.Count(d => d.VerificationStatus == "Pending"),
                TotalSubsidies = subs.Count,
                TotalSubsidyAmount = subs.Sum(s => s.Amount),
                RecentApplications = apps.OrderByDescending(a => a.SubmittedDate).Take(5).ToList(),
                RecentTransactions = allTx.OrderByDescending(t => t.TransactionDate).Take(5).ToList(),
                Notifications = notifs,
                AvailableLicenses = allLicenses.Take(5).ToList()
            };
        }
    }

    public class LicenseApplicationService : ILicenseApplicationService
    {
        private readonly ILicenseApplicationRepository _apps;
        public LicenseApplicationService(ILicenseApplicationRepository apps) { _apps = apps; }

        public async Task<IEnumerable<LicenseApplication>> GetAllAsync() => await _apps.GetAllWithDetailsAsync();
        public async Task<LicenseApplication?> GetByIdAsync(int id) => await _apps.GetWithDetailsAsync(id);
        public async Task<IEnumerable<LicenseApplication>> GetByBusinessTraderAsync(int btId) => await _apps.GetByBusinessTraderAsync(btId);
        public async Task<IEnumerable<LicenseApplication>> GetByStatusAsync(string status) => await _apps.GetByStatusAsync(status);

        public async Task<(bool, string)> UpdateStatusAsync(int id, string status, string? notes)
        {
            var app = await _apps.GetByIdAsync(id);
            if (app == null) return (false, "Not found.");
            app.Status = status; app.ReviewedDate = DateTime.Now; app.ReviewNotes = notes;
            _apps.Update(app);
            await _apps.SaveAsync();
            return (true, "Updated.");
        }

        public async Task<(bool, string)> WithdrawAsync(int id)
        {
            var app = await _apps.GetByIdAsync(id);
            if (app == null) return (false, "Not found.");
            _apps.Remove(app);
            await _apps.SaveAsync();
            return (true, "Withdrawn.");
        }
    }

    public class SubsidyService : ISubsidyService
    {
        private readonly ISubsidyRepository _s;
        private readonly ITradeProgramRepository _p;
        public SubsidyService(ISubsidyRepository s, ITradeProgramRepository p) { _s = s; _p = p; }

        public async Task<IEnumerable<Subsidy>> GetAllAsync() => await _s.GetAllAsync();
        public async Task<Subsidy?> GetByIdAsync(int id) => await _s.GetByIdAsync(id);
        public async Task<IEnumerable<Subsidy>> GetByBusinessTraderAsync(int btId) => await _s.GetByBusinessTraderAsync(btId);
        public async Task<IEnumerable<Subsidy>> GetByProgramAsync(int pid) => await _s.GetByProgramAsync(pid);
        public async Task<IEnumerable<Subsidy>> GetPendingAsync() => await _s.FindAsync(x => x.Status == "Pending");

        public async Task<(bool, string)> ApplyAsync(int btId, int programId)
        {
            var p = await _p.GetByIdAsync(programId);
            if (p == null) return (false, "Program not found.");
            await _s.AddAsync(new Subsidy { BusinessTraderId = btId, TradeProgramId = programId, SubsidyType = p.ProgramType ?? "General", Status = "Pending" });
            await _s.SaveAsync();
            return (true, "Subsidy requested.");
        }

        public async Task<(bool, string)> ApproveAsync(int id, decimal amount, INotificationService ns)
        {
            var sub = await _s.GetByIdAsync(id);
            if (sub == null) return (false, "Not found.");
            sub.Status = "Approved"; sub.Amount = amount; sub.SubsidyDate = DateTime.Now;
            _s.Update(sub);
            await _s.SaveAsync();
            var trader = sub.BusinessTrader;
            if (trader != null)
                await ns.CreateAsync(trader.UserId, $"Subsidy approved: ${amount}", "Subsidy", sub.Id, "Subsidy");
            return (true, "Approved.");
        }

        public async Task<(bool, string)> RejectAsync(int id, string reason, INotificationService ns)
        {
            var sub = await _s.GetByIdAsync(id);
            if (sub == null) return (false, "Not found.");
            sub.Status = "Rejected"; sub.Description = reason;
            _s.Update(sub);
            await _s.SaveAsync();
            var trader = sub.BusinessTrader;
            if (trader != null)
                await ns.CreateAsync(trader.UserId, $"Subsidy rejected: {reason}", "Subsidy", sub.Id, "Subsidy");
            return (true, "Rejected.");
        }
    }
}
