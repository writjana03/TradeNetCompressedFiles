using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Services.GovernmentAuditor
{
    public class GovernmentAuditorService : IGovernmentAuditorService
    {
        private readonly IAuditRepository _audits;
        private readonly IComplianceRecordRepository _records;
        private readonly ITradeProgramRepository _programs;
        private readonly IReportRepository _reports;
        private readonly IBusinessRepository _biz;
        private readonly INotificationRepository _notifs;

        public GovernmentAuditorService(
            IAuditRepository audits, IComplianceRecordRepository records,
            ITradeProgramRepository programs, IReportRepository reports,
            IBusinessRepository biz, INotificationRepository notifs)
        {
            _audits = audits; _records = records; _programs = programs;
            _reports = reports; _biz = biz; _notifs = notifs;
        }

        public async Task<IEnumerable<Audit>> GetAllAuditsAsync() => await _audits.GetAllAsync();
        public async Task<Audit?> GetAuditByIdAsync(int auditId) => await _audits.GetByIdAsync(auditId);

        public async Task<(bool, string, Audit?)> CreateAuditAsync(int officerId, string title, string scope, string findings)
        {
            var a = new Audit { OfficerId = officerId, AuditTitle = title, Scope = scope, Findings = findings, Status = "Open" };
            await _audits.AddAsync(a); await _audits.SaveAsync();
            return (true, "Audit created.", a);
        }

        public async Task<(bool, string)> UpdateAuditStatusAsync(int auditId, string newStatus)
        {
            var a = await _audits.GetByIdAsync(auditId);
            if (a == null) return (false, "Not found.");
            a.Status = newStatus;
            if (newStatus == "Completed") a.CompletedDate = DateTime.Now;
            _audits.Update(a); await _audits.SaveAsync();
            return (true, "Status updated.");
        }

        public async Task<(bool, string)> RecordAuditFindingsAsync(int auditId, string findings)
        {
            var a = await _audits.GetByIdAsync(auditId);
            if (a == null) return (false, "Not found.");
            a.Findings = findings;
            _audits.Update(a); await _audits.SaveAsync();
            return (true, "Findings recorded.");
        }

        public async Task<IEnumerable<ComplianceRecord>> GetComplianceRecordsAsync() => await _records.GetAllAsync();

        public async Task<(bool, string)> EscalateComplianceIssueAsync(int entityId, string entityType, int auditorId, string notes)
        {
            await _records.AddAsync(new ComplianceRecord
            {
                EntityId = entityId, Type = entityType, Result = "Escalated",
                Notes = notes, OfficerId = auditorId, RecommendedAction = "Compliance officer follow-up required"
            });
            await _records.SaveAsync();
            return (true, "Issue escalated.");
        }

        public async Task<IEnumerable<TradeProgram>> GetAllProgramsAsync() => await _programs.GetAllAsync();

        public async Task<(bool, string)> FlagProgramForReviewAsync(int programId, int auditorId, string reason)
        {
            var p = await _programs.GetByIdAsync(programId);
            if (p == null) return (false, "Not found.");
            p.Status = "Under Review";
            _programs.Update(p); await _programs.SaveAsync();
            await _records.AddAsync(new ComplianceRecord
            {
                EntityId = programId, Type = "Program", Result = "Under Review",
                Notes = reason, OfficerId = auditorId
            });
            await _records.SaveAsync();
            return (true, "Program flagged for review.");
        }

        public async Task<IEnumerable<Report>> GetAuditReportsAsync() => await _reports.GetAllAsync();

        public async Task<(bool, string, Report?)> GenerateAuditReportAsync(int auditorId, string reportName, string reportType, string content)
        {
            var r = new Report
            {
                ReportName = reportName, ReportType = reportType,
                GeneratedBy = auditorId, ReportContent = content, GeneratedDate = DateTime.Now
            };
            await _reports.AddAsync(r); await _reports.SaveAsync();
            return (true, "Report generated.", r);
        }

        public async Task<IEnumerable<TradeNetProject.Models.Business>> GetAllBusinessesAsync() => await _biz.GetAllAsync();

        public async Task<AuditorDashboardViewModel> GetDashboardAsync(int userId)
        {
            var audits = (await _audits.GetAllAsync()).ToList();
            var records = (await _records.GetAllAsync()).ToList();
            var programs = (await _programs.GetAllAsync()).ToList();
            var reports = (await _reports.GetAllAsync()).ToList();
            var notifs = (await _notifs.GetByUserAsync(userId)).Take(5).ToList();

            return new AuditorDashboardViewModel
            {
                TotalAudits = audits.Count,
                OpenAudits = audits.Count(a => a.Status == "Open"),
                CompletedAudits = audits.Count(a => a.Status == "Completed"),
                TotalCompliance = records.Count,
                NonCompliant = records.Count(r => r.Result == "Non-Compliant"),
                TotalPrograms = programs.Count,
                TotalReports = reports.Count,
                RecentAudits = audits.OrderByDescending(a => a.Date).Take(10).ToList(),
                RecentCompliance = records.OrderByDescending(r => r.Date).Take(10).ToList(),
                Programs = programs.Take(10).ToList(),
                RecentReports = reports.OrderByDescending(r => r.GeneratedDate).Take(10).ToList(),
                Notifications = notifs
            };
        }
    }
}
