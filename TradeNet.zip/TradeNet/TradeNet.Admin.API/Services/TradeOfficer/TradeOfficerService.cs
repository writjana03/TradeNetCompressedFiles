using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Services.TradeOfficer
{
    public class TradeOfficerService : ITradeOfficerService
    {
        private readonly ITraderDocumentRepository _traderDocs;
        private readonly IBusinessDocumentRepository _bizDocs;
        private readonly ILicenseApplicationRepository _apps;
        private readonly ITradeLicenseRepository _licenses;
        private readonly ITransactionRepository _tx;
        private readonly IBusinessRepository _biz;
        private readonly INotificationRepository _notifs;

        public TradeOfficerService(
            ITraderDocumentRepository traderDocs, IBusinessDocumentRepository bizDocs,
            ILicenseApplicationRepository apps, ITradeLicenseRepository licenses,
            ITransactionRepository tx, IBusinessRepository biz, INotificationRepository notifs)
        {
            _traderDocs = traderDocs; _bizDocs = bizDocs; _apps = apps; _licenses = licenses;
            _tx = tx; _biz = biz; _notifs = notifs;
        }

        public async Task<IEnumerable<TraderDocument>> GetPendingTraderDocumentsAsync() =>
            await _traderDocs.GetPendingAsync();

        public async Task<IEnumerable<BusinessDocument>> GetPendingBusinessDocumentsAsync() =>
            await _bizDocs.GetPendingAsync();

        public async Task<(bool, string)> VerifyTraderDocumentAsync(int documentId, int officerId)
        {
            var d = await _traderDocs.GetByIdAsync(documentId);
            if (d == null) return (false, "Not found.");
            d.VerificationStatus = "Verified"; d.VerifiedByUserId = officerId; d.VerificationDate = DateTime.Now;
            _traderDocs.Update(d); await _traderDocs.SaveAsync();
            return (true, "Document verified.");
        }

        public async Task<(bool, string)> RejectTraderDocumentAsync(int documentId, int officerId, string reason)
        {
            var d = await _traderDocs.GetByIdAsync(documentId);
            if (d == null) return (false, "Not found.");
            d.VerificationStatus = "Rejected"; d.RejectionReason = reason; d.VerifiedByUserId = officerId;
            _traderDocs.Update(d); await _traderDocs.SaveAsync();
            return (true, "Document rejected.");
        }

        public async Task<(bool, string)> VerifyBusinessDocumentAsync(int documentId, int officerId)
        {
            var d = await _bizDocs.GetByIdAsync(documentId);
            if (d == null) return (false, "Not found.");
            d.VerificationStatus = "Verified";
            _bizDocs.Update(d); await _bizDocs.SaveAsync();
            // If all docs verified, mark business verified
            var allDocs = await _bizDocs.GetByBusinessAsync(d.BusinessId);
            if (allDocs.All(x => x.VerificationStatus == "Verified"))
            {
                var biz = await _biz.GetByIdAsync(d.BusinessId);
                if (biz != null)
                {
                    biz.Status = "Verified";
                    _biz.Update(biz);
                    await _biz.SaveAsync();
                }
            }
            return (true, "Business document verified.");
        }

        public async Task<(bool, string)> RejectBusinessDocumentAsync(int documentId, int officerId, string reason)
        {
            var d = await _bizDocs.GetByIdAsync(documentId);
            if (d == null) return (false, "Not found.");
            d.VerificationStatus = "Rejected"; d.RejectionReason = reason;
            _bizDocs.Update(d); await _bizDocs.SaveAsync();
            return (true, "Document rejected.");
        }

        public async Task<IEnumerable<LicenseApplication>> GetPendingApplicationsAsync() =>
            await _apps.GetByStatusAsync("Pending");

        public async Task<(bool, string)> ApproveApplicationAsync(int applicationId, int officerId, DateTime? expiryDate, string? notes)
        {
            var app = await _apps.GetWithDetailsAsync(applicationId);
            if (app == null) return (false, "Not found.");
            app.Status = "Approved"; app.ReviewedDate = DateTime.Now; app.ReviewNotes = notes;
            _apps.Update(app);

            if (app.TradeLicense != null)
            {
                app.TradeLicense.Status = "Approved";
                app.TradeLicense.IssuedDate = DateTime.Now;
                app.TradeLicense.ExpiryDate = expiryDate ?? DateTime.Now.AddYears(1);
                _licenses.Update(app.TradeLicense);
            }

            await _apps.SaveAsync();
            if (app.BusinessTrader != null)
                await _notifs.AddAsync(new Notification { UserId = app.BusinessTrader.UserId, Message = "Your license application has been approved.", Category = "License", EntityId = app.Id });
            await _notifs.SaveAsync();
            return (true, "Application approved.");
        }

        public async Task<(bool, string)> RejectApplicationAsync(int applicationId, int officerId, string reason)
        {
            var app = await _apps.GetWithDetailsAsync(applicationId);
            if (app == null) return (false, "Not found.");
            app.Status = "Rejected"; app.ReviewedDate = DateTime.Now; app.RejectionReason = reason; app.ReviewNotes = reason;
            _apps.Update(app);
            await _apps.SaveAsync();
            if (app.BusinessTrader != null)
                await _notifs.AddAsync(new Notification { UserId = app.BusinessTrader.UserId, Message = $"Your license application was rejected: {reason}", Category = "License", EntityId = app.Id });
            await _notifs.SaveAsync();
            return (true, "Application rejected.");
        }

        public async Task<IEnumerable<Transaction>> GetTransactionsAsync() => await _tx.GetAllAsync();
        public async Task<IEnumerable<Transaction>> GetSuspiciousTransactionsAsync() => await _tx.GetSuspiciousAsync();

        public async Task<(bool, string)> FlagTransactionAsync(int transactionId, int officerId, string notes)
        {
            var t = await _tx.GetByIdAsync(transactionId);
            if (t == null) return (false, "Not found.");
            t.Status = "Flagged"; t.OfficerNotes = notes; t.MonitoredByUserId = officerId;
            _tx.Update(t); await _tx.SaveAsync();
            return (true, "Transaction flagged.");
        }

        public async Task<(bool, string)> ClearTransactionFlagAsync(int transactionId, int officerId)
        {
            var t = await _tx.GetByIdAsync(transactionId);
            if (t == null) return (false, "Not found.");
            t.Status = "Completed"; t.MonitoredByUserId = officerId;
            _tx.Update(t); await _tx.SaveAsync();
            return (true, "Flag cleared.");
        }

        public async Task<IEnumerable<TradeNetProject.Models.Business>> GetAllBusinessesAsync() => await _biz.GetAllAsync();

        public async Task<(bool, string)> VerifyBusinessAsync(int businessId, int officerId)
        {
            var b = await _biz.GetByIdAsync(businessId);
            if (b == null) return (false, "Not found.");
            b.Status = "Verified";
            _biz.Update(b); await _biz.SaveAsync();
            return (true, "Business verified.");
        }

        public async Task<(bool, string)> RejectBusinessAsync(int businessId, int officerId, string reason)
        {
            var b = await _biz.GetByIdAsync(businessId);
            if (b == null) return (false, "Not found.");
            b.Status = "Rejected";
            b.Description = $"[REJECTED] {reason}";
            _biz.Update(b); await _biz.SaveAsync();
            return (true, "Business rejected.");
        }

        public async Task<TradeOfficerDashboardViewModel> GetDashboardAsync(int userId)
        {
            var pendingTraderDocs = (await _traderDocs.GetPendingAsync()).ToList();
            var pendingBizDocs = (await _bizDocs.GetPendingAsync()).ToList();
            var pendingApps = (await _apps.GetByStatusAsync("Pending")).ToList();
            var approvedApps = (await _apps.GetByStatusAsync("Approved")).ToList();
            var rejectedApps = (await _apps.GetByStatusAsync("Rejected")).ToList();
            var suspicious = (await _tx.GetSuspiciousAsync()).ToList();
            var businesses = (await _biz.GetByStatusAsync("Pending")).ToList();
            var notifs = (await _notifs.GetByUserAsync(userId)).Take(5).ToList();

            return new TradeOfficerDashboardViewModel
            {
                PendingDocuments = pendingTraderDocs.Count + pendingBizDocs.Count,
                PendingLicenseApplications = pendingApps.Count,
                ApprovedApplications = approvedApps.Count,
                RejectedApplications = rejectedApps.Count,
                FlaggedTransactions = suspicious.Count,
                PendingBusinessVerifications = businesses.Count,
                PendingBizDocs = pendingBizDocs.Take(10).ToList(),
                PendingTraderDocs = pendingTraderDocs.Take(10).ToList(),
                RecentApplications = pendingApps.Take(10).ToList(),
                SuspiciousTransactions = suspicious.Take(10).ToList(),
                FlaggedBusinesses = businesses.Take(10).ToList(),
                Notifications = notifs
            };
        }
    }
}
