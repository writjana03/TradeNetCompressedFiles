using TradeNetProject.Interfaces.Repositories;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Services.ProgramManager
{
    public class ProgramManagerService : IProgramManagerService
    {
        private readonly ITradeProgramRepository _programs;
        private readonly IResourceRepository _resources;
        private readonly ISubsidyRepository _subs;
        private readonly INotificationRepository _notifs;

        public ProgramManagerService(ITradeProgramRepository p, IResourceRepository r, ISubsidyRepository s, INotificationRepository n)
        {
            _programs = p; _resources = r; _subs = s; _notifs = n;
        }

        public async Task<IEnumerable<TradeProgram>> GetAllProgramsAsync() => await _programs.GetAllAsync();
        public async Task<TradeProgram?> GetProgramByIdAsync(int id) => await _programs.GetByIdAsync(id);

        public async Task<(bool, string, TradeProgram?)> CreateProgramAsync(TradeProgram program)
        {
            await _programs.AddAsync(program); await _programs.SaveAsync();
            return (true, "Program created.", program);
        }

        public async Task<(bool, string)> UpdateProgramAsync(TradeProgram program)
        {
            _programs.Update(program); await _programs.SaveAsync();
            return (true, "Updated.");
        }

        public async Task<(bool, string)> DeleteProgramAsync(int id)
        {
            var p = await _programs.GetByIdAsync(id);
            if (p == null) return (false, "Not found.");
            _programs.Remove(p); await _programs.SaveAsync();
            return (true, "Deleted.");
        }

        public async Task<IEnumerable<Resource>> GetResourcesAsync(int? programId = null) =>
            programId == null
                ? await _resources.GetAllAsync()
                : await _resources.FindAsync(r => r.TradeProgramId == programId);

        public async Task<(bool, string)> AddResourceAsync(Resource r)
        {
            await _resources.AddAsync(r); await _resources.SaveAsync();
            return (true, "Resource added.");
        }

        public async Task<(bool, string)> UpdateResourceAsync(Resource r)
        {
            _resources.Update(r); await _resources.SaveAsync();
            return (true, "Updated.");
        }

        public async Task<(bool, string)> DeleteResourceAsync(int id)
        {
            var r = await _resources.GetByIdAsync(id);
            if (r == null) return (false, "Not found.");
            _resources.Remove(r); await _resources.SaveAsync();
            return (true, "Deleted.");
        }

        public async Task<IEnumerable<Subsidy>> GetPendingSubsidiesAsync() =>
            await _subs.FindAsync(s => s.Status == "Pending");

        public async Task<(bool, string)> ApproveSubsidyAsync(int subsidyId, int managerUserId, decimal amount, INotificationService ns)
        {
            var s = await _subs.GetByIdAsync(subsidyId);
            if (s == null) return (false, "Not found.");
            s.Status = "Approved"; s.Amount = amount; s.SubsidyDate = DateTime.Now;
            _subs.Update(s); await _subs.SaveAsync();

            var program = await _programs.GetByIdAsync(s.TradeProgramId);
            if (program != null) { program.BudgetUtilized += amount; _programs.Update(program); await _programs.SaveAsync(); }
            if (s.BusinessTrader != null)
                await ns.CreateAsync(s.BusinessTrader.UserId, $"Subsidy approved: ${amount}", "Subsidy", s.Id, "Subsidy");
            return (true, "Subsidy approved.");
        }

        public async Task<(bool, string)> RejectSubsidyAsync(int subsidyId, int managerUserId, string reason, INotificationService ns)
        {
            var s = await _subs.GetByIdAsync(subsidyId);
            if (s == null) return (false, "Not found.");
            s.Status = "Rejected"; s.Description = reason;
            _subs.Update(s); await _subs.SaveAsync();
            if (s.BusinessTrader != null)
                await ns.CreateAsync(s.BusinessTrader.UserId, $"Subsidy rejected: {reason}", "Subsidy", s.Id, "Subsidy");
            return (true, "Subsidy rejected.");
        }

        public async Task<ProgramManagerDashboardViewModel> GetDashboardAsync(int userId)
        {
            var programs = (await _programs.GetAllAsync()).ToList();
            var subs = (await _subs.GetAllAsync()).ToList();
            var resources = (await _resources.GetAllAsync()).ToList();
            var notifs = (await _notifs.GetByUserAsync(userId)).Take(5).ToList();

            return new ProgramManagerDashboardViewModel
            {
                TotalPrograms = programs.Count,
                ActivePrograms = programs.Count(p => p.Status == "Active"),
                TotalBudget = programs.Sum(p => p.TotalBudget),
                BudgetUtilized = programs.Sum(p => p.BudgetUtilized),
                TotalSubsidies = subs.Count,
                TotalBeneficiaries = subs.Select(s => s.BusinessTraderId).Distinct().Count(),
                TotalResources = resources.Count,
                Programs = programs,
                RecentSubsidies = subs.OrderByDescending(s => s.SubsidyDate).Take(5).ToList(),
                Notifications = notifs
            };
        }
    }
}
