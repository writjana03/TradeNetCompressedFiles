namespace TradeNetProject.Exceptions;

public sealed class UnauthorizedException : Exception
{
    public UnauthorizedException(string message = "You are not authorized to perform this action.")
        : base(message) { }
}
