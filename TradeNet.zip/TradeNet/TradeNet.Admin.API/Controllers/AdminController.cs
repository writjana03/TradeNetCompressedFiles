using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Security.Claims;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;
using TradeNetProject.Models.ViewModels;

namespace TradeNetProject.Controllers
{
    [Route("api/admin")]
    [ApiController]
    [Authorize]
    [Produces("application/json")]
    public class AdminController : ControllerBase
    {
        private readonly IAdminService _admin;
        private readonly IAccountService _account;
        private readonly IReportService _reports;
        private readonly ISystemLogService _logs;
        private readonly INotificationService _notifications;

        public AdminController(IAdminService admin, IAccountService account,
            IReportService reports, ISystemLogService logs, INotificationService notifications)
        {
            _admin = admin; _account = account;
            _reports = reports; _logs = logs; _notifications = notifications;
        }

        private int GetUserId()
        {
            var c = User.FindFirst(ClaimTypes.NameIdentifier);
            if (c != null && int.TryParse(c.Value, out int j)) return j;
            if (Request.Headers.TryGetValue("X-User-Id", out var h) && int.TryParse(h, out int p)) return p;
            throw new UnauthorizedAccessException("Provide a valid JWT or X-User-Id header.");
        }

        // ── DASHBOARD ───────────────────────────────────────────────────
        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard() => Ok(await _admin.GetFullDashboardAsync());

        // ── USER MANAGEMENT ─────────────────────────────────────────────
        [HttpGet("users")]
        public async Task<IActionResult> GetAllUsers() => Ok(await _account.GetAllUsersAsync());

        [HttpGet("users/{id}")]
        public async Task<IActionResult> GetUser(int id)
        {
            var u = await _account.GetByIdAsync(id);
            return u == null ? NotFound(new { Message = "User not found." }) : Ok(u);
        }

        [HttpPost("users")]
        public async Task<IActionResult> CreateUser([FromBody] CreateUserViewModel model)
        {
            var (success, msg) = await _account.CreateUserAsync(model);
            if (success) { await _logs.LogAsync(GetUserId(), "CreateUser", model.Email); return Ok(new { Message = msg }); }
            return BadRequest(new { Message = msg });
        }

        [HttpPut("users/{id}")]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] User model)
        {
            var existing = await _account.GetByIdAsync(id);
            if (existing == null) return NotFound(new { Message = "User not found." });
            existing.FullName = model.FullName; existing.Email = model.Email;
            existing.Role = model.Role; existing.Status = model.Status; existing.Phone = model.Phone;
            if (!string.IsNullOrEmpty(model.Password)) existing.Password = model.Password;
            var (success, msg) = await _account.UpdateUserAsync(existing);
            if (success) { await _logs.LogAsync(GetUserId(), "UpdateUser", $"UserId: {id}"); return Ok(new { Message = "User updated.", User = existing }); }
            return BadRequest(new { Message = msg });
        }

        [HttpPut("users/{id}/deactivate")]
        public async Task<IActionResult> DeactivateUser(int id)
        {
            var u = await _account.GetByIdAsync(id);
            if (u == null) return NotFound(new { Message = "User not found." });
            u.Status = "Inactive";
            var (success, msg) = await _account.UpdateUserAsync(u);
            if (success) { await _logs.LogAsync(GetUserId(), "DeactivateUser", $"UserId: {id}"); return Ok(new { Message = "User deactivated." }); }
            return BadRequest(new { Message = msg });
        }

        [HttpPut("users/{id}/activate")]
        public async Task<IActionResult> ActivateUser(int id)
        {
            var u = await _account.GetByIdAsync(id);
            if (u == null) return NotFound(new { Message = "User not found." });
            u.Status = "Active";
            var (success, msg) = await _account.UpdateUserAsync(u);
            if (success) { await _logs.LogAsync(GetUserId(), "ActivateUser", $"UserId: {id}"); return Ok(new { Message = $"User '{u.FullName}' activated." }); }
            return BadRequest(new { Message = msg });
        }

        [HttpDelete("users/{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var (success, msg) = await _account.DeleteUserAsync(id);
            if (success) { await _logs.LogAsync(GetUserId(), "DeleteUser", $"UserId: {id}"); return Ok(new { Message = msg }); }
            return BadRequest(new { Message = msg });
        }

        // ── BUSINESS OVERSIGHT ──────────────────────────────────────────
        [HttpGet("businesses")]
        public async Task<IActionResult> GetBusinesses([FromQuery] string? status) =>
            Ok(await _admin.GetAllBusinessesAsync(status));

        [HttpPut("businesses/{id}/suspend")]
        public async Task<IActionResult> SuspendBusiness(int id, [FromBody] string reason)
        {
            var (success, msg) = await _admin.SuspendBusinessAsync(id, reason);
            if (success) await _logs.LogAsync(GetUserId(), "SuspendBusiness", "BusinessId=" + id);
            return success ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("businesses/{id}/reinstate")]
        public async Task<IActionResult> ReinstateBusiness(int id)
        {
            var (success, msg) = await _admin.ReinstateBusinessAsync(id);
            if (success) await _logs.LogAsync(GetUserId(), "ReinstateBusiness", "BusinessId=" + id);
            return success ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── NOTIFICATIONS ───────────────────────────────────────────────
        [HttpGet("notifications")]
        public async Task<IActionResult> GetNotifications()
        {
            var uid = GetUserId();
            var n = await _notifications.GetByUserAsync(uid);
            await _notifications.MarkAllReadAsync(uid);
            return Ok(n);
        }

        [HttpPost("notifications/broadcast")]
        public async Task<IActionResult> BroadcastNotification([FromQuery] string targetRole, [FromBody] string message)
        {
            var (success, msg) = await _admin.BroadcastNotificationAsync(targetRole, message, _notifications);
            if (success) await _logs.LogAsync(GetUserId(), "BroadcastNotification", targetRole);
            return success ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── REPORTS ─────────────────────────────────────────────────────
        [HttpGet("reports")]
        public async Task<IActionResult> GetReports() =>
            Ok((await _reports.GetAllAsync()).OrderByDescending(r => r.GeneratedDate));

        public record GenerateReportRequest(string ReportName, string ReportType, DateTime? StartDate, DateTime? EndDate);

        [HttpPost("reports")]
        public async Task<IActionResult> GenerateReport([FromBody] GenerateReportRequest request)
        {
            var csv = new System.Text.StringBuilder();
            switch (request.ReportType)
            {
                case "UserActivity":
                    var logs = (await _logs.GetRecentAsync(5000));
                    if (request.StartDate.HasValue) logs = logs.Where(l => l.Timestamp >= request.StartDate.Value);
                    if (request.EndDate.HasValue) logs = logs.Where(l => l.Timestamp <= request.EndDate.Value.AddDays(1));
                    csv.AppendLine("LogID,Action,Resource,Timestamp");
                    foreach (var l in logs)
                        csv.AppendLine($"{l.Id},{l.Action},{l.Resource?.Replace(",", " ") ?? "N/A"},{l.Timestamp:yyyy-MM-dd HH:mm:ss}");
                    break;
                case "Compliance":
                    var users = await _account.GetAllUsersAsync();
                    csv.AppendLine("UserID,FullName,Email,Role,Status,Phone");
                    foreach (var u in users)
                        csv.AppendLine($"{u.Id},{u.FullName?.Replace(",", " ")},{u.Email},{u.Role},{u.Status},{u.Phone}");
                    break;
                case "Business":
                    var businesses = await _admin.GetAllBusinessesAsync(null);
                    csv.AppendLine("BusinessID,BusinessName,BusinessType,Status,RegistrationDate");
                    foreach (var b in businesses)
                        csv.AppendLine($"{b.Id},{b.BusinessName?.Replace(",", " ")},{b.BusinessType},{b.Status},{b.RegistrationDate:yyyy-MM-dd}");
                    break;
                default:
                    csv.AppendLine("ReportId,Generated,Type");
                    csv.AppendLine($"{Guid.NewGuid().ToString()[..8]},{DateTime.UtcNow:yyyy-MM-dd},{request.ReportType}");
                    break;
            }
            var report = new Report
            {
                ReportName = request.ReportName, ReportType = request.ReportType,
                GeneratedBy = GetUserId(), GeneratedDate = DateTime.Now,
                StartDate = request.StartDate, EndDate = request.EndDate,
                ReportContent = csv.ToString()
            };
            var (success, msg) = await _reports.GenerateAsync(report);
            if (success) await _logs.LogAsync(GetUserId(), "GenerateReport", request.ReportType);
            return success ? Ok(new { Message = "Report generated.", Report = report }) : BadRequest(new { Message = msg });
        }

        [HttpGet("reports/{id}/download")]
        public async Task<IActionResult> DownloadReport(int id)
        {
            var r = await _reports.GetByIdAsync(id);
            if (r == null) return NotFound("Report not found.");
            var preamble = System.Text.Encoding.UTF8.GetPreamble();
            var content = System.Text.Encoding.UTF8.GetBytes(r.ReportContent ?? "No data");
            var fileBytes = preamble.Concat(content).ToArray();
            var fileName = $"{r.ReportName.Replace(" ", "_")}_{DateTime.Now:yyyyMMdd}.csv";
            return File(fileBytes, "text/csv", fileName);
        }

        // ── SYSTEM MONITORING ───────────────────────────────────────────
        [HttpGet("system-logs")]
        public async Task<IActionResult> GetSystemLogs([FromQuery] int count = 100) =>
            Ok(await _logs.GetRecentAsync(count));
    }
}
