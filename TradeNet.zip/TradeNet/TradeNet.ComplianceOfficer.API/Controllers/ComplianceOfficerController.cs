using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;

namespace TradeNetProject.Controllers
{
    [Route("api/compliance-officer")]
    [ApiController]
    [Authorize]
    [Produces("application/json")]
    public class ComplianceOfficerController : ControllerBase
    {
        private readonly IComplianceOfficerService _compliance;
        private readonly INotificationService _notifications;
        private readonly ISystemLogService _logs;

        public ComplianceOfficerController(IComplianceOfficerService c, INotificationService n, ISystemLogService logs)
        {
            _compliance = c; _notifications = n; _logs = logs;
        }

        private int GetUserId()
        {
            var c = User.FindFirst(ClaimTypes.NameIdentifier);
            if (c != null && int.TryParse(c.Value, out int id)) return id;
            throw new UnauthorizedAccessException("Valid JWT required.");
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard() => Ok(await _compliance.GetDashboardAsync(GetUserId()));

        // ── BUSINESS REVIEW ─────────────────────────────────────────────
        [HttpGet("businesses")]
        public async Task<IActionResult> GetBusinesses([FromQuery] string? status) =>
            string.IsNullOrEmpty(status)
                ? Ok(await _compliance.GetAllBusinessesAsync())
                : Ok(await _compliance.GetBusinessesByStatusAsync(status));

        [HttpGet("businesses/{id}")]
        public async Task<IActionResult> GetBusiness(int id)
        {
            var b = await _compliance.GetBusinessDetailsAsync(id);
            return b == null ? NotFound() : Ok(b);
        }

        [HttpPut("businesses/{id}/flag")]
        public async Task<IActionResult> FlagBusiness(int id, [FromBody] string reason)
        {
            var (ok, msg) = await _compliance.FlagBusinessNonCompliantAsync(id, GetUserId(), reason);
            if (ok) await _logs.LogAsync(GetUserId(), "FlagBusiness", $"BizId={id}");
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("businesses/{id}/clear")]
        public async Task<IActionResult> ClearBusinessFlag(int id, [FromBody] string notes)
        {
            var (ok, msg) = await _compliance.ClearNonComplianceFlagAsync(id, GetUserId(), notes);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── COMPLAINTS ──────────────────────────────────────────────────
        [HttpGet("complaints")]
        public async Task<IActionResult> GetComplaints() => Ok(await _compliance.GetAllComplaintsAsync());

        [HttpPut("complaints/{id}/resolve")]
        public async Task<IActionResult> ResolveComplaint(int id, [FromBody] string resolution)
        {
            var (ok, msg) = await _compliance.ResolveComplaintAsync(id, GetUserId(), resolution);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── COMPLIANCE RECORDS ──────────────────────────────────────────
        [HttpGet("compliance-records")]
        public async Task<IActionResult> GetRecords() => Ok(await _compliance.GetAllComplianceRecordsAsync());

        [HttpPost("compliance-records")]
        public async Task<IActionResult> CreateRecord([FromBody] ComplianceRecord r)
        {
            r.OfficerId = GetUserId();
            var (ok, msg) = await _compliance.CreateComplianceRecordAsync(r);
            return ok ? Ok(new { Message = msg, Record = r }) : BadRequest(new { Message = msg });
        }

        public record UpdateRecordRequest(string Result, string Notes);

        [HttpPut("compliance-records/{id}")]
        public async Task<IActionResult> UpdateRecord(int id, [FromBody] UpdateRecordRequest req)
        {
            var (ok, msg) = await _compliance.UpdateComplianceResultAsync(id, req.Result, req.Notes);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── VIOLATIONS ──────────────────────────────────────────────────
        [HttpGet("violations")]
        public async Task<IActionResult> GetViolations() => Ok(await _compliance.GetAllViolationsAsync());

        [HttpPost("violations")]
        public async Task<IActionResult> CreateViolation([FromBody] Violation v)
        {
            v.OfficerId = GetUserId();
            var (ok, msg) = await _compliance.RecordViolationAsync(v);
            if (ok) await _logs.LogAsync(GetUserId(), "RecordViolation", $"BusinessId={v.BusinessId}");
            return ok ? Ok(new { Message = msg, Violation = v }) : BadRequest(new { Message = msg });
        }

        // ── NOTIFICATIONS ───────────────────────────────────────────────
        [HttpGet("notifications")]
        public async Task<IActionResult> GetNotifications()
        {
            var uid = GetUserId();
            var n = await _notifications.GetByUserAsync(uid);
            await _notifications.MarkAllReadAsync(uid);
            return Ok(n);
        }
    }
}
