using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TradeNetProject.Interfaces.Services;
using TradeNetProject.Models;

namespace TradeNetProject.Controllers
{
    [Route("api/gov-auditor")]
    [ApiController]
    [Authorize]
    [Produces("application/json")]
    public class GovernmentAuditorController : ControllerBase
    {
        private readonly IGovernmentAuditorService _auditor;
        private readonly INotificationService _notifications;
        private readonly ISystemLogService _logs;

        public GovernmentAuditorController(IGovernmentAuditorService a, INotificationService n, ISystemLogService logs)
        {
            _auditor = a; _notifications = n; _logs = logs;
        }

        private int GetUserId()
        {
            var c = User.FindFirst(ClaimTypes.NameIdentifier);
            if (c != null && int.TryParse(c.Value, out int id)) return id;
            throw new UnauthorizedAccessException("Valid JWT required.");
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard() => Ok(await _auditor.GetDashboardAsync(GetUserId()));

        // ── AUDITS ──────────────────────────────────────────────────────
        [HttpGet("audits")]
        public async Task<IActionResult> GetAudits() => Ok(await _auditor.GetAllAuditsAsync());

        [HttpGet("audits/{id}")]
        public async Task<IActionResult> GetAudit(int id)
        {
            var a = await _auditor.GetAuditByIdAsync(id);
            return a == null ? NotFound() : Ok(a);
        }

        public record CreateAuditRequest(string Title, string Scope, string Findings);

        [HttpPost("audits")]
        public async Task<IActionResult> CreateAudit([FromBody] CreateAuditRequest req)
        {
            var (ok, msg, a) = await _auditor.CreateAuditAsync(GetUserId(), req.Title, req.Scope, req.Findings);
            if (ok) await _logs.LogAsync(GetUserId(), "CreateAudit", req.Scope);
            return ok ? Ok(new { Message = msg, Audit = a }) : BadRequest(new { Message = msg });
        }

        [HttpPut("audits/{id}/status")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] string newStatus)
        {
            var (ok, msg) = await _auditor.UpdateAuditStatusAsync(id, newStatus);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        [HttpPut("audits/{id}/findings")]
        public async Task<IActionResult> RecordFindings(int id, [FromBody] string findings)
        {
            var (ok, msg) = await _auditor.RecordAuditFindingsAsync(id, findings);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── COMPLIANCE REVIEW ───────────────────────────────────────────
        [HttpGet("compliance")]
        public async Task<IActionResult> GetCompliance() => Ok(await _auditor.GetComplianceRecordsAsync());

        public record EscalateRequest(int EntityId, string EntityType, string Notes);

        [HttpPost("compliance/escalate")]
        public async Task<IActionResult> Escalate([FromBody] EscalateRequest req)
        {
            var (ok, msg) = await _auditor.EscalateComplianceIssueAsync(req.EntityId, req.EntityType, GetUserId(), req.Notes);
            if (ok) await _logs.LogAsync(GetUserId(), "EscalateCompliance", $"{req.EntityType}/{req.EntityId}");
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── PROGRAMS ────────────────────────────────────────────────────
        [HttpGet("programs")]
        public async Task<IActionResult> GetPrograms() => Ok(await _auditor.GetAllProgramsAsync());

        [HttpPut("programs/{id}/flag")]
        public async Task<IActionResult> FlagProgram(int id, [FromBody] string reason)
        {
            var (ok, msg) = await _auditor.FlagProgramForReviewAsync(id, GetUserId(), reason);
            return ok ? Ok(new { Message = msg }) : BadRequest(new { Message = msg });
        }

        // ── REPORTS ─────────────────────────────────────────────────────
        [HttpGet("reports")]
        public async Task<IActionResult> GetReports() => Ok(await _auditor.GetAuditReportsAsync());

        public record GenReportRequest(string ReportName, string ReportType, string Content);

        [HttpPost("reports")]
        public async Task<IActionResult> GenerateReport([FromBody] GenReportRequest req)
        {
            var (ok, msg, r) = await _auditor.GenerateAuditReportAsync(GetUserId(), req.ReportName, req.ReportType, req.Content);
            if (ok) await _logs.LogAsync(GetUserId(), "GenerateAuditReport", req.ReportType);
            return ok ? Ok(new { Message = msg, Report = r }) : BadRequest(new { Message = msg });
        }

        // ── BUSINESSES ──────────────────────────────────────────────────
        [HttpGet("businesses")]
        public async Task<IActionResult> GetBusinesses() => Ok(await _auditor.GetAllBusinessesAsync());

        // ── NOTIFICATIONS ───────────────────────────────────────────────
        [HttpGet("notifications")]
        public async Task<IActionResult> GetNotifications()
        {
            var uid = GetUserId();
            var n = await _notifications.GetByUserAsync(uid);
            await _notifications.MarkAllReadAsync(uid);
            return Ok(n);
        }
    }
}
