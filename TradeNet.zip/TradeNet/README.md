# TradeNet — Backend Microservices

A .NET 10 microservices solution mirroring the WorkForceGov architecture for the TradeNet trade-licensing platform.

## Architecture

6 self-contained microservices, each with the same internal structure (Models, Data, Repositories, Services, Interfaces, Middleware, Authentication, Controllers) sharing a single SQL Server database called `tradenet`.

| Service                          | Port (HTTPS) | Port (HTTP) | Role base route             |
|----------------------------------|--------------|-------------|-----------------------------|
| TradeNet.Admin.API               | 7001         | 5001        | `/api/admin` (+ `/api/auth`) |
| TradeNet.BusinessTrader.API      | 7002         | 5002        | `/api/business-trader`      |
| TradeNet.TradeOfficer.API        | 7003         | 5003        | `/api/trade-officer`        |
| TradeNet.ProgramManager.API      | 7004         | 5004        | `/api/program-manager`      |
| TradeNet.ComplianceOfficer.API   | 7005         | 5005        | `/api/compliance-officer`   |
| TradeNet.GovernmentAuditor.API   | 7006         | 5006        | `/api/gov-auditor`          |

The Admin API is the single auth gateway — all roles log in via `/api/auth/login` on port 7001. All APIs accept that JWT for their own endpoints.

## Running

```bash
# Set up SQL Server with database `tradenet` (created on startup via EnsureCreated)
# Run each API (in separate terminals or with the solution):
dotnet run --project TradeNet.Admin.API
dotnet run --project TradeNet.BusinessTrader.API
dotnet run --project TradeNet.TradeOfficer.API
dotnet run --project TradeNet.ProgramManager.API
dotnet run --project TradeNet.ComplianceOfficer.API
dotnet run --project TradeNet.GovernmentAuditor.API
```

Each API opens its Swagger UI at its root URL.

## Seeded Test Users (all password `password123`)

| Email                          | Role               |
|--------------------------------|--------------------|
| trader@tradenet.local          | BusinessTrader     |
| officer@tradenet.local         | TradeOfficer       |
| manager@tradenet.local         | ProgramManager     |
| admin@tradenet.local           | SystemAdmin        |
| compliance@tradenet.local      | ComplianceOfficer  |
| auditor@tradenet.local         | GovernmentAuditor  |

## Domain Model

- **User** ↔ **BusinessTrader** (1:1) → owns **Business** entities (1:N) → uploads **BusinessDocument** & **TraderDocument**
- **Business** applies for **TradeLicense** via **LicenseApplication** → reviewed by **TradeOfficer**
- **Business** performs **Transactions** → monitored by **TradeOfficer**
- **TradeProgram** offers **Subsidies** → approved by **ProgramManager**
- **ComplianceOfficer** records **ComplianceRecord**, **Complaint**, **Violation**
- **GovernmentAuditor** creates **Audit**, generates **Report**

See `Models/` in any API for full schema.
