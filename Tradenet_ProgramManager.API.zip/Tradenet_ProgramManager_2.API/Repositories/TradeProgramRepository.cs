using Microsoft.EntityFrameworkCore;
using Tradenet_ProgramManager_2.API.Data;
using Tradenet_ProgramManager_2.API.Models;

namespace Tradenet_ProgramManager_2.API.Repositories
{
    public class TradeProgramRepository : ITradeProgramRepository
    {
        private readonly AppDbContext _context;

        public TradeProgramRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<TradeProgram>> GetAll()
        {
            return await _context.TradePrograms.ToListAsync();
        }

        public async Task<TradeProgram?> GetById(int id)
        {
            return await _context.TradePrograms.FindAsync(id);
        }

        public async Task Add(TradeProgram tradeProgram)
        {
            _context.TradePrograms.Add(tradeProgram);
            await _context.SaveChangesAsync();
        }

        public async Task Update(TradeProgram tradeProgram)
        {
            _context.TradePrograms.Update(tradeProgram);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(int id)
        {
            var tradeProgram = await _context.TradePrograms.FindAsync(id);
            if (tradeProgram != null)
            {
                _context.TradePrograms.Remove(tradeProgram);
                await _context.SaveChangesAsync();
            }
        }
    }
}
