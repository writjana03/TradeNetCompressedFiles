using Microsoft.EntityFrameworkCore;
using Tradenet_ProgramManager_2.API.Data;
using Tradenet_ProgramManager_2.API.Models;

namespace Tradenet_ProgramManager_2.API.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly AppDbContext _context;

        public TransactionRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Transaction>> GetAll()
        {
            return await _context.Transactions
                .Include(t => t.Program)
                .OrderByDescending(t => t.Date)
                .ToListAsync();
        }

        public async Task<IEnumerable<Transaction>> GetByProgramId(int programId)
        {
            return await _context.Transactions
                .Where(t => t.ProgramId == programId)
                .Include(t => t.Program)
                .OrderByDescending(t => t.Date)
                .ToListAsync();
        }

        public async Task<IEnumerable<Transaction>> GetByType(string type)
        {
            return await _context.Transactions
                .Where(t => t.Type == type)
                .Include(t => t.Program)
                .OrderByDescending(t => t.Date)
                .ToListAsync();
        }

        public async Task<Transaction?> GetById(int id)
        {
            return await _context.Transactions
                .Include(t => t.Program)
                .FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task Add(Transaction transaction)
        {
            _context.Transactions.Add(transaction);
            await _context.SaveChangesAsync();
        }

        public async Task<decimal> GetTotalByType(string type)
        {
            return await _context.Transactions
                .Where(t => t.Type == type)
                .SumAsync(t => t.Amount);
        }
    }
}
