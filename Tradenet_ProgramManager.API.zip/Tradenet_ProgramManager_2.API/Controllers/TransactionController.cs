using Microsoft.AspNetCore.Mvc;
using Tradenet_ProgramManager_2.API.Models;
using Tradenet_ProgramManager_2.API.Repositories;

namespace Tradenet_ProgramManager_2.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionRepository _transactionRepository;

        public TransactionController(ITransactionRepository transactionRepository)
        {
            _transactionRepository = transactionRepository;
        }

        /// <summary>
        /// Get all transactions
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Transaction>>> GetAllTransactions()
        {
            try
            {
                var transactions = await _transactionRepository.GetAll();
                return Ok(transactions);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving transactions: {ex.Message}" });
            }
        }

        /// <summary>
        /// Get a single transaction by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<Transaction>> GetTransactionById(int id)
        {
            try
            {
                var transaction = await _transactionRepository.GetById(id);
                if (transaction == null)
                {
                    return NotFound(new { message = "Transaction not found" });
                }
                return Ok(transaction);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving transaction: {ex.Message}" });
            }
        }

        /// <summary>
        /// Get transactions by program ID
        /// </summary>
        [HttpGet("program/{programId}")]
        public async Task<ActionResult<IEnumerable<Transaction>>> GetTransactionsByProgramId(int programId)
        {
            try
            {
                var transactions = await _transactionRepository.GetByProgramId(programId);
                return Ok(transactions);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving transactions: {ex.Message}" });
            }
        }

        /// <summary>
        /// Get transactions by type (Sale or Purchase)
        /// </summary>
        [HttpGet("type/{type}")]
        public async Task<ActionResult<IEnumerable<Transaction>>> GetTransactionsByType(string type)
        {
            try
            {
                var transactions = await _transactionRepository.GetByType(type);
                return Ok(transactions);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving transactions: {ex.Message}" });
            }
        }

        /// <summary>
        /// Create a new transaction
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<Transaction>> CreateTransaction([FromBody] Transaction transaction)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                await _transactionRepository.Add(transaction);
                return CreatedAtAction(nameof(GetTransactionById), new { id = transaction.Id }, transaction);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error creating transaction: {ex.Message}" });
            }
        }

        /// <summary>
        /// Get total by transaction type
        /// </summary>
        [HttpGet("total/{type}")]
        public async Task<ActionResult<decimal>> GetTotalByType(string type)
        {
            try
            {
                var total = await _transactionRepository.GetTotalByType(type);
                return Ok(new { type = type, total = total });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error calculating total: {ex.Message}" });
            }
        }
    }
}
