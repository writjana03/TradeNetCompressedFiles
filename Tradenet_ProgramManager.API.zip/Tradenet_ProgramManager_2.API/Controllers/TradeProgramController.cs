using Microsoft.AspNetCore.Mvc;
using Tradenet_ProgramManager_2.API.Models;
using Tradenet_ProgramManager_2.API.Models.ViewModels;
using Tradenet_ProgramManager_2.API.Repositories;
using Tradenet_ProgramManager_2.API.Services;

namespace Tradenet_ProgramManager_2.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TradeProgramController : ControllerBase
    {
        private readonly ITradeProgramRepository _tradeProgramRepository;
        private readonly ITransactionRepository _transactionRepository;
        private readonly ITradeProgramService _tradeProgramService;

        public TradeProgramController(
            ITradeProgramRepository tradeProgramRepository,
            ITransactionRepository transactionRepository,
            ITradeProgramService tradeProgramService)
        {
            _tradeProgramRepository = tradeProgramRepository;
            _transactionRepository = transactionRepository;
            _tradeProgramService = tradeProgramService;
        }

        /// <summary>
        /// Get all trade programs
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TradeProgram>>> GetAllPrograms()
        {
            try
            {
                var programs = await _tradeProgramRepository.GetAll();
                return Ok(programs);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving programs: {ex.Message}" });
            }
        }

        /// <summary>
        /// Get a single trade program by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<TradeProgram>> GetProgramById(int id)
        {
            try
            {
                var program = await _tradeProgramRepository.GetById(id);
                if (program == null)
                {
                    return NotFound(new { message = "Program not found" });
                }
                return Ok(program);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving program: {ex.Message}" });
            }
        }

        /// <summary>
        /// Create a new trade program
        /// </summary>
        [HttpPost]
        public async Task<ActionResult<TradeProgram>> CreateProgram([FromBody] TradeProgram tradeProgram)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                await _tradeProgramRepository.Add(tradeProgram);
                return CreatedAtAction(nameof(GetProgramById), new { id = tradeProgram.Id }, tradeProgram);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error creating program: {ex.Message}" });
            }
        }

        /// <summary>
        /// Update an existing trade program
        /// </summary>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProgram(int id, [FromBody] TradeProgram tradeProgram)
        {
            try
            {
                if (id != tradeProgram.Id)
                {
                    return BadRequest(new { message = "ID mismatch" });
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                await _tradeProgramRepository.Update(tradeProgram);
                return Ok(new { message = "Program updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error updating program: {ex.Message}" });
            }
        }

        /// <summary>
        /// Delete a trade program
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProgram(int id)
        {
            try
            {
                var program = await _tradeProgramRepository.GetById(id);
                if (program == null)
                {
                    return NotFound(new { message = "Program not found" });
                }

                await _tradeProgramRepository.Delete(id);
                return Ok(new { message = "Program deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error deleting program: {ex.Message}" });
            }
        }

        /// <summary>
        /// Get dashboard data (total programs, budget used, sales, purchases, etc.)
        /// </summary>
        [HttpGet("dashboard")]
        public async Task<ActionResult<DashboardViewModel>> GetDashboardData()
        {
            try
            {
                var programs = await _tradeProgramRepository.GetAll();
                var transactions = await _transactionRepository.GetAll();

                var dashboard = new DashboardViewModel
                {
                    TotalPrograms = programs.Count(),
                    BudgetUsed = programs.Sum(p => p.Budget),
                    MarketHealth = "Good",
                    TotalSales = transactions.Where(t => t.Type == "Sale").Sum(t => t.Amount),
                    TotalPurchases = transactions.Where(t => t.Type == "Purchase").Sum(t => t.Amount),
                    NetBalance = transactions.Where(t => t.Type == "Sale").Sum(t => t.Amount) - 
                                transactions.Where(t => t.Type == "Purchase").Sum(t => t.Amount)
                };

                return Ok(dashboard);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Error retrieving dashboard data: {ex.Message}" });
            }
        }
    }
}
