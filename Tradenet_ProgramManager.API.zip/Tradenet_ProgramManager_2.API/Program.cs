using Microsoft.EntityFrameworkCore;
using Tradenet_ProgramManager_2.API.Data;
using Tradenet_ProgramManager_2.API.Repositories;
using Tradenet_ProgramManager_2.API.Services;

namespace Tradenet_ProgramManager_2.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllers();

            // Configure CORS to allow MVC project to call the API
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowMVC", policy =>
                {
                    policy.WithOrigins("https://localhost:7014", "http://localhost:5123")
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                });
            });

            // Configure DbContext with SQL Server
            builder.Services.AddDbContext<AppDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            // Register Repositories and Services
            builder.Services.AddScoped<ITradeProgramRepository, TradeProgramRepository>();
            builder.Services.AddScoped<ITransactionRepository, TransactionRepository>();
            builder.Services.AddScoped<ITradeProgramService, TradeProgramService>();

            var app = builder.Build();

            // Seed the database with sample data
            using (var scope = app.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                try
                {
                    var context = services.GetRequiredService<AppDbContext>();
                    DbInitializer.Initialize(context);
                }
                catch (Exception ex)
                {
                    var logger = services.GetRequiredService<ILogger<Program>>();
                    logger.LogError(ex, "An error occurred while seeding the database.");
                }
            }

            // Configure the HTTP request pipeline.

            app.UseHttpsRedirection();

            // Enable CORS
            app.UseCors("AllowMVC");

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
